import { createClient } from '@supabase/supabase-js';

/**
 * Public Supabase client configuration loaded strictly from Vite environment variables.
 * Configure VITE_SUPABASE_URL and either VITE_SUPABASE_PUBLISHABLE_KEY (recommended) or VITE_SUPABASE_ANON_KEY in Netlify / Vercel / .env.local.
 */
const PLACEHOLDER_URL = 'https://placeholder.invalid';
const PLACEHOLDER_KEY = 'placeholder-anon-key';

const rawSupabaseUrl =
  typeof import.meta.env?.VITE_SUPABASE_URL === 'string'
    ? import.meta.env.VITE_SUPABASE_URL.trim().replace(/\/+$/, '')
    : '';

const rawSupabaseAnonKey =
  (typeof import.meta.env?.VITE_SUPABASE_PUBLISHABLE_KEY === 'string'
    ? import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY.trim()
    : '') ||
  (typeof import.meta.env?.VITE_SUPABASE_ANON_KEY === 'string'
    ? import.meta.env.VITE_SUPABASE_ANON_KEY.trim()
    : '');

export const isSupabaseConfigured =
  rawSupabaseUrl.startsWith('https://') && rawSupabaseAnonKey.length > 0;

export const SUPABASE_URL = isSupabaseConfigured ? rawSupabaseUrl : PLACEHOLDER_URL;

/**
 * Safe storage adapter for cross-origin iframe previews and restricted mobile browsers.
 * Uses localStorage when allowed and falls back to in-memory storage if blocked.
 */
const memoryStorage = new Map<string, string>();
const safeAuthStorage = {
  getItem(key: string): string | null {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return window.localStorage.getItem(key);
      }
    } catch {
      // Fallback to memory storage in restricted browser contexts
    }
    return memoryStorage.get(key) ?? null;
  },
  setItem(key: string, value: string): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(key, value);
        return;
      }
    } catch {
      // Fallback to memory storage in restricted browser contexts
    }
    memoryStorage.set(key, value);
  },
  removeItem(key: string): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.removeItem(key);
        return;
      }
    } catch {
      // Fallback to memory storage in restricted browser contexts
    }
    memoryStorage.delete(key);
  },
};

let initError: string | null = isSupabaseConfigured
  ? null
  : 'لم يتم ضبط متغيرات اتصال Supabase (VITE_SUPABASE_URL و VITE_SUPABASE_PUBLISHABLE_KEY (أو VITE_SUPABASE_ANON_KEY)) في إعدادات الاستضافة.';

function createSafeSupabaseClient() {
  if (!isSupabaseConfigured) {
    return createClient(PLACEHOLDER_URL, PLACEHOLDER_KEY, {
      auth: {
        storage: safeAuthStorage,
        persistSession: false,
        autoRefreshToken: false,
        detectSessionInUrl: false,
      },
    });
  }

  try {
    return createClient(rawSupabaseUrl, rawSupabaseAnonKey, {
      auth: {
        storage: safeAuthStorage,
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    });
  } catch (err) {
    initError =
      err instanceof Error ? err.message : 'تعذر تهيئة عميل Supabase في المتصفح.';
    console.error('[MEYAR Supabase] Client initialization failed:', err);
    return createClient(PLACEHOLDER_URL, PLACEHOLDER_KEY, {
      auth: {
        storage: safeAuthStorage,
        persistSession: false,
        autoRefreshToken: false,
        detectSessionInUrl: false,
      },
    });
  }
}

export const supabase = createSafeSupabaseClient();
export const supabaseInitError: string | null = initError;

interface SupabaseLikeError {
  name?: string;
  message?: string;
  code?: string;
  status?: number;
  details?: string;
  hint?: string;
  error_description?: string;
}

function formatRawErrorDetail(err: SupabaseLikeError): string {
  const parts: string[] = [];
  if (err.status !== undefined && err.status !== null) {
    parts.push(`HTTP ${err.status}`);
  }
  if (err.code) {
    parts.push(err.code);
  } else if (err.name && err.name !== 'Error') {
    parts.push(err.name);
  }
  const rawMessage = err.message || err.error_description || err.details;
  if (rawMessage) {
    parts.push(rawMessage);
  }
  return parts.join(' | ');
}

/**
 * Translates common Supabase Auth & PostgreSQL errors into clear Arabic messages
 * while preserving the real underlying Supabase error detail for troubleshooting.
 */
export function translateSupabaseError(
  error: unknown,
  fallback = 'حدث خطأ أثناء الاتصال بقاعدة البيانات. يرجى المحاولة مرة أخرى.'
): string {
  if (!error) return fallback;
  if (typeof error === 'string') return `${fallback} (${error})`;
  if (typeof error !== 'object') return fallback;

  const err = error as SupabaseLikeError;
  const rawMsg = err.message ?? err.error_description ?? '';
  const msg = rawMsg.toLowerCase();
  const code = err.code ?? '';
  const detail = formatRawErrorDetail(err);
  const suffix = detail ? ` — [${detail}]` : '';

  if (msg.includes('invalid login credentials')) {
    return `البريد الإلكتروني أو كلمة المرور غير صحيحة.${suffix}`;
  }
  if (msg.includes('email not confirmed')) {
    return `يرجى تأكيد بريدك الإلكتروني عبر رابط التفعيل المرسل إليك قبل تسجيل الدخول.${suffix}`;
  }
  if (msg.includes('user already registered') || msg.includes('already been registered')) {
    return `هذا البريد الإلكتروني مسجل بالفعل. يمكنك تسجيل الدخول مباشرة.${suffix}`;
  }
  if (msg.includes('password should be at least') || code === 'weak_password') {
    return `كلمة المرور يجب أن تتكون من 6 أحرف على الأقل.${suffix}`;
  }
  if (msg.includes('unable to validate email') || msg.includes('invalid email')) {
    return `صيغة البريد الإلكتروني غير صحيحة.${suffix}`;
  }
  if (msg.includes('signup is disabled') || msg.includes('signups not allowed')) {
    return `إنشاء الحسابات الجديدة غير مفعّل حالياً في إعدادات Supabase Auth.${suffix}`;
  }
  if (msg.includes('rate limit') || msg.includes('too many requests')) {
    return `تم تجاوز الحد المسموح من المحاولات مؤقتاً. يرجى الانتظار قليلاً ثم المحاولة.${suffix}`;
  }
  if (
    msg.includes('failed to fetch') ||
    msg.includes('network') ||
    err.name === 'AuthRetryableFetchError'
  ) {
    return `تعذر الوصول إلى خادم Supabase (${SUPABASE_URL}). تحقق من حالة المشروع في لوحة Supabase واتصال الإنترنت ثم حاول مجدداً.${suffix}`;
  }
  if (code === '23505' || msg.includes('duplicate key')) {
    return `هذه البيانات مسجلة بالفعل (تعارض في قيمة فريدة مثل كود الطالب أو الرمز).${suffix}`;
  }
  if (code === '23503' || msg.includes('foreign key')) {
    return `لا يمكن إتمام العملية لوجود ارتباط ببيانات أخرى في قاعدة البيانات.${suffix}`;
  }
  if (code === '23502' || msg.includes('null value in column')) {
    return `يرجى استكمال جميع الحقول المطلوبة قبل الحفظ.${suffix}`;
  }
  if (code === '42501' || msg.includes('row-level security') || msg.includes('permission denied')) {
    return `لا تملك صلاحية تنفيذ هذه العملية وفق سياسات الحماية (RLS) في قاعدة البيانات.${suffix}`;
  }

  return detail ? `${fallback}${suffix}` : fallback;
}
