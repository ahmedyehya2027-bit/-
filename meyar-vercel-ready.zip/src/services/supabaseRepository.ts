import type { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import type {
  ActivityEntry,
  Assignment,
  AssignmentKind,
  MCQOptionKey,
  MCQQuestion,
  MeyarStateSnapshot,
  Student,
  StudentSubmission,
  StudyGroup,
  Subject,
  Teacher,
} from '../types/domain';
import { evaluateMCQSubmission } from '../utils/grading';

// --- Raw Database Row Shapes matching the user's Supabase schema ---

interface DbTeacherRow {
  id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  specialty: string | null;
  created_at: string | null;
}

interface DbSubjectRow {
  id: string;
  teacher_id: string;
  name: string;
  code: string | null;
  description: string | null;
  created_at: string | null;
}

interface DbGroupRow {
  id: string;
  teacher_id: string;
  subject_id: string | null;
  name: string;
  schedule: string | null;
  created_at: string | null;
}

interface DbStudentRow {
  id: string;
  teacher_id: string;
  group_id: string | null;
  student_code: string | null;
  full_name: string;
  phone: string | null;
  parent_phone: string | null;
  notes: string | null;
  created_at: string | null;
}

interface DbAssignmentRow {
  id: string;
  teacher_id: string;
  subject_id: string | null;
  group_id: string | null;
  title: string;
  type: string | null;
  total_marks: number | null;
  due_date: string | null;
  status: string | null;
  created_at: string | null;
}

interface DbAnswerKeyRow {
  id: string;
  teacher_id: string;
  assignment_id: string;
  questions: unknown;
  created_at: string | null;
  updated_at: string | null;
}

interface DbSubmissionRow {
  id: string;
  teacher_id: string;
  assignment_id: string;
  student_id: string;
  answers: unknown;
  mcq_score: number | null;
  essay_score: number | null;
  total_score: number | null;
  max_score: number | null;
  ai_feedback: string | null;
  weak_topics: unknown;
  status: string | null;
  submission_source: string | null;
  file_url: string | null;
  graded_at: string | null;
  created_at: string | null;
}

// --- Metadata helpers to keep UI fields lossless in the exact Supabase columns ---

function toNullableUuid(value: string | null | undefined): string | null {
  const trimmed = (value ?? '').trim();
  return trimmed.length > 0 ? trimmed : null;
}

function toIsoDate(value: string | null | undefined): string {
  if (!value) return new Date().toISOString().slice(0, 10);
  return String(value).slice(0, 10);
}

export function serializeSubjectDescription(
  description: string,
  stage: string,
  topics: string[]
): string {
  const lines: string[] = [];
  const cleanStage = stage.trim();
  const cleanTopics = topics.map((t) => t.trim()).filter(Boolean);
  const cleanDesc = description.trim();

  if (cleanStage) lines.push(`المرحلة: ${cleanStage}`);
  if (cleanTopics.length > 0) lines.push(`الموضوعات: ${cleanTopics.join('، ')}`);
  if (cleanDesc) lines.push(cleanDesc);

  return lines.join('\n');
}

export function parseSubjectDescription(raw: string | null | undefined): {
  stage: string;
  topics: string[];
  description: string;
} {
  if (!raw || !raw.trim()) {
    return { stage: 'عام', topics: ['موضوعات عامة'], description: '' };
  }

  let stage = 'عام';
  let topics: string[] = [];
  const remainingLines: string[] = [];

  for (const line of raw.split('\n')) {
    const trimmed = line.trim();
    if (trimmed.startsWith('المرحلة:')) {
      const val = trimmed.slice('المرحلة:'.length).trim();
      if (val) stage = val;
    } else if (trimmed.startsWith('الموضوعات:')) {
      const val = trimmed.slice('الموضوعات:'.length).trim();
      topics = val
        .split(/[،,]/)
        .map((t) => t.trim())
        .filter(Boolean);
    } else if (trimmed.length > 0) {
      remainingLines.push(trimmed);
    }
  }

  return {
    stage,
    topics: topics.length > 0 ? topics : ['موضوعات عامة'],
    description: remainingLines.join('\n'),
  };
}

export function serializeGroupSchedule(
  schedule: string,
  gradeLevel: string,
  capacity: number
): string {
  const parts: string[] = [];
  const cleanSchedule = schedule.trim();
  const cleanGrade = gradeLevel.trim();
  const cleanCapacity = Number.isFinite(capacity) && capacity > 0 ? Math.round(capacity) : 25;

  if (cleanSchedule) parts.push(cleanSchedule);
  if (cleanGrade) parts.push(`الصف: ${cleanGrade}`);
  parts.push(`السعة: ${cleanCapacity}`);

  return parts.join(' | ');
}

export function parseGroupSchedule(raw: string | null | undefined): {
  schedule: string;
  gradeLevel: string;
  capacity: number;
} {
  if (!raw || !raw.trim()) {
    return { schedule: '', gradeLevel: 'عام', capacity: 25 };
  }

  let gradeLevel = 'عام';
  let capacity = 25;
  const scheduleParts: string[] = [];

  for (const segment of raw.split('|')) {
    const trimmed = segment.trim();
    if (trimmed.startsWith('الصف:')) {
      const val = trimmed.slice('الصف:'.length).trim();
      if (val) gradeLevel = val;
    } else if (trimmed.startsWith('السعة:')) {
      const num = parseInt(trimmed.slice('السعة:'.length).trim(), 10);
      if (!Number.isNaN(num) && num > 0) capacity = num;
    } else if (trimmed.length > 0) {
      scheduleParts.push(trimmed);
    }
  }

  return {
    schedule: scheduleParts.join(' | '),
    gradeLevel,
    capacity,
  };
}

function normalizeOptionKey(val: unknown): MCQOptionKey {
  if (val === 'A' || val === 'B' || val === 'C' || val === 'D') return val;
  return 'A';
}

function normalizeQuestions(raw: unknown): MCQQuestion[] {
  if (!Array.isArray(raw)) return [];
  return raw.map((item, idx) => {
    const rec = (item && typeof item === 'object' ? item : {}) as Record<string, unknown>;
    const rawOptions =
      rec.options && typeof rec.options === 'object'
        ? (rec.options as Record<string, unknown>)
        : {};
    return {
      id: typeof rec.id === 'string' && rec.id ? rec.id : `q-${idx + 1}`,
      number: typeof rec.number === 'number' && rec.number > 0 ? rec.number : idx + 1,
      prompt: typeof rec.prompt === 'string' ? rec.prompt : `السؤال رقم ${idx + 1}`,
      topic: typeof rec.topic === 'string' && rec.topic ? rec.topic : 'موضوع عام',
      marks: typeof rec.marks === 'number' && rec.marks > 0 ? rec.marks : 1,
      options: {
        A: typeof rawOptions.A === 'string' ? rawOptions.A : 'الاختيار أ',
        B: typeof rawOptions.B === 'string' ? rawOptions.B : 'الاختيار ب',
        C: typeof rawOptions.C === 'string' ? rawOptions.C : 'الاختيار ج',
        D: typeof rawOptions.D === 'string' ? rawOptions.D : 'الاختيار د',
      },
      correctOption: normalizeOptionKey(rec.correctOption ?? rec.correct_option),
    };
  });
}

function normalizeAnswers(raw: unknown): Record<string, MCQOptionKey | null> {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const result: Record<string, MCQOptionKey | null> = {};
  for (const [key, value] of Object.entries(raw as Record<string, unknown>)) {
    if (value === 'A' || value === 'B' || value === 'C' || value === 'D') {
      result[key] = value;
    } else {
      result[key] = null;
    }
  }
  return result;
}

// --- Row Mappers ---

function mapTeacherRow(row: DbTeacherRow, subjectIds: string[]): Teacher {
  return {
    id: row.id,
    name: row.full_name?.trim() || row.email?.split('@')[0] || 'مدرس',
    email: row.email ?? '',
    phone: row.phone ?? '',
    specialization: row.specialty ?? '',
    subjectIds,
    joinedAt: toIsoDate(row.created_at),
    active: true,
  };
}

function mapSubjectRow(row: DbSubjectRow): Subject {
  const parsed = parseSubjectDescription(row.description);
  return {
    id: row.id,
    name: row.name,
    code: row.code ?? '',
    stage: parsed.stage,
    topics: parsed.topics,
    description: parsed.description,
  };
}

function mapGroupRow(row: DbGroupRow): StudyGroup {
  const parsed = parseGroupSchedule(row.schedule);
  return {
    id: row.id,
    name: row.name,
    gradeLevel: parsed.gradeLevel,
    teacherId: row.teacher_id,
    subjectId: row.subject_id ?? '',
    schedule: parsed.schedule,
    capacity: parsed.capacity,
  };
}

function mapStudentRow(
  row: DbStudentRow,
  groupSubjectMap: Map<string, string>
): Student {
  const groupId = row.group_id ?? '';
  return {
    id: row.id,
    code: row.student_code ?? '',
    name: row.full_name,
    groupId,
    teacherId: row.teacher_id,
    subjectId: groupId ? groupSubjectMap.get(groupId) ?? '' : '',
    phone: row.phone ?? '',
    guardianPhone: row.parent_phone ?? '',
    enrolledAt: toIsoDate(row.created_at),
    notes: row.notes ?? undefined,
  };
}

function mapAssignmentRow(
  row: DbAssignmentRow,
  questions: MCQQuestion[]
): Assignment {
  const computedTotal = questions.reduce((sum, q) => sum + q.marks, 0);
  const kind: AssignmentKind = row.type === 'homework' ? 'homework' : 'exam';
  return {
    id: row.id,
    title: row.title,
    kind,
    teacherId: row.teacher_id,
    subjectId: row.subject_id ?? '',
    groupId: row.group_id ?? '',
    totalMarks: Number(row.total_marks) || computedTotal || 0,
    deadline: row.due_date ? String(row.due_date).slice(0, 10) : '',
    createdAt: toIsoDate(row.created_at),
    questions,
  };
}

function mapSubmissionRow(
  row: DbSubmissionRow,
  assignment?: Assignment
): StudentSubmission {
  const answers = normalizeAnswers(row.answers);
  const evaluated = assignment ? evaluateMCQSubmission(assignment, answers) : null;

  const earnedMarks =
    row.total_score !== null && row.total_score !== undefined
      ? Number(row.total_score)
      : row.mcq_score !== null && row.mcq_score !== undefined
      ? Number(row.mcq_score)
      : evaluated?.earnedMarks ?? 0;

  const totalMarks =
    row.max_score !== null && row.max_score !== undefined && Number(row.max_score) > 0
      ? Number(row.max_score)
      : evaluated?.totalMarks ?? assignment?.totalMarks ?? 0;

  const percentage =
    totalMarks > 0 ? Math.round((earnedMarks / totalMarks) * 1000) / 10 : 0;

  return {
    id: row.id,
    assignmentId: row.assignment_id,
    studentId: row.student_id,
    answers,
    earnedMarks,
    totalMarks,
    percentage,
    correctCount: evaluated?.correctCount ?? 0,
    wrongCount: evaluated?.wrongCount ?? 0,
    unansweredCount: evaluated?.unansweredCount ?? 0,
    gradedAt: toIsoDate(row.graded_at ?? row.created_at),
    notes: row.ai_feedback ?? undefined,
  };
}

function deriveRecentActivities(
  teacherName: string,
  subjects: DbSubjectRow[],
  groups: DbGroupRow[],
  students: DbStudentRow[],
  assignments: DbAssignmentRow[],
  submissions: DbSubmissionRow[],
  studentMap: Map<string, Student>,
  assignmentMap: Map<string, Assignment>
): ActivityEntry[] {
  const entries: ActivityEntry[] = [];

  for (const sub of submissions.slice(0, 10)) {
    const student = studentMap.get(sub.student_id);
    const asg = assignmentMap.get(sub.assignment_id);
    entries.push({
      id: `act-sub-${sub.id}`,
      timestamp: sub.graded_at ?? sub.created_at ?? new Date().toISOString(),
      actor: teacherName,
      action: `رصد درجة (${sub.total_score ?? sub.mcq_score ?? 0}/${sub.max_score ?? asg?.totalMarks ?? 0})`,
      target: `${student?.name ?? 'طالب'} — ${asg?.title ?? 'اختبار'}`,
      category: 'grading',
    });
  }

  for (const asg of assignments.slice(0, 8)) {
    entries.push({
      id: `act-asg-${asg.id}`,
      timestamp: asg.created_at ?? new Date().toISOString(),
      actor: teacherName,
      action: asg.type === 'homework' ? 'إنشاء واجب جديد' : 'إنشاء امتحان جديد',
      target: asg.title,
      category: 'assignment',
    });
  }

  for (const st of students.slice(0, 8)) {
    entries.push({
      id: `act-st-${st.id}`,
      timestamp: st.created_at ?? new Date().toISOString(),
      actor: teacherName,
      action: 'تسجيل طالب',
      target: st.student_code ? `${st.full_name} (${st.student_code})` : st.full_name,
      category: 'student',
    });
  }

  for (const grp of groups.slice(0, 5)) {
    entries.push({
      id: `act-grp-${grp.id}`,
      timestamp: grp.created_at ?? new Date().toISOString(),
      actor: teacherName,
      action: 'إنشاء مجموعة دراسية',
      target: grp.name,
      category: 'system',
    });
  }

  for (const subj of subjects.slice(0, 5)) {
    entries.push({
      id: `act-subj-${subj.id}`,
      timestamp: subj.created_at ?? new Date().toISOString(),
      actor: teacherName,
      action: 'إضافة مادة دراسية',
      target: subj.name,
      category: 'system',
    });
  }

  return entries
    .sort((a, b) => b.timestamp.localeCompare(a.timestamp))
    .slice(0, 25);
}

// --- Public Repository API ---

export const supabaseRepository = {
  /**
   * Ensures the authenticated Supabase Auth user has a corresponding row in `teachers`.
   */
  async ensureTeacherProfile(user: User): Promise<DbTeacherRow> {
    const { data: existing, error: fetchError } = await supabase
      .from('teachers')
      .select('*')
      .eq('id', user.id)
      .maybeSingle();

    if (fetchError) {
      throw fetchError;
    }

    if (existing) {
      return existing as DbTeacherRow;
    }

    const meta = (user.user_metadata ?? {}) as Record<string, unknown>;
    const fullName =
      (typeof meta.full_name === 'string' && meta.full_name.trim()) ||
      user.email?.split('@')[0] ||
      'مدرس جديد';
    const phone = typeof meta.phone === 'string' ? meta.phone.trim() : '';
    const specialty =
      typeof meta.specialty === 'string' && meta.specialty.trim()
        ? meta.specialty.trim()
        : 'تعليم عام';

    const { data: created, error: upsertError } = await supabase
      .from('teachers')
      .upsert(
        {
          id: user.id,
          full_name: fullName,
          email: user.email ?? '',
          phone,
          specialty,
        },
        { onConflict: 'id' }
      )
      .select('*')
      .single();

    if (upsertError) {
      throw upsertError;
    }

    return created as DbTeacherRow;
  },

  /**
   * Loads the full ME'YAR workspace snapshot scoped to the authenticated teacher.
   */
  async loadWorkspace(user: User): Promise<MeyarStateSnapshot> {
    const teacherProfile = await this.ensureTeacherProfile(user);
    const teacherId = user.id;

    const [
      teachersRes,
      subjectsRes,
      groupsRes,
      studentsRes,
      assignmentsRes,
      answerKeysRes,
      submissionsRes,
    ] = await Promise.all([
      supabase
        .from('teachers')
        .select('*')
        .eq('id', teacherId)
        .order('created_at', { ascending: false }),
      supabase
        .from('subjects')
        .select('*')
        .eq('teacher_id', teacherId)
        .order('created_at', { ascending: false }),
      supabase
        .from('groups')
        .select('*')
        .eq('teacher_id', teacherId)
        .order('created_at', { ascending: false }),
      supabase
        .from('students')
        .select('*')
        .eq('teacher_id', teacherId)
        .order('created_at', { ascending: false }),
      supabase
        .from('assignments')
        .select('*')
        .eq('teacher_id', teacherId)
        .order('created_at', { ascending: false }),
      supabase.from('answer_keys').select('*').eq('teacher_id', teacherId),
      supabase
        .from('submissions')
        .select('*')
        .eq('teacher_id', teacherId)
        .order('created_at', { ascending: false }),
    ]);

    const firstError =
      teachersRes.error ||
      subjectsRes.error ||
      groupsRes.error ||
      studentsRes.error ||
      assignmentsRes.error ||
      answerKeysRes.error ||
      submissionsRes.error;

    if (firstError) {
      throw firstError;
    }

    const dbTeachers = (teachersRes.data ?? []) as DbTeacherRow[];
    const dbSubjects = (subjectsRes.data ?? []) as DbSubjectRow[];
    const dbGroups = (groupsRes.data ?? []) as DbGroupRow[];
    const dbStudents = (studentsRes.data ?? []) as DbStudentRow[];
    const dbAssignments = (assignmentsRes.data ?? []) as DbAssignmentRow[];
    const dbAnswerKeys = (answerKeysRes.data ?? []) as DbAnswerKeyRow[];
    const dbSubmissions = (submissionsRes.data ?? []) as DbSubmissionRow[];

    const subjects = dbSubjects.map(mapSubjectRow);

    // Map teachers and derive assigned subjects from subjects.teacher_id
    const teacherRowsToMap = dbTeachers.length > 0 ? dbTeachers : [teacherProfile];
    const teachers = teacherRowsToMap.map((row) =>
      mapTeacherRow(
        row,
        dbSubjects.filter((s) => s.teacher_id === row.id).map((s) => s.id)
      )
    );

    const groups = dbGroups.map(mapGroupRow);
    const groupSubjectMap = new Map(groups.map((g) => [g.id, g.subjectId]));

    const students = dbStudents.map((row) => mapStudentRow(row, groupSubjectMap));
    const studentMap = new Map(students.map((s) => [s.id, s]));

    const answerKeyByAssignment = new Map<string, MCQQuestion[]>();
    for (const ak of dbAnswerKeys) {
      answerKeyByAssignment.set(ak.assignment_id, normalizeQuestions(ak.questions));
    }

    const assignments = dbAssignments.map((row) =>
      mapAssignmentRow(row, answerKeyByAssignment.get(row.id) ?? [])
    );
    const assignmentMap = new Map(assignments.map((a) => [a.id, a]));

    const submissions = dbSubmissions.map((row) =>
      mapSubmissionRow(row, assignmentMap.get(row.assignment_id))
    );

    const primaryTeacherName = teachers[0]?.name ?? 'المدرس';
    const activities = deriveRecentActivities(
      primaryTeacherName,
      dbSubjects,
      dbGroups,
      dbStudents,
      dbAssignments,
      dbSubmissions,
      studentMap,
      assignmentMap
    );

    return {
      subjects,
      teachers,
      groups,
      students,
      assignments,
      submissions,
      activities,
    };
  },

  // --- Teachers CRUD ---

  async createTeacher(input: Omit<Teacher, 'id' | 'joinedAt'>): Promise<Teacher> {
    // teachers.id is tied to an auth account, so a profile cannot be created without sign-up.
    const notice = new Error('حساب كل مدرس يُنشأ بتسجيله بنفسه من شاشة إنشاء حساب. اطلب منه التسجيل وسيظهر هنا تلقائياً.');
    notice.name = 'MeyarUserError';
    throw notice;
  },

  async _createTeacherLegacy(input: Omit<Teacher, 'id' | 'joinedAt'>): Promise<Teacher> {
    const { data, error } = await supabase
      .from('teachers')
      .insert({
        full_name: input.name.trim(),
        email: input.email.trim(),
        phone: input.phone.trim(),
        specialty: input.specialization.trim(),
      })
      .select('*')
      .single();

    if (error) throw error;
    return mapTeacherRow(data as DbTeacherRow, input.subjectIds);
  },

  async updateTeacher(
    id: string,
    updates: Partial<Omit<Teacher, 'id'>>,
    existingSubjectIds: string[]
  ): Promise<Teacher> {
    const payload: Record<string, unknown> = {};
    if (updates.name !== undefined) payload.full_name = updates.name.trim();
    if (updates.email !== undefined) payload.email = updates.email.trim();
    if (updates.phone !== undefined) payload.phone = updates.phone.trim();
    if (updates.specialization !== undefined) {
      payload.specialty = updates.specialization.trim();
    }

    const { data, error } = await supabase
      .from('teachers')
      .update(payload)
      .eq('id', id)
      .select('*')
      .single();

    if (error) throw error;
    return mapTeacherRow(
      data as DbTeacherRow,
      updates.subjectIds ?? existingSubjectIds
    );
  },

  async deleteTeacher(id: string): Promise<void> {
    const { error } = await supabase.from('teachers').delete().eq('id', id);
    if (error) throw error;
  },

  // --- Subjects CRUD ---

  async createSubject(
    teacherId: string,
    input: Omit<Subject, 'id'>
  ): Promise<Subject> {
    const { data, error } = await supabase
      .from('subjects')
      .insert({
        teacher_id: teacherId,
        name: input.name.trim(),
        code: input.code.trim().toUpperCase(),
        description: serializeSubjectDescription(
          input.description,
          input.stage,
          input.topics
        ),
      })
      .select('*')
      .single();

    if (error) throw error;
    return mapSubjectRow(data as DbSubjectRow);
  },

  async updateSubject(
    teacherId: string,
    id: string,
    nextSubject: Subject
  ): Promise<Subject> {
    const { data, error } = await supabase
      .from('subjects')
      .update({
        name: nextSubject.name.trim(),
        code: nextSubject.code.trim().toUpperCase(),
        description: serializeSubjectDescription(
          nextSubject.description,
          nextSubject.stage,
          nextSubject.topics
        ),
      })
      .eq('id', id)
      .eq('teacher_id', teacherId)
      .select('*')
      .single();

    if (error) throw error;
    return mapSubjectRow(data as DbSubjectRow);
  },

  async deleteSubject(teacherId: string, id: string): Promise<void> {
    const { error } = await supabase
      .from('subjects')
      .delete()
      .eq('id', id)
      .eq('teacher_id', teacherId);
    if (error) throw error;
  },

  // --- Groups CRUD ---

  async createGroup(
    teacherId: string,
    input: Omit<StudyGroup, 'id'>
  ): Promise<StudyGroup> {
    const { data, error } = await supabase
      .from('groups')
      .insert({
        teacher_id: teacherId,
        subject_id: toNullableUuid(input.subjectId),
        name: input.name.trim(),
        schedule: serializeGroupSchedule(
          input.schedule,
          input.gradeLevel,
          input.capacity
        ),
      })
      .select('*')
      .single();

    if (error) throw error;
    return mapGroupRow(data as DbGroupRow);
  },

  async updateGroup(
    teacherId: string,
    id: string,
    nextGroup: StudyGroup
  ): Promise<StudyGroup> {
    const { data, error } = await supabase
      .from('groups')
      .update({
        subject_id: toNullableUuid(nextGroup.subjectId),
        name: nextGroup.name.trim(),
        schedule: serializeGroupSchedule(
          nextGroup.schedule,
          nextGroup.gradeLevel,
          nextGroup.capacity
        ),
      })
      .eq('id', id)
      .eq('teacher_id', teacherId)
      .select('*')
      .single();

    if (error) throw error;
    return mapGroupRow(data as DbGroupRow);
  },

  async deleteGroup(teacherId: string, id: string): Promise<void> {
    const { error } = await supabase
      .from('groups')
      .delete()
      .eq('id', id)
      .eq('teacher_id', teacherId);
    if (error) throw error;
  },

  // --- Students CRUD ---

  async createStudent(
    teacherId: string,
    input: Omit<Student, 'id' | 'enrolledAt'>,
    groupSubjectMap: Map<string, string>
  ): Promise<Student> {
    const { data, error } = await supabase
      .from('students')
      .insert({
        teacher_id: teacherId,
        group_id: toNullableUuid(input.groupId),
        student_code: input.code.trim().toUpperCase(),
        full_name: input.name.trim(),
        phone: input.phone?.trim() || null,
        parent_phone: input.guardianPhone.trim() || null,
        notes: input.notes?.trim() || null,
      })
      .select('*')
      .single();

    if (error) throw error;
    return mapStudentRow(data as DbStudentRow, groupSubjectMap);
  },

  async updateStudent(
    teacherId: string,
    id: string,
    nextStudent: Student,
    groupSubjectMap: Map<string, string>
  ): Promise<Student> {
    const { data, error } = await supabase
      .from('students')
      .update({
        group_id: toNullableUuid(nextStudent.groupId),
        student_code: nextStudent.code.trim().toUpperCase(),
        full_name: nextStudent.name.trim(),
        phone: nextStudent.phone?.trim() || null,
        parent_phone: nextStudent.guardianPhone.trim() || null,
        notes: nextStudent.notes?.trim() || null,
      })
      .eq('id', id)
      .eq('teacher_id', teacherId)
      .select('*')
      .single();

    if (error) throw error;
    return mapStudentRow(data as DbStudentRow, groupSubjectMap);
  },

  async deleteStudent(teacherId: string, id: string): Promise<void> {
    // Clean up child submissions first in case FK does not cascade
    const { error: subError } = await supabase
      .from('submissions')
      .delete()
      .eq('student_id', id)
      .eq('teacher_id', teacherId);
    if (subError) throw subError;

    const { error } = await supabase
      .from('students')
      .delete()
      .eq('id', id)
      .eq('teacher_id', teacherId);
    if (error) throw error;
  },

  // --- Assignments & Answer Keys CRUD ---

  async createAssignment(
    teacherId: string,
    input: Omit<Assignment, 'id' | 'createdAt'>
  ): Promise<Assignment> {
    const computedTotal =
      input.questions.reduce((sum, q) => sum + q.marks, 0) || input.totalMarks;

    const { data: asgData, error: asgError } = await supabase
      .from('assignments')
      .insert({
        teacher_id: teacherId,
        subject_id: toNullableUuid(input.subjectId),
        group_id: toNullableUuid(input.groupId),
        title: input.title.trim(),
        type: input.kind,
        total_marks: computedTotal,
        due_date: input.deadline || null,
      })
      .select('*')
      .single();

    if (asgError) throw asgError;
    const createdAsg = asgData as DbAssignmentRow;

    const { error: akError } = await supabase.from('answer_keys').insert({
      teacher_id: teacherId,
      assignment_id: createdAsg.id,
      questions: input.questions,
    });

    if (akError) {
      // Roll back assignment if answer_key insert fails so state stays consistent
      await supabase
        .from('assignments')
        .delete()
        .eq('id', createdAsg.id)
        .eq('teacher_id', teacherId);
      throw akError;
    }

    return mapAssignmentRow(createdAsg, input.questions);
  },

  async updateAssignment(
    teacherId: string,
    id: string,
    nextAssignment: Assignment,
    existingSubmissions: StudentSubmission[]
  ): Promise<{ assignment: Assignment; updatedSubmissions: StudentSubmission[] }> {
    const computedTotal =
      nextAssignment.questions.reduce((sum, q) => sum + q.marks, 0) ||
      nextAssignment.totalMarks;

    const { data: asgData, error: asgError } = await supabase
      .from('assignments')
      .update({
        subject_id: toNullableUuid(nextAssignment.subjectId),
        group_id: toNullableUuid(nextAssignment.groupId),
        title: nextAssignment.title.trim(),
        type: nextAssignment.kind,
        total_marks: computedTotal,
        due_date: nextAssignment.deadline || null,
      })
      .eq('id', id)
      .eq('teacher_id', teacherId)
      .select('*')
      .single();

    if (asgError) throw asgError;

    await this.upsertAnswerKeyQuestions(teacherId, id, nextAssignment.questions);

    const hydrated = mapAssignmentRow(
      asgData as DbAssignmentRow,
      nextAssignment.questions
    );

    const updatedSubmissions = await this.regradeAssignmentSubmissions(
      teacherId,
      hydrated,
      existingSubmissions
    );

    return { assignment: hydrated, updatedSubmissions };
  },

  async upsertAnswerKeyQuestions(
    teacherId: string,
    assignmentId: string,
    questions: MCQQuestion[]
  ): Promise<void> {
    const { data: existingKey, error: fetchErr } = await supabase
      .from('answer_keys')
      .select('id')
      .eq('assignment_id', assignmentId)
      .eq('teacher_id', teacherId)
      .maybeSingle();

    if (fetchErr) throw fetchErr;

    if (existingKey?.id) {
      const { error: updErr } = await supabase
        .from('answer_keys')
        .update({
          questions,
          updated_at: new Date().toISOString(),
        })
        .eq('id', existingKey.id)
        .eq('teacher_id', teacherId);
      if (updErr) throw updErr;
    } else {
      const { error: insErr } = await supabase.from('answer_keys').insert({
        teacher_id: teacherId,
        assignment_id: assignmentId,
        questions,
      });
      if (insErr) throw insErr;
    }
  },

  async regradeAssignmentSubmissions(
    teacherId: string,
    assignment: Assignment,
    existingSubmissions: StudentSubmission[]
  ): Promise<StudentSubmission[]> {
    const affected = existingSubmissions.filter(
      (sub) => sub.assignmentId === assignment.id
    );
    if (affected.length === 0) return [];

    const results = await Promise.all(
      affected.map(async (sub) => {
        const evalRes = evaluateMCQSubmission(assignment, sub.answers);
        const weakTopics = Array.from(
          new Set(
            evalRes.questionBreakdown
              .filter((q) => !q.isCorrect && q.topic)
              .map((q) => q.topic)
          )
        );
        const nowIso = new Date().toISOString();

        const { error } = await supabase
          .from('submissions')
          .update({
            mcq_score: evalRes.earnedMarks,
            total_score: evalRes.earnedMarks,
            max_score: evalRes.totalMarks,
            weak_topics: weakTopics,
            graded_at: nowIso,
          })
          .eq('id', sub.id)
          .eq('teacher_id', teacherId);

        if (error) throw error;

        return {
          ...sub,
          earnedMarks: evalRes.earnedMarks,
          totalMarks: evalRes.totalMarks,
          percentage: evalRes.percentage,
          correctCount: evalRes.correctCount,
          wrongCount: evalRes.wrongCount,
          unansweredCount: evalRes.unansweredCount,
          gradedAt: nowIso.slice(0, 10),
        };
      })
    );

    return results;
  },

  async deleteAssignment(teacherId: string, id: string): Promise<void> {
    const { error: subErr } = await supabase
      .from('submissions')
      .delete()
      .eq('assignment_id', id)
      .eq('teacher_id', teacherId);
    if (subErr) throw subErr;

    const { error: akErr } = await supabase
      .from('answer_keys')
      .delete()
      .eq('assignment_id', id)
      .eq('teacher_id', teacherId);
    if (akErr) throw akErr;

    const { error } = await supabase
      .from('assignments')
      .delete()
      .eq('id', id)
      .eq('teacher_id', teacherId);
    if (error) throw error;
  },

  // --- Submissions CRUD ---

  async saveSubmission(
    teacherId: string,
    assignment: Assignment,
    studentId: string,
    answers: Record<string, MCQOptionKey | null>,
    notes: string | undefined,
    existingSubmissionId?: string
  ): Promise<StudentSubmission> {
    const evalRes = evaluateMCQSubmission(assignment, answers);
    const weakTopics = Array.from(
      new Set(
        evalRes.questionBreakdown
          .filter((q) => !q.isCorrect && q.topic)
          .map((q) => q.topic)
      )
    );
    const nowIso = new Date().toISOString();

    const basePayload = {
      teacher_id: teacherId,
      assignment_id: assignment.id,
      student_id: studentId,
      answers,
      mcq_score: evalRes.earnedMarks,
      essay_score: 0,
      total_score: evalRes.earnedMarks,
      max_score: evalRes.totalMarks,
      ai_feedback: notes?.trim() || null,
      weak_topics: weakTopics,
      graded_at: nowIso,
    };

    const fullPayload = {
      ...basePayload,
      status: 'graded',
      submission_source: 'manual',
    };

    const executeWrite = async (payload: Record<string, unknown>) => {
      if (existingSubmissionId) {
        return supabase
          .from('submissions')
          .update(payload)
          .eq('id', existingSubmissionId)
          .eq('teacher_id', teacherId)
          .select('*')
          .single();
      }
      return supabase.from('submissions').insert(payload).select('*').single();
    };

    let { data, error } = await executeWrite(fullPayload);

    // If a custom CHECK constraint exists on `status` or `submission_source`,
    // retry without those optional fields so PostgreSQL applies its column defaults.
    if (error && error.code === '23514') {
      const retry = await executeWrite(basePayload);
      data = retry.data;
      error = retry.error;
    }

    if (error) throw error;
    return mapSubmissionRow(data as DbSubmissionRow, assignment);
  },

  async deleteSubmission(teacherId: string, submissionId: string): Promise<void> {
    const { error } = await supabase
      .from('submissions')
      .delete()
      .eq('id', submissionId)
      .eq('teacher_id', teacherId);
    if (error) throw error;
  },
};
