import type { MeyarStateSnapshot } from '../types/domain';
import { createInitialSeedData } from '../data/seedData';

const STORAGE_KEY = 'meyar_platform_state_v1';

/**
 * Persistence contract allowing seamless replacement of local storage
 * with a real database backend (PostgreSQL / Firestore / REST API) later.
 */
export interface IMeyarRepository {
  load(): MeyarStateSnapshot;
  save(snapshot: MeyarStateSnapshot): void;
  reset(): MeyarStateSnapshot;
}

function isValidSnapshot(data: unknown): data is MeyarStateSnapshot {
  if (!data || typeof data !== 'object') return false;
  const candidate = data as Record<string, unknown>;
  return (
    Array.isArray(candidate.subjects) &&
    Array.isArray(candidate.teachers) &&
    Array.isArray(candidate.groups) &&
    Array.isArray(candidate.students) &&
    Array.isArray(candidate.assignments) &&
    Array.isArray(candidate.submissions) &&
    Array.isArray(candidate.activities)
  );
}

class LocalStorageMeyarRepository implements IMeyarRepository {
  load(): MeyarStateSnapshot {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        const seed = createInitialSeedData();
        this.save(seed);
        return seed;
      }
      const parsed: unknown = JSON.parse(raw);
      if (!isValidSnapshot(parsed)) {
        const seed = createInitialSeedData();
        this.save(seed);
        return seed;
      }
      return parsed;
    } catch {
      return createInitialSeedData();
    }
  }

  save(snapshot: MeyarStateSnapshot): void {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
    } catch {
      // Gracefully ignore storage quota errors in restricted sandboxes
    }
  }

  reset(): MeyarStateSnapshot {
    const fresh = createInitialSeedData();
    this.save(fresh);
    return fresh;
  }
}

export const meyarRepository: IMeyarRepository = new LocalStorageMeyarRepository();
