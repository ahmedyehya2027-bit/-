/**
 * Modular integration adapter contracts for future backend capabilities.
 * IMPORTANT: None of these external services are connected in this local prototype.
 * Each adapter exposes explicit status metadata so the UI stays honest and transparent.
 */

export type IntegrationStatus = 'connected' | 'not_connected' | 'ready_for_config';

export interface IntegrationDescriptor {
  id: 'database' | 'auth' | 'cloud_storage' | 'telegram' | 'ai_essay_grading';
  title: string;
  description: string;
  status: IntegrationStatus;
  plannedProvider: string;
}

export interface IAuthService {
  getCurrentRole(): 'admin' | 'teacher' | 'unauthenticated';
  isConnected(): boolean;
}

export interface ICloudStorageService {
  isConnected(): boolean;
  getAcceptedFormats(): string[];
}

export interface ITelegramNotificationService {
  isConnected(): boolean;
  buildStudentReportPayload(studentCode: string, scoreLabel: string): {
    studentCode: string;
    messagePreview: string;
  };
}

export interface IAIEssayGradingService {
  isConnected(): boolean;
}

export const FUTURE_INTEGRATIONS: IntegrationDescriptor[] = [
  {
    id: 'database',
    title: 'قاعدة البيانات السحابية',
    description: 'متصل بقاعدة بيانات PostgreSQL السحابية عبر Supabase لحفظ بيانات المدرسين والطلاب والواجبات والدرجات.',
    status: 'connected',
    plannedProvider: 'Supabase PostgreSQL',
  },
  {
    id: 'auth',
    title: 'المصادقة وصلاحيات المستخدمين',
    description: 'تسجيل دخول وإنشاء حسابات المدرسين بالبريد الإلكتروني وكلمة المرور مع عزل بيانات كل مدرس.',
    status: 'connected',
    plannedProvider: 'Supabase Auth',
  },
  {
    id: 'cloud_storage',
    title: 'التخزين السحابي للمرفقات',
    description: 'رفع أوراق الامتحانات المصورة وملفات PDF الخاصة بالواجبات ونماذج الإجابة.',
    status: 'not_connected',
    plannedProvider: 'Cloud Storage Bucket',
  },
  {
    id: 'telegram',
    title: 'إشعارات تيليجرام لأولياء الأمور',
    description: 'إرسال تقارير الدرجات وتنبيهات الواجبات تلقائياً عبر بوت تيليجرام.',
    status: 'not_connected',
    plannedProvider: 'Telegram Bot API',
  },
  {
    id: 'ai_essay_grading',
    title: 'تصحيح الأسئلة المقالية بالذكاء الاصطناعي',
    description: 'تقييم الإجابات المقالية وفق معايير التصحيح (Rubrics) ومراجعتها بواسطة المدرس.',
    status: 'not_connected',
    plannedProvider: 'Server-side AI Grading Endpoint',
  },
];

export const telegramAdapter: ITelegramNotificationService = {
  isConnected: () => false,
  buildStudentReportPayload: (studentCode, scoreLabel) => ({
    studentCode,
    messagePreview: `تقرير منصة مِعيار — كود الطالب: ${studentCode} | النتيجة: ${scoreLabel}`,
  }),
};
