import type {
  Assignment,
  MCQOptionKey,
  Student,
  StudentSubmission,
  StudyGroup,
  Subject,
  Teacher,
} from '../types/domain';

export interface GradingResult {
  earnedMarks: number;
  totalMarks: number;
  percentage: number;
  correctCount: number;
  wrongCount: number;
  unansweredCount: number;
  questionBreakdown: Array<{
    questionId: string;
    number: number;
    topic: string;
    marks: number;
    correctOption: MCQOptionKey;
    selectedOption: MCQOptionKey | null;
    isCorrect: boolean;
    earned: number;
  }>;
}

/**
 * Pure deterministic MCQ grading function.
 * Designed to be reusable both client-side and in a future server-side grading API.
 */
export function evaluateMCQSubmission(
  assignment: Assignment,
  answers: Record<string, MCQOptionKey | null>
): GradingResult {
  let earnedMarks = 0;
  let computedTotalMarks = 0;
  let correctCount = 0;
  let wrongCount = 0;
  let unansweredCount = 0;

  const questionBreakdown = assignment.questions.map((q) => {
    const selectedOption = answers[q.id] ?? null;
    computedTotalMarks += q.marks;
    const isCorrect = selectedOption !== null && selectedOption === q.correctOption;

    if (selectedOption === null) {
      unansweredCount += 1;
    } else if (isCorrect) {
      correctCount += 1;
      earnedMarks += q.marks;
    } else {
      wrongCount += 1;
    }

    return {
      questionId: q.id,
      number: q.number,
      topic: q.topic,
      marks: q.marks,
      correctOption: q.correctOption,
      selectedOption,
      isCorrect,
      earned: isCorrect ? q.marks : 0,
    };
  });

  const totalMarks = computedTotalMarks > 0 ? computedTotalMarks : assignment.totalMarks;
  const percentage =
    totalMarks > 0 ? Math.round((earnedMarks / totalMarks) * 1000) / 10 : 0;

  return {
    earnedMarks: Math.round(earnedMarks * 100) / 100,
    totalMarks,
    percentage,
    correctCount,
    wrongCount,
    unansweredCount,
    questionBreakdown,
  };
}

export function getPerformanceBand(percentage: number): {
  label: string;
  textClass: string;
} {
  if (percentage >= 85) {
    return { label: 'ممتاز', textClass: 'text-emerald-700' };
  }
  if (percentage >= 75) {
    return { label: 'جيد جداً', textClass: 'text-teal-700' };
  }
  if (percentage >= 60) {
    return { label: 'جيد', textClass: 'text-amber-700' };
  }
  return { label: 'يحتاج متابعة', textClass: 'text-red-700' };
}

export interface DifficultTopicMetric {
  topic: string;
  subjectName: string;
  subjectId: string;
  totalAttempts: number;
  wrongAttempts: number;
  errorRate: number;
  accuracyRate: number;
}

export function computeDifficultTopics(
  assignments: Assignment[],
  submissions: StudentSubmission[],
  subjects: Subject[]
): DifficultTopicMetric[] {
  const subjectMap = new Map(subjects.map((s) => [s.id, s]));
  const assignmentMap = new Map(assignments.map((a) => [a.id, a]));
  const stats = new Map<
    string,
    { topic: string; subjectId: string; subjectName: string; total: number; wrong: number }
  >();

  for (const sub of submissions) {
    const assignment = assignmentMap.get(sub.assignmentId);
    if (!assignment) continue;
    const subject = subjectMap.get(assignment.subjectId);
    const subjectName = subject?.name ?? 'غير محدد';

    for (const q of assignment.questions) {
      const key = `${assignment.subjectId}::${q.topic}`;
      const existing = stats.get(key) ?? {
        topic: q.topic,
        subjectId: assignment.subjectId,
        subjectName,
        total: 0,
        wrong: 0,
      };
      existing.total += 1;
      const selected = sub.answers[q.id];
      if (!selected || selected !== q.correctOption) {
        existing.wrong += 1;
      }
      stats.set(key, existing);
    }
  }

  return Array.from(stats.values())
    .filter((item) => item.total > 0)
    .map((item) => {
      const errorRate = Math.round((item.wrong / item.total) * 100);
      return {
        topic: item.topic,
        subjectName: item.subjectName,
        subjectId: item.subjectId,
        totalAttempts: item.total,
        wrongAttempts: item.wrong,
        errorRate,
        accuracyRate: 100 - errorRate,
      };
    })
    .sort((a, b) => b.errorRate - a.errorRate);
}

export interface StudentPerformanceSummary {
  student: Student;
  groupName: string;
  teacherName: string;
  subjectName: string;
  gradedCount: number;
  averagePercentage: number | null;
  highestPercentage: number | null;
  lowestPercentage: number | null;
  latestPercentage: number | null;
  trendDelta: number | null;
}

export function computeStudentSummaries(
  students: Student[],
  submissions: StudentSubmission[],
  groups: StudyGroup[],
  teachers: Teacher[],
  subjects: Subject[]
): StudentPerformanceSummary[] {
  const groupMap = new Map(groups.map((g) => [g.id, g.name]));
  const teacherMap = new Map(teachers.map((t) => [t.id, t.name]));
  const subjectMap = new Map(subjects.map((s) => [s.id, s.name]));

  return students.map((student) => {
    const studentSubs = submissions
      .filter((s) => s.studentId === student.id)
      .sort((a, b) => a.gradedAt.localeCompare(b.gradedAt));

    if (studentSubs.length === 0) {
      return {
        student,
        groupName: groupMap.get(student.groupId) ?? 'غير محدد',
        teacherName: teacherMap.get(student.teacherId) ?? 'غير محدد',
        subjectName: subjectMap.get(student.subjectId) ?? 'غير محدد',
        gradedCount: 0,
        averagePercentage: null,
        highestPercentage: null,
        lowestPercentage: null,
        latestPercentage: null,
        trendDelta: null,
      };
    }

    const percentages = studentSubs.map((s) => s.percentage);
    const avg =
      Math.round(
        (percentages.reduce((acc, v) => acc + v, 0) / percentages.length) * 10
      ) / 10;
    const latest = percentages[percentages.length - 1];
    const prev = percentages.length >= 2 ? percentages[percentages.length - 2] : null;
    const trendDelta = prev !== null ? Math.round((latest - prev) * 10) / 10 : null;

    return {
      student,
      groupName: groupMap.get(student.groupId) ?? 'غير محدد',
      teacherName: teacherMap.get(student.teacherId) ?? 'غير محدد',
      subjectName: subjectMap.get(student.subjectId) ?? 'غير محدد',
      gradedCount: studentSubs.length,
      averagePercentage: avg,
      highestPercentage: Math.max(...percentages),
      lowestPercentage: Math.min(...percentages),
      latestPercentage: latest,
      trendDelta,
    };
  });
}

export function formatArabicDate(isoDate: string): string {
  if (!isoDate) return '—';
  try {
    const date = new Date(isoDate);
    if (Number.isNaN(date.getTime())) return isoDate;
    return new Intl.DateTimeFormat('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(date);
  } catch {
    return isoDate;
  }
}

export function exportRowsToCSV(
  filename: string,
  headers: string[],
  rows: Array<Array<string | number | null | undefined>>
): void {
  const escapeCell = (cell: string | number | null | undefined): string => {
    const value = cell === null || cell === undefined ? '' : String(cell);
    if (value.includes(',') || value.includes('"') || value.includes('\n')) {
      return `"${value.replace(/"/g, '""')}"`;
    }
    return value;
  };

  const csvLines = [
    headers.map(escapeCell).join(','),
    ...rows.map((row) => row.map(escapeCell).join(',')),
  ];

  // UTF-8 BOM ensures Arabic text renders cleanly in Microsoft Excel
  const blob = new Blob(['\uFEFF' + csvLines.join('\n')], {
    type: 'text/csv;charset=utf-8;',
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename.endsWith('.csv') ? filename : `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
