import type {
  Assignment,
  Student,
  StudentSubmission,
  StudyGroup,
  Subject,
  Teacher,
} from '../types/domain';
import {
  getPerformanceBand,
  type StudentPerformanceSummary,
} from './grading';

export type CsvCell = string | number | null | undefined;

export interface CsvExportPayload {
  headers: string[];
  rows: CsvCell[][];
}

export interface CsvDownloadResult {
  filename: string;
  rowCount: number;
  byteSize: number;
}

/**
 * Escapes a single CSV cell per RFC 4180 while mitigating spreadsheet formula injection.
 */
export function escapeCsvCell(cell: CsvCell): string {
  if (cell === null || cell === undefined) return '';
  let value = String(cell);

  // Neutralize spreadsheet formula execution for untrusted text starting with =, +, @
  // (Keep numeric negative values like -5 untouched while neutralizing formulas like -SUM(A1))
  if (
    value.startsWith('=') ||
    value.startsWith('+') ||
    value.startsWith('@') ||
    (value.startsWith('-') && value.length > 1 && !/^\-\d/.test(value))
  ) {
    value = `'${value}`;
  }

  if (
    value.includes(',') ||
    value.includes('"') ||
    value.includes('\n') ||
    value.includes('\r')
  ) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

/**
 * Builds an Excel-compatible UTF-8 CSV string prefixed with UTF-8 BOM (\uFEFF)
 * and CRLF line endings so Arabic text renders accurately in Microsoft Excel.
 */
export function buildCsvContent(headers: string[], rows: CsvCell[][]): string {
  const lines = [
    headers.map(escapeCsvCell).join(','),
    ...rows.map((row) => row.map(escapeCsvCell).join(',')),
  ];
  return '\uFEFF' + lines.join('\r\n');
}

/**
 * Generates an organized, date-stamped filename for ME'YAR CSV exports.
 */
export function buildExportFilename(
  datasetSlug: string,
  options?: { filtered?: boolean; detailSlug?: string; date?: Date }
): string {
  const dateObj = options?.date ?? new Date();
  const isoDate = dateObj.toISOString().slice(0, 10);
  const parts = ['meyar', datasetSlug];
  if (options?.detailSlug) {
    const clean = options.detailSlug
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9\u0600-\u06FF]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 32);
    if (clean) parts.push(clean);
  }
  if (options?.filtered) {
    parts.push('filtered');
  }
  parts.push(isoDate);
  return `${parts.join('-')}.csv`;
}

/**
 * Triggers a client-side CSV download with UTF-8 BOM encoding.
 */
export function downloadCsvFile(
  filename: string,
  headers: string[],
  rows: CsvCell[][]
): CsvDownloadResult {
  const content = buildCsvContent(headers, rows);
  const finalName = filename.endsWith('.csv') ? filename : `${filename}.csv`;
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', finalName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  return {
    filename: finalName,
    rowCount: rows.length,
    byteSize: blob.size,
  };
}

// ============================================================================
// Domain Dataset CSV Builders (Pure & Testable)
// ============================================================================

export function buildStudentsCsvData(
  summaries: StudentPerformanceSummary[]
): CsvExportPayload {
  return {
    headers: [
      'كود الطالب',
      'اسم الطالب',
      'المجموعة',
      'المدرس',
      'المادة الدراسية',
      'هاتف ولي الأمر',
      'تاريخ التسجيل',
      'الاختبارات المصححة',
      'المتوسط %',
      'أعلى درجة %',
      'أدنى درجة %',
      'التقدير',
      'ملاحظات',
    ],
    rows: summaries.map((item) => [
      item.student.code,
      item.student.name,
      item.groupName,
      item.teacherName,
      item.subjectName,
      item.student.guardianPhone || '—',
      item.student.enrolledAt,
      item.gradedCount,
      item.averagePercentage !== null ? item.averagePercentage : '—',
      item.highestPercentage !== null ? item.highestPercentage : '—',
      item.lowestPercentage !== null ? item.lowestPercentage : '—',
      item.averagePercentage !== null
        ? getPerformanceBand(item.averagePercentage).label
        : 'غير مصحح',
      item.student.notes ?? '',
    ]),
  };
}

export interface TeacherExportRow {
  teacher: Teacher;
  subjectsLabel: string;
  groupsCount: number;
  studentsCount: number;
  assignmentsCount: number;
  gradedCount?: number;
  avgScore: number | null;
  passRate?: number | null;
}

export function buildTeachersCsvData(rows: TeacherExportRow[]): CsvExportPayload {
  return {
    headers: [
      'اسم المدرس',
      'التخصص',
      'البريد الإلكتروني',
      'رقم الهاتف',
      'المواد الدراسية',
      'عدد المجموعات',
      'عدد الطلاب',
      'الواجبات والامتحانات',
      'الأوراق المصححة',
      'متوسط الدرجات %',
      'نسبة النجاح %',
      'الحالة',
      'تاريخ الانضمام',
    ],
    rows: rows.map((r) => [
      r.teacher.name,
      r.teacher.specialization,
      r.teacher.email || '—',
      r.teacher.phone || '—',
      r.subjectsLabel || 'غير محدد',
      r.groupsCount,
      r.studentsCount,
      r.assignmentsCount,
      r.gradedCount ?? 0,
      r.avgScore !== null ? r.avgScore : '—',
      r.passRate !== null && r.passRate !== undefined ? r.passRate : '—',
      r.teacher.active ? 'نشط' : 'موقوف مؤقتاً',
      r.teacher.joinedAt,
    ]),
  };
}

export interface GroupExportRow {
  group: StudyGroup;
  teacherName: string;
  subjectName: string;
  enrolled: number;
  assignmentsCount: number;
  gradedCount?: number;
  avg: number | null;
  passRate?: number | null;
}

export function buildGroupsCsvData(rows: GroupExportRow[]): CsvExportPayload {
  return {
    headers: [
      'اسم المجموعة',
      'الصف الدراسي',
      'المدرس',
      'المادة الدراسية',
      'المواعيد',
      'الطلاب المسجلون',
      'السعة القصوى',
      'الواجبات والامتحانات',
      'الأوراق المصححة',
      'متوسط المجموعة %',
      'نسبة النجاح %',
    ],
    rows: rows.map((r) => [
      r.group.name,
      r.group.gradeLevel,
      r.teacherName,
      r.subjectName,
      r.group.schedule || '—',
      r.enrolled,
      r.group.capacity,
      r.assignmentsCount,
      r.gradedCount ?? 0,
      r.avg !== null ? r.avg : '—',
      r.passRate !== null && r.passRate !== undefined ? r.passRate : '—',
    ]),
  };
}

export interface AssignmentExportRow {
  assignment: Assignment;
  subjectName: string;
  groupName: string;
  teacherName: string;
  gradedCount: number;
  groupStudentsCount: number;
  averagePercentage: number | null;
}

export function buildAssignmentsCsvData(rows: AssignmentExportRow[]): CsvExportPayload {
  return {
    headers: [
      'عنوان الواجب / الامتحان',
      'النوع',
      'المادة الدراسية',
      'المجموعة',
      'المدرس',
      'عدد الأسئلة',
      'الدرجة النهائية',
      'تاريخ الإنشاء',
      'الموعد النهائي',
      'تم تصحيحه',
      'إجمالي طلاب المجموعة',
      'متوسط الدرجات %',
    ],
    rows: rows.map((r) => [
      r.assignment.title,
      r.assignment.kind === 'exam' ? 'امتحان' : 'واجب منزلي',
      r.subjectName,
      r.groupName,
      r.teacherName,
      r.assignment.questions.length,
      r.assignment.totalMarks,
      r.assignment.createdAt,
      r.assignment.deadline,
      r.gradedCount,
      r.groupStudentsCount,
      r.averagePercentage !== null ? r.averagePercentage : '—',
    ]),
  };
}

export interface GradeExportRow {
  submission: StudentSubmission;
  student: Student | undefined;
  assignment: Assignment | undefined;
  subject: Subject | undefined;
  group: StudyGroup | undefined;
  teacher: Teacher | undefined;
}

export function buildGradesCsvData(rows: GradeExportRow[]): CsvExportPayload {
  return {
    headers: [
      'كود الطالب',
      'اسم الطالب',
      'عنوان الواجب / الامتحان',
      'النوع',
      'المادة الدراسية',
      'المجموعة',
      'المدرس',
      'الدرجة المستحقة',
      'الدرجة النهائية',
      'النسبة المئوية %',
      'إجابات صحيحة',
      'إجابات خاطئة',
      'بدون إجابة',
      'التقدير',
      'تاريخ التصحيح',
      'ملاحظات المدرس',
    ],
    rows: rows.map((r) => [
      r.student?.code ?? '—',
      r.student?.name ?? 'طالب غير موجود',
      r.assignment?.title ?? 'اختبار غير موجود',
      r.assignment ? (r.assignment.kind === 'exam' ? 'امتحان' : 'واجب منزلي') : '—',
      r.subject?.name ?? '—',
      r.group?.name ?? '—',
      r.teacher?.name ?? '—',
      r.submission.earnedMarks,
      r.submission.totalMarks,
      r.submission.percentage,
      r.submission.correctCount,
      r.submission.wrongCount,
      r.submission.unansweredCount,
      getPerformanceBand(r.submission.percentage).label,
      r.submission.gradedAt,
      r.submission.notes ?? '',
    ]),
  };
}
