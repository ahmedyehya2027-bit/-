import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import type {
  ActivityEntry,
  Assignment,
  MCQOptionKey,
  MeyarStateSnapshot,
  NavSectionId,
  Student,
  StudentSubmission,
  StudyGroup,
  Subject,
  Teacher,
} from '../types/domain';
import { useAuth } from './AuthContext';
import { translateSupabaseError } from '../lib/supabase';
import { supabaseRepository } from '../services/supabaseRepository';

interface NavigationContextPayload {
  assignmentId?: string;
  studentId?: string;
}

interface ToastState {
  message: string;
  variant: 'default' | 'error';
}

const EMPTY_STATE: MeyarStateSnapshot = {
  subjects: [],
  teachers: [],
  groups: [],
  students: [],
  assignments: [],
  submissions: [],
  activities: [],
};

interface MeyarContextValue {
  state: MeyarStateSnapshot;
  currentTeacher: Teacher | null;
  isLoading: boolean;
  isSyncing: boolean;
  loadError: string | null;
  refreshData: () => Promise<void>;

  activeSection: NavSectionId;
  navPayload: NavigationContextPayload;
  navigate: (section: NavSectionId, payload?: NavigationContextPayload) => void;
  clearNavPayload: () => void;
  toastMessage: string | null;
  toastVariant: 'default' | 'error';
  showToast: (message: string, variant?: 'default' | 'error') => void;

  // Teachers CRUD
  addTeacher: (teacher: Omit<Teacher, 'id' | 'joinedAt'>) => Promise<boolean>;
  updateTeacher: (id: string, updates: Partial<Omit<Teacher, 'id'>>) => Promise<boolean>;
  deleteTeacher: (id: string) => Promise<boolean>;

  // Students CRUD
  addStudent: (student: Omit<Student, 'id' | 'enrolledAt'>) => Promise<boolean>;
  updateStudent: (id: string, updates: Partial<Omit<Student, 'id'>>) => Promise<boolean>;
  deleteStudent: (id: string) => Promise<boolean>;
  generateNextStudentCode: () => string;

  // Groups CRUD
  addGroup: (group: Omit<StudyGroup, 'id'>) => Promise<boolean>;
  updateGroup: (id: string, updates: Partial<Omit<StudyGroup, 'id'>>) => Promise<boolean>;
  deleteGroup: (id: string) => Promise<boolean>;

  // Subjects CRUD
  addSubject: (subject: Omit<Subject, 'id'>) => Promise<boolean>;
  updateSubject: (id: string, updates: Partial<Omit<Subject, 'id'>>) => Promise<boolean>;
  deleteSubject: (id: string) => Promise<boolean>;

  // Assignments & Answer Keys
  addAssignment: (
    assignment: Omit<Assignment, 'id' | 'createdAt'>
  ) => Promise<Assignment | null>;
  updateAssignment: (
    id: string,
    updates: Partial<Omit<Assignment, 'id'>>
  ) => Promise<boolean>;
  deleteAssignment: (id: string) => Promise<boolean>;
  updateAnswerKey: (
    assignmentId: string,
    keyMap: Record<string, MCQOptionKey>
  ) => Promise<boolean>;

  // Grading / Submissions
  saveSubmission: (
    assignmentId: string,
    studentId: string,
    answers: Record<string, MCQOptionKey | null>,
    notes?: string
  ) => Promise<StudentSubmission | null>;
  deleteSubmission: (submissionId: string) => Promise<boolean>;
}

const MeyarContext = createContext<MeyarContextValue | null>(null);

function pushActivity(
  prev: MeyarStateSnapshot,
  actor: string,
  action: string,
  target: string,
  category: ActivityEntry['category']
): ActivityEntry[] {
  const entry: ActivityEntry = {
    id: `act-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: new Date().toISOString(),
    actor,
    action,
    target,
    category,
  };
  return [entry, ...prev.activities].slice(0, 30);
}

export const MeyarProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [state, setState] = useState<MeyarStateSnapshot>(EMPTY_STATE);
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [activeSection, setActiveSection] = useState<NavSectionId>('dashboard');
  const [navPayload, setNavPayload] = useState<NavigationContextPayload>({});
  const [toast, setToast] = useState<ToastState | null>(null);

  const showToast = useCallback(
    (message: string, variant: 'default' | 'error' = 'default') => {
      setToast({ message, variant });
    },
    []
  );

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 4000);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const loadWorkspace = useCallback(
    async (silent = false) => {
      if (!user) {
        setState(EMPTY_STATE);
        setIsLoading(false);
        return;
      }
      if (!silent) {
        setIsLoading(true);
      } else {
        setIsSyncing(true);
      }
      setLoadError(null);

      try {
        const snapshot = await supabaseRepository.loadWorkspace(user);
        setState(snapshot);
      } catch (err) {
        const msg = translateSupabaseError(
          err,
          'تعذر تحميل بيانات المنصة من قاعدة البيانات.'
        );
        setLoadError(msg);
      } finally {
        setIsLoading(false);
        setIsSyncing(false);
      }
    },
    [user]
  );

  useEffect(() => {
    void loadWorkspace(false);
  }, [loadWorkspace]);

  const refreshData = useCallback(async () => {
    await loadWorkspace(true);
  }, [loadWorkspace]);

  const currentTeacher = useMemo(() => {
    if (!user) return null;
    return state.teachers.find((t) => t.id === user.id) ?? state.teachers[0] ?? null;
  }, [state.teachers, user]);

  const actorName = currentTeacher?.name ?? user?.email ?? 'المدرس';

  const navigate = useCallback(
    (section: NavSectionId, payload?: NavigationContextPayload) => {
      setActiveSection(section);
      setNavPayload(payload ?? {});
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    []
  );

  const clearNavPayload = useCallback(() => {
    setNavPayload({});
  }, []);

  // --- Teachers CRUD ---
  const addTeacher = useCallback(
    async (teacherData: Omit<Teacher, 'id' | 'joinedAt'>): Promise<boolean> => {
      if (!user) return false;
      try {
        const created = await supabaseRepository.createTeacher(teacherData);
        setState((prev) => ({
          ...prev,
          teachers: [created, ...prev.teachers],
          activities: pushActivity(
            prev,
            actorName,
            'إضافة مدرس جديد',
            created.name,
            'teacher'
          ),
        }));
        showToast(`تمت إضافة المدرس ${created.name} بنجاح`);
        return true;
      } catch (err) {
        showToast(
          err instanceof Error && err.name === 'MeyarUserError'
            ? err.message
            : translateSupabaseError(
            err,
            'تعذر إضافة مدرس جديد (حسابات المدرسين مرتبطة بالمصادقة المسجلة).'
          ),
          'error'
        );
        return false;
      }
    },
    [user, actorName, showToast]
  );

  const updateTeacher = useCallback(
    async (id: string, updates: Partial<Omit<Teacher, 'id'>>): Promise<boolean> => {
      if (!user) return false;
      const existing = state.teachers.find((t) => t.id === id);
      if (!existing) return false;
      try {
        const updated = await supabaseRepository.updateTeacher(
          id,
          updates,
          existing.subjectIds
        );
        setState((prev) => ({
          ...prev,
          teachers: prev.teachers.map((t) =>
            t.id === id ? { ...updated, active: updates.active ?? t.active } : t
          ),
          activities: pushActivity(
            prev,
            actorName,
            'تحديث بيانات مدرس',
            updated.name,
            'teacher'
          ),
        }));
        showToast('تم تحديث بيانات المدرس في قاعدة البيانات');
        return true;
      } catch (err) {
        showToast(
          translateSupabaseError(err, 'تعذر تحديث بيانات المدرس.'),
          'error'
        );
        return false;
      }
    },
    [user, state.teachers, actorName, showToast]
  );

  const deleteTeacher = useCallback(
    async (id: string): Promise<boolean> => {
      if (!user) return false;
      if (id === user.id) {
        showToast('لا يمكن حذف ملف حساب المدرس المسجل حالياً.', 'error');
        return false;
      }
      const target = state.teachers.find((t) => t.id === id);
      try {
        await supabaseRepository.deleteTeacher(id);
        setState((prev) => ({
          ...prev,
          teachers: prev.teachers.filter((t) => t.id !== id),
          activities: target
            ? pushActivity(prev, actorName, 'حذف سجل مدرس', target.name, 'teacher')
            : prev.activities,
        }));
        showToast('تم حذف المدرس من السجل');
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر حذف المدرس.'), 'error');
        return false;
      }
    },
    [user, state.teachers, actorName, showToast]
  );

  // --- Students CRUD ---
  const generateNextStudentCode = useCallback(() => {
    const nums = state.students
      .map((s) => parseInt(s.code.replace(/\D/g, ''), 10))
      .filter((n) => !Number.isNaN(n));
    const next = nums.length > 0 ? Math.max(...nums) + 1 : 1001;
    return `MYR-${next}`;
  }, [state.students]);

  const groupSubjectMap = useMemo(
    () => new Map(state.groups.map((g) => [g.id, g.subjectId])),
    [state.groups]
  );

  const addStudent = useCallback(
    async (studentData: Omit<Student, 'id' | 'enrolledAt'>): Promise<boolean> => {
      if (!user) return false;
      try {
        const created = await supabaseRepository.createStudent(
          user.id,
          studentData,
          groupSubjectMap
        );
        setState((prev) => ({
          ...prev,
          students: [created, ...prev.students],
          activities: pushActivity(
            prev,
            actorName,
            'تسجيل طالب جديد',
            `${created.name} (${created.code})`,
            'student'
          ),
        }));
        showToast(`تم تسجيل الطالب ${created.name} بالكود ${created.code}`);
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر تسجيل الطالب.'), 'error');
        return false;
      }
    },
    [user, groupSubjectMap, actorName, showToast]
  );

  const updateStudent = useCallback(
    async (id: string, updates: Partial<Omit<Student, 'id'>>): Promise<boolean> => {
      if (!user) return false;
      const existing = state.students.find((s) => s.id === id);
      if (!existing) return false;
      const merged: Student = { ...existing, ...updates };
      try {
        const updated = await supabaseRepository.updateStudent(
          user.id,
          id,
          merged,
          groupSubjectMap
        );
        setState((prev) => ({
          ...prev,
          students: prev.students.map((s) => (s.id === id ? updated : s)),
          activities: pushActivity(
            prev,
            actorName,
            'تعديل بيانات طالب',
            `${updated.name} (${updated.code})`,
            'student'
          ),
        }));
        showToast('تم حفظ تعديلات بيانات الطالب');
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر تعديل بيانات الطالب.'), 'error');
        return false;
      }
    },
    [user, state.students, groupSubjectMap, actorName, showToast]
  );

  const deleteStudent = useCallback(
    async (id: string): Promise<boolean> => {
      if (!user) return false;
      const target = state.students.find((s) => s.id === id);
      try {
        await supabaseRepository.deleteStudent(user.id, id);
        setState((prev) => ({
          ...prev,
          students: prev.students.filter((s) => s.id !== id),
          submissions: prev.submissions.filter((sub) => sub.studentId !== id),
          activities: target
            ? pushActivity(
                prev,
                actorName,
                'حذف طالب',
                `${target.name} (${target.code})`,
                'student'
              )
            : prev.activities,
        }));
        showToast('تم حذف سجل الطالب وإجاباته المرتبطة');
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر حذف الطالب.'), 'error');
        return false;
      }
    },
    [user, state.students, actorName, showToast]
  );

  // --- Groups CRUD ---
  const addGroup = useCallback(
    async (groupData: Omit<StudyGroup, 'id'>): Promise<boolean> => {
      if (!user) return false;
      try {
        const created = await supabaseRepository.createGroup(user.id, groupData);
        setState((prev) => ({
          ...prev,
          groups: [created, ...prev.groups],
          activities: pushActivity(
            prev,
            actorName,
            'إنشاء مجموعة جديدة',
            created.name,
            'system'
          ),
        }));
        showToast(`تم إنشاء المجموعة "${created.name}"`);
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر إنشاء المجموعة.'), 'error');
        return false;
      }
    },
    [user, actorName, showToast]
  );

  const updateGroup = useCallback(
    async (id: string, updates: Partial<Omit<StudyGroup, 'id'>>): Promise<boolean> => {
      if (!user) return false;
      const existing = state.groups.find((g) => g.id === id);
      if (!existing) return false;
      const merged: StudyGroup = { ...existing, ...updates };
      try {
        const updated = await supabaseRepository.updateGroup(user.id, id, merged);
        setState((prev) => ({
          ...prev,
          groups: prev.groups.map((g) => (g.id === id ? updated : g)),
          // Keep derived subjectId on students in sync when a group's subject changes
          students: prev.students.map((st) =>
            st.groupId === id ? { ...st, subjectId: updated.subjectId } : st
          ),
          activities: pushActivity(
            prev,
            actorName,
            'تحديث بيانات مجموعة',
            updated.name,
            'system'
          ),
        }));
        showToast('تم تحديث بيانات المجموعة');
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر تحديث بيانات المجموعة.'), 'error');
        return false;
      }
    },
    [user, state.groups, actorName, showToast]
  );

  const deleteGroup = useCallback(
    async (id: string): Promise<boolean> => {
      if (!user) return false;
      const target = state.groups.find((g) => g.id === id);
      try {
        await supabaseRepository.deleteGroup(user.id, id);
        setState((prev) => ({
          ...prev,
          groups: prev.groups.filter((g) => g.id !== id),
          activities: target
            ? pushActivity(prev, actorName, 'حذف مجموعة', target.name, 'system')
            : prev.activities,
        }));
        showToast('تم حذف المجموعة');
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر حذف المجموعة.'), 'error');
        return false;
      }
    },
    [user, state.groups, actorName, showToast]
  );

  // --- Subjects CRUD ---
  const addSubject = useCallback(
    async (subjectData: Omit<Subject, 'id'>): Promise<boolean> => {
      if (!user) return false;
      try {
        const created = await supabaseRepository.createSubject(user.id, subjectData);
        setState((prev) => ({
          ...prev,
          subjects: [created, ...prev.subjects],
          teachers: prev.teachers.map((t) =>
            t.id === user.id && !t.subjectIds.includes(created.id)
              ? { ...t, subjectIds: [...t.subjectIds, created.id] }
              : t
          ),
          activities: pushActivity(
            prev,
            actorName,
            'إضافة مادة دراسية',
            created.name,
            'system'
          ),
        }));
        showToast(`تمت إضافة مادة "${created.name}"`);
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر إضافة المادة الدراسية.'), 'error');
        return false;
      }
    },
    [user, actorName, showToast]
  );

  const updateSubject = useCallback(
    async (id: string, updates: Partial<Omit<Subject, 'id'>>): Promise<boolean> => {
      if (!user) return false;
      const existing = state.subjects.find((s) => s.id === id);
      if (!existing) return false;
      const merged: Subject = { ...existing, ...updates };
      try {
        const updated = await supabaseRepository.updateSubject(user.id, id, merged);
        setState((prev) => ({
          ...prev,
          subjects: prev.subjects.map((s) => (s.id === id ? updated : s)),
          activities: pushActivity(
            prev,
            actorName,
            'تحديث مادة دراسية',
            updated.name,
            'system'
          ),
        }));
        showToast('تم تحديث بيانات المادة الدراسية');
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر تحديث المادة الدراسية.'), 'error');
        return false;
      }
    },
    [user, state.subjects, actorName, showToast]
  );

  const deleteSubject = useCallback(
    async (id: string): Promise<boolean> => {
      if (!user) return false;
      const target = state.subjects.find((s) => s.id === id);
      try {
        await supabaseRepository.deleteSubject(user.id, id);
        setState((prev) => ({
          ...prev,
          subjects: prev.subjects.filter((s) => s.id !== id),
          teachers: prev.teachers.map((t) => ({
            ...t,
            subjectIds: t.subjectIds.filter((sid) => sid !== id),
          })),
          activities: target
            ? pushActivity(prev, actorName, 'حذف مادة دراسية', target.name, 'system')
            : prev.activities,
        }));
        showToast('تم حذف المادة الدراسية');
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر حذف المادة الدراسية.'), 'error');
        return false;
      }
    },
    [user, state.subjects, actorName, showToast]
  );

  // --- Assignments & Answer Keys CRUD ---
  const addAssignment = useCallback(
    async (
      assignmentData: Omit<Assignment, 'id' | 'createdAt'>
    ): Promise<Assignment | null> => {
      if (!user) return null;
      try {
        const created = await supabaseRepository.createAssignment(
          user.id,
          assignmentData
        );
        setState((prev) => ({
          ...prev,
          assignments: [created, ...prev.assignments],
          activities: pushActivity(
            prev,
            actorName,
            created.kind === 'exam' ? 'إنشاء امتحان جديد' : 'إنشاء واجب جديد',
            created.title,
            'assignment'
          ),
        }));
        showToast(`تم إنشاء "${created.title}" وحفظه في قاعدة البيانات`);
        return created;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر إنشاء الواجب أو الامتحان.'), 'error');
        return null;
      }
    },
    [user, actorName, showToast]
  );

  const updateAssignment = useCallback(
    async (
      id: string,
      updates: Partial<Omit<Assignment, 'id'>>
    ): Promise<boolean> => {
      if (!user) return false;
      const existing = state.assignments.find((a) => a.id === id);
      if (!existing) return false;

      const merged: Assignment = {
        ...existing,
        ...updates,
        questions: updates.questions ?? existing.questions,
      };
      if (updates.questions) {
        merged.totalMarks =
          updates.questions.reduce((sum, q) => sum + q.marks, 0) || merged.totalMarks;
      }

      try {
        const { assignment, updatedSubmissions } =
          await supabaseRepository.updateAssignment(
            user.id,
            id,
            merged,
            state.submissions
          );

        const updatedSubMap = new Map(updatedSubmissions.map((s) => [s.id, s]));

        setState((prev) => ({
          ...prev,
          assignments: prev.assignments.map((a) => (a.id === id ? assignment : a)),
          submissions: prev.submissions.map(
            (sub) => updatedSubMap.get(sub.id) ?? sub
          ),
          activities: pushActivity(
            prev,
            actorName,
            'تعديل واجب / امتحان',
            assignment.title,
            'assignment'
          ),
        }));
        showToast('تم تحديث بيانات الواجب وإعادة احتساب الدرجات المرتبطة');
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر تحديث الواجب.'), 'error');
        return false;
      }
    },
    [user, state.assignments, state.submissions, actorName, showToast]
  );

  const deleteAssignment = useCallback(
    async (id: string): Promise<boolean> => {
      if (!user) return false;
      const target = state.assignments.find((a) => a.id === id);
      try {
        await supabaseRepository.deleteAssignment(user.id, id);
        setState((prev) => ({
          ...prev,
          assignments: prev.assignments.filter((a) => a.id !== id),
          submissions: prev.submissions.filter((sub) => sub.assignmentId !== id),
          activities: target
            ? pushActivity(
                prev,
                actorName,
                'حذف واجب / امتحان',
                target.title,
                'assignment'
              )
            : prev.activities,
        }));
        showToast('تم حذف الواجب والدرجات المرتبطة به');
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر حذف الواجب.'), 'error');
        return false;
      }
    },
    [user, state.assignments, actorName, showToast]
  );

  const updateAnswerKey = useCallback(
    async (
      assignmentId: string,
      keyMap: Record<string, MCQOptionKey>
    ): Promise<boolean> => {
      if (!user) return false;
      const target = state.assignments.find((a) => a.id === assignmentId);
      if (!target) return false;

      const updatedQuestions = target.questions.map((q) => ({
        ...q,
        correctOption: keyMap[q.id] ?? q.correctOption,
      }));
      const updatedAssignment: Assignment = {
        ...target,
        questions: updatedQuestions,
      };

      try {
        await supabaseRepository.upsertAnswerKeyQuestions(
          user.id,
          assignmentId,
          updatedQuestions
        );
        const regraded = await supabaseRepository.regradeAssignmentSubmissions(
          user.id,
          updatedAssignment,
          state.submissions
        );
        const regradedMap = new Map(regraded.map((s) => [s.id, s]));

        setState((prev) => ({
          ...prev,
          assignments: prev.assignments.map((a) =>
            a.id === assignmentId ? updatedAssignment : a
          ),
          submissions: prev.submissions.map((sub) => regradedMap.get(sub.id) ?? sub),
          activities: pushActivity(
            prev,
            actorName,
            'تحديث نموذج الإجابة وإعادة التصحيح',
            updatedAssignment.title,
            'assignment'
          ),
        }));
        showToast('تم حفظ نموذج الإجابة وتحديث جميع درجات الطلاب تلقائياً');
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر حفظ نموذج الإجابة.'), 'error');
        return false;
      }
    },
    [user, state.assignments, state.submissions, actorName, showToast]
  );

  // --- Grading / Submissions CRUD ---
  const saveSubmission = useCallback(
    async (
      assignmentId: string,
      studentId: string,
      answers: Record<string, MCQOptionKey | null>,
      notes?: string
    ): Promise<StudentSubmission | null> => {
      if (!user) return null;
      const assignment = state.assignments.find((a) => a.id === assignmentId);
      const student = state.students.find((s) => s.id === studentId);
      if (!assignment || !student) return null;

      const existing = state.submissions.find(
        (s) => s.assignmentId === assignmentId && s.studentId === studentId
      );

      try {
        const saved = await supabaseRepository.saveSubmission(
          user.id,
          assignment,
          studentId,
          answers,
          notes,
          existing?.id
        );

        setState((prev) => {
          const others = prev.submissions.filter((s) => s.id !== saved.id);
          return {
            ...prev,
            submissions: [saved, ...others],
            activities: pushActivity(
              prev,
              actorName,
              `رصد درجة (${saved.earnedMarks}/${saved.totalMarks})`,
              `${student.name} — ${assignment.title}`,
              'grading'
            ),
          };
        });

        showToast(
          `تم حفظ التصحيح للطالب ${student.name}: ${saved.earnedMarks} من ${saved.totalMarks} (${saved.percentage}%)`
        );
        return saved;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر حفظ نتيجة التصحيح.'), 'error');
        return null;
      }
    },
    [user, state.assignments, state.students, state.submissions, actorName, showToast]
  );

  const deleteSubmission = useCallback(
    async (submissionId: string): Promise<boolean> => {
      if (!user) return false;
      const target = state.submissions.find((s) => s.id === submissionId);
      const student = target
        ? state.students.find((st) => st.id === target.studentId)
        : undefined;

      try {
        await supabaseRepository.deleteSubmission(user.id, submissionId);
        setState((prev) => ({
          ...prev,
          submissions: prev.submissions.filter((s) => s.id !== submissionId),
          activities: target
            ? pushActivity(
                prev,
                actorName,
                'حذف سجل تصحيح',
                student ? `${student.name} (${student.code})` : target.id,
                'grading'
              )
            : prev.activities,
        }));
        showToast('تم حذف سجل التصحيح');
        return true;
      } catch (err) {
        showToast(translateSupabaseError(err, 'تعذر حذف سجل التصحيح.'), 'error');
        return false;
      }
    },
    [user, state.submissions, state.students, actorName, showToast]
  );

  return (
    <MeyarContext.Provider
      value={{
        state,
        currentTeacher,
        isLoading,
        isSyncing,
        loadError,
        refreshData,
        activeSection,
        navPayload,
        navigate,
        clearNavPayload,
        toastMessage: toast?.message ?? null,
        toastVariant: toast?.variant ?? 'default',
        showToast,
        addTeacher,
        updateTeacher,
        deleteTeacher,
        addStudent,
        updateStudent,
        deleteStudent,
        generateNextStudentCode,
        addGroup,
        updateGroup,
        deleteGroup,
        addSubject,
        updateSubject,
        deleteSubject,
        addAssignment,
        updateAssignment,
        deleteAssignment,
        updateAnswerKey,
        saveSubmission,
        deleteSubmission,
      }}
    >
      {children}
    </MeyarContext.Provider>
  );
};

export function useMeyar(): MeyarContextValue {
  const ctx = useContext(MeyarContext);
  if (!ctx) {
    throw new Error('useMeyar must be used within MeyarProvider');
  }
  return ctx;
}
