import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import {
  isSupabaseConfigured,
  supabase,
  supabaseInitError,
  translateSupabaseError,
} from '../lib/supabase';
import { supabaseRepository } from '../services/supabaseRepository';

interface SignUpPayload {
  fullName: string;
  email: string;
  password: string;
  phone?: string;
  specialty?: string;
}

interface AuthActionResult {
  error: string | null;
  needsEmailConfirmation?: boolean;
}

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<AuthActionResult>;
  signUp: (payload: SignUpPayload) => Promise<AuthActionResult>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(isSupabaseConfigured);

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }

    let isMounted = true;

    // Safety guard so restricted mobile browsers never stall indefinitely on loading screen
    const fallbackTimer = window.setTimeout(() => {
      if (isMounted) {
        setLoading(false);
      }
    }, 6000);

    supabase.auth
      .getSession()
      .then(({ data, error }) => {
        if (!isMounted) return;
        window.clearTimeout(fallbackTimer);
        if (error) {
          console.error('[MEYAR Auth] getSession error:', error);
        }
        setSession(data?.session ?? null);
        setLoading(false);
      })
      .catch((err) => {
        if (!isMounted) return;
        window.clearTimeout(fallbackTimer);
        console.error('[MEYAR Auth] getSession exception:', err);
        setSession(null);
        setLoading(false);
      });

    let subscription: { unsubscribe: () => void } | null = null;
    try {
      const listener = supabase.auth.onAuthStateChange((_event, nextSession) => {
        if (!isMounted) return;
        window.clearTimeout(fallbackTimer);
        setSession(nextSession ?? null);
        setLoading(false);
      });
      subscription = listener.data.subscription;
    } catch (err) {
      console.error('[MEYAR Auth] onAuthStateChange setup error:', err);
      if (isMounted) {
        setLoading(false);
      }
    }

    return () => {
      isMounted = false;
      window.clearTimeout(fallbackTimer);
      subscription?.unsubscribe();
    };
  }, []);

  const signIn = useCallback(
    async (email: string, password: string): Promise<AuthActionResult> => {
      if (!isSupabaseConfigured) {
        return {
          error:
            supabaseInitError ||
            'لم يتم ضبط متغيرات اتصال Supabase (VITE_SUPABASE_URL و VITE_SUPABASE_PUBLISHABLE_KEY).',
        };
      }

      try {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });

        if (error) {
          console.error('[MEYAR Auth] signInWithPassword error:', error);
          return { error: translateSupabaseError(error, 'تعذر تسجيل الدخول.') };
        }

        if (!data?.session || !data?.user) {
          return {
            error: 'لم يتم إنشاء جلسة تسجيل دخول من Supabase. يرجى المحاولة مرة أخرى.',
          };
        }

        setSession(data.session);

        try {
          await supabaseRepository.ensureTeacherProfile(data.user);
        } catch (profileError) {
          console.error('[MEYAR Auth] ensureTeacherProfile error:', profileError);
        }

        return { error: null };
      } catch (err) {
        console.error('[MEYAR Auth] signInWithPassword exception:', err);
        return { error: translateSupabaseError(err, 'تعذر تسجيل الدخول.') };
      }
    },
    []
  );

  const signUp = useCallback(async (payload: SignUpPayload): Promise<AuthActionResult> => {
    if (!isSupabaseConfigured) {
      return {
        error:
          supabaseInitError ||
          'لم يتم ضبط متغيرات اتصال Supabase (VITE_SUPABASE_URL و VITE_SUPABASE_PUBLISHABLE_KEY).',
      };
    }

    const cleanEmail = payload.email.trim();
    const cleanName = payload.fullName.trim();
    const cleanPhone = payload.phone?.trim() ?? '';
    const cleanSpecialty = payload.specialty?.trim() || 'تعليم عام';

    try {
      const emailRedirectTo =
        typeof window !== 'undefined' ? window.location.origin : undefined;
      const { data, error } = await supabase.auth.signUp({
        email: cleanEmail,
        password: payload.password,
        options: {
          emailRedirectTo,
          data: {
            full_name: cleanName,
            phone: cleanPhone,
            specialty: cleanSpecialty,
          },
        },
      });

      if (error) {
        console.error('[MEYAR Auth] signUp error:', error);
        return { error: translateSupabaseError(error, 'تعذر إنشاء الحساب الجديد.') };
      }

      if (!data?.user) {
        return {
          error: 'لم يتم استلام بيانات الحساب الجديد من Supabase. يرجى المحاولة مرة أخرى.',
        };
      }

      if (data.session) {
        setSession(data.session);
        try {
          await supabaseRepository.ensureTeacherProfile(data.user);
        } catch (profileError) {
          console.error('[MEYAR Auth] ensureTeacherProfile after signUp error:', profileError);
        }
        return { error: null, needsEmailConfirmation: false };
      }

      return { error: null, needsEmailConfirmation: true };
    } catch (err) {
      console.error('[MEYAR Auth] signUp exception:', err);
      return { error: translateSupabaseError(err, 'تعذر إنشاء الحساب الجديد.') };
    }
  }, []);

  const signOut = useCallback(async () => {
    try {
      await supabase.auth.signOut();
    } catch (err) {
      console.error('[MEYAR Auth] signOut exception:', err);
    } finally {
      setSession(null);
    }
  }, []);

  return (
    <AuthContext.Provider
      value={{
        session,
        user: session?.user ?? null,
        loading,
        signIn,
        signUp,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return ctx;
}
