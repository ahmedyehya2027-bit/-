import React from 'react';
import { createPortal } from 'react-dom';
import type { Assignment, StudentSubmission } from '../types/domain';
import {
  formatArabicDate,
  getPerformanceBand,
  type StudentPerformanceSummary,
} from '../utils/grading';

interface PrintHeaderProps {
  title: string;
  subtitle?: string;
  filterSummary?: string;
  metrics?: Array<{ label: string; value: string }>;
}

/**
 * Official Arabic RTL A4 Print Header & Letterhead (visible only when printing).
 */
export const PrintDocumentHeader: React.FC<PrintHeaderProps> = ({
  title,
  subtitle,
  filterSummary,
  metrics,
}) => {
  const printedDate = new Intl.DateTimeFormat('ar-EG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date());

  return (
    <div className="print-only mb-6 pb-4 border-b-2 border-slate-800">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-teal-700 text-white flex items-center justify-center font-bold text-lg">
            م
          </div>
          <div>
            <div className="text-base font-bold text-slate-900">
              مِعيار <span className="text-slate-400 font-normal">|</span>{' '}
              <span className="font-mono text-xs text-teal-800">ME&apos;YAR</span>
            </div>
            <div className="text-xs text-slate-500">
              منصة إدارة التعليم وتصحيح الاختبارات وتحليل النتائج
            </div>
          </div>
        </div>
        <div className="text-left text-xs text-slate-600">
          <div>تاريخ الطباعة: {printedDate}</div>
          <div className="text-slate-400 mt-0.5">نموذج طباعة معياري A4</div>
        </div>
      </div>

      <div className="mt-4 pt-3 border-t border-slate-200">
        <h1 className="text-xl font-bold text-slate-900">{title}</h1>
        {subtitle && <p className="text-xs text-slate-600 mt-0.5">{subtitle}</p>}
        {filterSummary && (
          <p className="text-xs text-slate-700 mt-1.5 font-medium">
            نطاق التقرير: {filterSummary}
          </p>
        )}
      </div>

      {metrics && metrics.length > 0 && (
        <div className="mt-4 grid grid-cols-4 gap-3 border border-slate-300 rounded-lg p-3 bg-slate-50">
          {metrics.map((m) => (
            <div key={m.label}>
              <div className="text-[10pt] text-slate-500">{m.label}</div>
              <div className="text-sm font-bold font-mono tabular-nums text-slate-900 mt-0.5">
                {m.value}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/**
 * Official Arabic RTL A4 Print Footer with academic verification signature lines.
 */
export const PrintDocumentFooter: React.FC<{ note?: string }> = ({ note }) => {
  return (
    <div className="print-only mt-8 pt-4 border-t border-slate-300 print-avoid-break">
      <div className="grid grid-cols-3 gap-6 text-xs text-slate-700 mb-4">
        <div>
          <div className="font-semibold mb-6">اعتماد المدرس:</div>
          <div className="border-b border-slate-400 w-40" />
        </div>
        <div>
          <div className="font-semibold mb-6">مراجعة الإدارة الأكاديمية:</div>
          <div className="border-b border-slate-400 w-40" />
        </div>
        <div>
          <div className="font-semibold mb-6">تاريخ التسليم:</div>
          <div className="border-b border-slate-400 w-32" />
        </div>
      </div>
      <div className="flex items-center justify-between text-[9pt] text-slate-500 pt-2 border-t border-slate-200">
        <span>تم إصدار هذا التقرير عبر منصة مِعيار | ME&apos;YAR</span>
        <span>{note ?? 'بيانات محلية تجريبية — للاستخدام الأكاديمي'}</span>
      </div>
    </div>
  );
};

interface StudentA4SheetProps {
  summary: StudentPerformanceSummary;
  submissions: Array<{ sub: StudentSubmission; assignment?: Assignment }>;
}

/**
 * Dedicated printable A4 Individual Student Academic Report Card (portaled to document.body).
 */
export const StudentA4ReportSheet: React.FC<StudentA4SheetProps> = ({
  summary,
  submissions,
}) => {
  const band =
    summary.averagePercentage !== null
      ? getPerformanceBand(summary.averagePercentage)
      : null;

  if (typeof document === 'undefined') return null;

  return createPortal(
    <div className="print-single-sheet-root hidden" dir="rtl">
      <PrintDocumentHeader
        title={`التقرير الأكاديمي الفردي للطالب: ${summary.student.name}`}
        subtitle={`كود الطالب: ${summary.student.code} · تاريخ التسجيل: ${formatArabicDate(summary.student.enrolledAt)}`}
        filterSummary={`${summary.groupName} · ${summary.teacherName} · ${summary.subjectName}`}
        metrics={[
          {
            label: 'المتوسط العام',
            value:
              summary.averagePercentage !== null ? `${summary.averagePercentage}%` : '—',
          },
          {
            label: 'التقدير العام',
            value: band ? band.label : 'لم يُقيّم',
          },
          {
            label: 'أعلى / أدنى نسبة',
            value:
              summary.highestPercentage !== null && summary.lowestPercentage !== null
                ? `${summary.highestPercentage}% / ${summary.lowestPercentage}%`
                : '—',
          },
          {
            label: 'الاختبارات المصححة',
            value: String(summary.gradedCount),
          },
        ]}
      />

      <div className="mb-5 grid grid-cols-2 gap-4 text-xs border border-slate-300 rounded-lg p-4">
        <div>
          <span className="text-slate-500">اسم الطالب: </span>
          <strong className="text-slate-900">{summary.student.name}</strong>
        </div>
        <div>
          <span className="text-slate-500">الكود التعريفي: </span>
          <strong className="font-mono text-slate-900">{summary.student.code}</strong>
        </div>
        <div>
          <span className="text-slate-500">المجموعة الدراسية: </span>
          <strong className="text-slate-900">{summary.groupName}</strong>
        </div>
        <div>
          <span className="text-slate-500">المدرس المسؤول: </span>
          <strong className="text-slate-900">{summary.teacherName}</strong>
        </div>
        <div>
          <span className="text-slate-500">المادة الدراسية: </span>
          <strong className="text-slate-900">{summary.subjectName}</strong>
        </div>
        <div>
          <span className="text-slate-500">هاتف ولي الأمر: </span>
          <strong className="font-mono text-slate-900">
            {summary.student.guardianPhone || '—'}
          </strong>
        </div>
      </div>

      <h2 className="text-sm font-bold text-slate-900 mb-3">
        تفاصيل نتائج الواجبات والامتحانات
      </h2>

      {submissions.length === 0 ? (
        <p className="text-xs text-slate-600 border border-slate-300 rounded-lg p-4 text-center">
          لا توجد اختبارات مصححة مسجلة لهذا الطالب حتى تاريخ الطباعة.
        </p>
      ) : (
        <table className="w-full text-right">
          <thead>
            <tr>
              <th>العنوان</th>
              <th>النوع</th>
              <th>تاريخ التصحيح</th>
              <th>صحيح / خطأ</th>
              <th>الدرجة</th>
              <th>النسبة</th>
              <th>التقدير</th>
            </tr>
          </thead>
          <tbody>
            {submissions.map(({ sub, assignment }) => {
              const subBand = getPerformanceBand(sub.percentage);
              return (
                <tr key={sub.id}>
                  <td className="font-semibold">
                    <div>{assignment?.title ?? 'اختبار'}</div>
                    {sub.notes && (
                      <div className="text-[8.5pt] text-slate-500 font-normal mt-0.5">
                        ملاحظة: {sub.notes}
                      </div>
                    )}
                  </td>
                  <td>
                    {assignment
                      ? assignment.kind === 'exam'
                        ? 'امتحان'
                        : 'واجب'
                      : '—'}
                  </td>
                  <td>{formatArabicDate(sub.gradedAt)}</td>
                  <td className="font-mono tabular-nums">
                    {sub.correctCount} / {sub.wrongCount}
                  </td>
                  <td className="font-mono tabular-nums font-bold">
                    {sub.earnedMarks} / {sub.totalMarks}
                  </td>
                  <td className="font-mono tabular-nums font-bold">{sub.percentage}%</td>
                  <td className={`font-semibold ${subBand.textClass}`}>{subBand.label}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}

      {summary.student.notes && (
        <div className="mt-5 p-3 border border-slate-300 rounded-lg text-xs">
          <strong className="text-slate-900">ملاحظات أكاديمية: </strong>
          <span className="text-slate-700">{summary.student.notes}</span>
        </div>
      )}

      <PrintDocumentFooter />
    </div>,
    document.body
  );
};

/**
 * Helper to trigger isolated single-sheet A4 print and reliably clean up body class afterward.
 */
export function triggerSingleSheetPrint(onComplete?: () => void): void {
  document.body.classList.add('printing-single-sheet');
  let cleaned = false;
  const cleanup = () => {
    if (cleaned) return;
    cleaned = true;
    document.body.classList.remove('printing-single-sheet');
    window.removeEventListener('afterprint', cleanup);
    onComplete?.();
  };
  window.addEventListener('afterprint', cleanup);
  window.setTimeout(() => {
    window.print();
    // Fallback cleanup for browsers that don't always fire afterprint synchronously
    window.setTimeout(cleanup, 1000);
  }, 60);
}
