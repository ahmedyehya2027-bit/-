import React from 'react';
import { AlertTriangle, RefreshCw, RotateCcw } from 'lucide-react';

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  componentStack: string | null;
}

/**
 * Top-level React ErrorBoundary for ME'YAR.
 * Prevents a blank white screen by displaying a clear Arabic error diagnostic
 * panel with one-tap recovery actions whenever an unexpected runtime error occurs.
 */
export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      componentStack: null,
    };
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return {
      hasError: true,
      error,
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void {
    console.error('[MEYAR ErrorBoundary] Uncaught error:', error, errorInfo);
    this.setState({
      componentStack: errorInfo.componentStack ?? null,
    });
  }

  private handleReload = (): void => {
    window.location.reload();
  };

  private handleClearSessionAndReload = (): void => {
    try {
      Object.keys(window.localStorage)
        .filter((k) => k.startsWith('sb-') || k.startsWith('meyar'))
        .forEach((k) => window.localStorage.removeItem(k));
    } catch {
      // Ignore storage access errors in restricted browsers
    }
    window.location.reload();
  };

  render(): React.ReactNode {
    if (!this.state.hasError) {
      return this.props.children;
    }

    const errorName = this.state.error?.name || 'RuntimeError';
    const errorMessage =
      this.state.error?.message || 'حدث خطأ غير متوقع أثناء تحميل واجهة المنصة.';

    return (
      <div
        dir="rtl"
        className="min-h-screen bg-slate-50 text-slate-900 flex items-center justify-center p-4 sm:p-6"
      >
        <div className="w-full max-w-lg bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          <div className="bg-red-50 border-b border-red-100 px-6 py-4 flex items-center gap-3">
            <span className="w-10 h-10 rounded-lg bg-red-100 text-red-700 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </span>
            <div>
              <h1 className="text-base font-bold text-red-900">
                تعذر عرض الصفحة بسبب خطأ غير متوقع
              </h1>
              <p className="text-xs text-red-700 mt-0.5">
                تم إيقاف التحميل لحماية بياناتك. يمكنك إعادة المحاولة من الأزرار بالأسفل.
              </p>
            </div>
          </div>

          <div className="p-6 space-y-4">
            <div className="space-y-1.5">
              <div className="text-xs font-semibold text-slate-700">تفاصيل الخطأ:</div>
              <div
                dir="ltr"
                className="p-3 rounded-lg bg-slate-900 text-slate-100 font-mono text-xs leading-relaxed break-words overflow-x-auto"
              >
                <span className="text-red-300 font-semibold">{errorName}: </span>
                <span>{errorMessage}</span>
              </div>
            </div>

            {(this.state.error?.stack || this.state.componentStack) && (
              <details className="text-xs text-slate-600 border border-slate-200 rounded-lg p-3 bg-slate-50">
                <summary className="cursor-pointer font-semibold text-slate-700 select-none">
                  عرض التفاصيل التقنية (للمساعدة في التشخيص)
                </summary>
                <pre
                  dir="ltr"
                  className="mt-2.5 text-[11px] font-mono text-slate-700 whitespace-pre-wrap break-words max-h-48 overflow-y-auto"
                >
                  {[this.state.error?.stack, this.state.componentStack]
                    .filter(Boolean)
                    .join('\n\n')}
                </pre>
              </details>
            )}

            <div className="flex flex-col sm:flex-row gap-2.5 pt-1">
              <button
                type="button"
                onClick={this.handleReload}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                <span>إعادة تحميل الصفحة</span>
              </button>
              <button
                type="button"
                onClick={this.handleClearSessionAndReload}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>مسح الجلسة وإعادة المحاولة</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
