import React, { useState } from 'react';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  Layers,
  BookOpen,
  FileText,
  KeyRound,
  CheckSquare,
  BarChart3,
  FileSpreadsheet,
  Menu,
  X,
  Plus,
  LogOut,
  RefreshCw,
  Loader2,
  AlertCircle,
} from 'lucide-react';
import type { NavSectionId } from '../types/domain';
import { useMeyar } from '../context/MeyarContext';
import { useAuth } from '../context/AuthContext';

interface NavItem {
  id: NavSectionId;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

interface NavGroup {
  heading: string;
  items: NavItem[];
}

export const NAV_GROUPS: NavGroup[] = [
  {
    heading: 'نظرة عامة',
    items: [{ id: 'dashboard', label: 'لوحة التحكم', icon: LayoutDashboard }],
  },
  {
    heading: 'الإدارة الأكاديمية',
    items: [
      { id: 'teachers', label: 'إدارة المدرسين', icon: GraduationCap },
      { id: 'students', label: 'إدارة الطلاب', icon: Users },
      { id: 'groups', label: 'إدارة المجموعات', icon: Layers },
      { id: 'subjects', label: 'المواد الدراسية', icon: BookOpen },
    ],
  },
  {
    heading: 'التقييم والتصحيح',
    items: [
      { id: 'assignments', label: 'الواجبات والامتحانات', icon: FileText },
      { id: 'answer-keys', label: 'نماذج الإجابة', icon: KeyRound },
      { id: 'grading', label: 'تصحيح الإجابات', icon: CheckSquare },
    ],
  },
  {
    heading: 'النتائج والتقارير',
    items: [
      { id: 'analytics', label: 'تحليل أداء الطلاب', icon: BarChart3 },
      { id: 'reports', label: 'التقارير', icon: FileSpreadsheet },
    ],
  },
];

const SECTION_TITLES: Record<NavSectionId, string> = {
  dashboard: 'لوحة التحكم',
  teachers: 'إدارة المدرسين',
  students: 'إدارة الطلاب',
  groups: 'إدارة المجموعات',
  subjects: 'المواد الدراسية',
  assignments: 'الواجبات والامتحانات',
  'answer-keys': 'نماذج الإجابة',
  grading: 'تصحيح الإجابات',
  analytics: 'تحليل أداء الطلاب',
  reports: 'التقارير',
};

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const {
    activeSection,
    navigate,
    toastMessage,
    toastVariant,
    currentTeacher,
    isLoading,
    isSyncing,
    loadError,
    refreshData,
  } = useMeyar();
  const { user, signOut } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [signingOut, setSigningOut] = useState(false);

  const handleSelectNav = (id: NavSectionId) => {
    navigate(id);
    setMobileMenuOpen(false);
  };

  const handleSignOut = async () => {
    setSigningOut(true);
    try {
      await signOut();
    } finally {
      setSigningOut(false);
    }
  };

  const teacherDisplayName =
    currentTeacher?.name ||
    (typeof user?.user_metadata?.full_name === 'string' &&
      user.user_metadata.full_name) ||
    user?.email?.split('@')[0] ||
    'المدرس';

  const sidebarContent = (
    <div className="flex flex-col h-full bg-white border-l border-slate-200">
      {/* Brand Header */}
      <div className="h-16 px-5 flex items-center justify-between border-b border-slate-200 shrink-0">
        <button
          type="button"
          onClick={() => handleSelectNav('dashboard')}
          className="flex items-center gap-3 text-right focus-visible:outline-2 focus-visible:outline-teal-600 rounded-md"
        >
          <span className="w-8 h-8 rounded-lg bg-teal-700 text-white flex items-center justify-center font-bold text-base shrink-0">
            م
          </span>
          <span className="font-bold text-slate-900 text-base tracking-tight whitespace-nowrap shrink-0">
            مِعيار <span className="text-slate-400 font-normal mx-0.5">|</span>{' '}
            <span className="font-mono text-xs font-semibold text-teal-800 tracking-wider">
              ME&apos;YAR
            </span>
          </span>
        </button>

        <button
          type="button"
          onClick={() => setMobileMenuOpen(false)}
          className="lg:hidden p-2 text-slate-500 hover:text-slate-900 rounded-lg"
          aria-label="إغلاق القائمة"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-6" aria-label="التنقل الرئيسي">
        {NAV_GROUPS.map((group) => (
          <div key={group.heading}>
            <div className="px-3 mb-2 text-xs font-semibold text-slate-400">
              {group.heading}
            </div>
            <ul className="space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                return (
                  <li key={item.id}>
                    <button
                      type="button"
                      onClick={() => handleSelectNav(item.id)}
                      aria-current={isActive ? 'page' : undefined}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors whitespace-nowrap focus-visible:outline-2 focus-visible:outline-teal-600 ${
                        isActive
                          ? 'bg-teal-50 text-teal-800 font-semibold'
                          : 'text-slate-600 hover:bg-slate-100/80 hover:text-slate-900 font-medium'
                      }`}
                    >
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          isActive ? 'text-teal-700' : 'text-slate-400'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      {/* Sidebar Footer — Authenticated Teacher Account & Actions */}
      <div className="p-4 border-t border-slate-200 shrink-0 space-y-3">
        <div className="min-w-0">
          <p className="text-xs font-bold text-slate-900 truncate">{teacherDisplayName}</p>
          <p className="text-[11px] text-slate-500 font-mono truncate mt-0.5" dir="ltr">
            {user?.email ?? ''}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={isSyncing || isLoading}
            onClick={() => void refreshData()}
            className="flex-1 inline-flex items-center justify-center gap-1.5 px-2.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap disabled:opacity-50"
            title="تحديث البيانات"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>تحديث</span>
          </button>
          <button
            type="button"
            disabled={signingOut}
            onClick={() => void handleSignOut()}
            className="flex-1 inline-flex items-center justify-center gap-1.5 px-2.5 py-2 text-xs font-medium text-red-700 hover:text-red-800 border border-red-200 hover:bg-red-50 rounded-lg transition-colors whitespace-nowrap disabled:opacity-50"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{signingOut ? 'خروج...' : 'خروج'}</span>
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex print-app-shell">
      {/* Desktop Fixed Sidebar (RTL right side) */}
      <aside className="hidden lg:block w-64 shrink-0 fixed inset-y-0 right-0 z-30 no-print">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer Overlay */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-40 lg:hidden bg-slate-900/40 no-print"
          onClick={() => setMobileMenuOpen(false)}
        >
          <aside
            className="fixed inset-y-0 right-0 w-72 max-w-[85vw] shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            {sidebarContent}
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 lg:mr-64 print-main-shell">
        {/* Clean Contextual Top Bar */}
        <header className="sticky top-0 z-20 h-16 bg-white/95 backdrop-blur-xs border-b border-slate-200 px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4 no-print">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 -mr-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
              aria-label="فتح القائمة الجانبية"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="text-slate-400 hidden sm:inline whitespace-nowrap">مِعيار</span>
              <span className="text-slate-300 hidden sm:inline" aria-hidden="true">
                /
              </span>
              <h1 className="text-base sm:text-lg font-bold text-slate-900 truncate">
                {SECTION_TITLES[activeSection]}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {activeSection !== 'grading' ? (
              <button
                type="button"
                onClick={() => navigate('grading')}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-teal-600"
              >
                <CheckSquare className="w-4 h-4" />
                <span>تصحيح إجابات</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => navigate('assignments')}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-teal-600"
              >
                <Plus className="w-4 h-4" />
                <span>إنشاء اختبار</span>
              </button>
            )}
          </div>
        </header>

        {/* Page Viewport */}
        <main className="flex-1 w-full max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          {loadError && (
            <div
              role="alert"
              className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-800 no-print"
            >
              <div className="flex items-start gap-2.5">
                <AlertCircle className="w-5 h-5 shrink-0 text-red-600 mt-0.5" />
                <span>{loadError}</span>
              </div>
              <button
                type="button"
                onClick={() => void refreshData()}
                className="px-3.5 py-1.5 text-xs font-semibold text-red-800 bg-white border border-red-200 hover:bg-red-100/60 rounded-lg whitespace-nowrap shrink-0"
              >
                إعادة المحاولة
              </button>
            </div>
          )}

          {isLoading ? (
            <div className="py-24 flex flex-col items-center justify-center gap-3 text-slate-500">
              <Loader2 className="w-7 h-7 text-teal-700 animate-spin" />
              <p className="text-sm font-medium">جاري تحميل بيانات المنصة...</p>
            </div>
          ) : (
            children
          )}
        </main>
      </div>

      {/* Live Feedback Toast */}
      {toastMessage && (
        <div
          role={toastVariant === 'error' ? 'alert' : 'status'}
          aria-live="polite"
          className={`fixed bottom-5 left-5 z-50 text-white text-sm px-4 py-3 rounded-lg shadow-lg border max-w-md no-print ${
            toastVariant === 'error'
              ? 'bg-red-800 border-red-700'
              : 'bg-slate-900 border-slate-700'
          }`}
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
};
