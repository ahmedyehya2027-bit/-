export type NavSectionId =
  | 'dashboard'
  | 'teachers'
  | 'students'
  | 'groups'
  | 'subjects'
  | 'assignments'
  | 'answer-keys'
  | 'grading'
  | 'analytics'
  | 'reports';

export type MCQOptionKey = 'A' | 'B' | 'C' | 'D';

export const MCQ_OPTION_LABELS: Record<MCQOptionKey, string> = {
  A: 'أ',
  B: 'ب',
  C: 'ج',
  D: 'د',
};

export interface Subject {
  id: string;
  name: string;
  code: string;
  stage: string;
  topics: string[];
  description: string;
}

export interface Teacher {
  id: string;
  name: string;
  email: string;
  phone: string;
  specialization: string;
  subjectIds: string[];
  joinedAt: string;
  active: boolean;
}

export interface StudyGroup {
  id: string;
  name: string;
  gradeLevel: string;
  teacherId: string;
  subjectId: string;
  schedule: string;
  capacity: number;
}

export interface Student {
  id: string;
  code: string;
  name: string;
  groupId: string;
  teacherId: string;
  subjectId: string;
  phone?: string;
  guardianPhone: string;
  enrolledAt: string;
  notes?: string;
}

export interface MCQQuestion {
  id: string;
  number: number;
  prompt: string;
  topic: string;
  marks: number;
  options: Record<MCQOptionKey, string>;
  correctOption: MCQOptionKey;
}

export type AssignmentKind = 'homework' | 'exam';

export interface Assignment {
  id: string;
  title: string;
  kind: AssignmentKind;
  teacherId: string;
  subjectId: string;
  groupId: string;
  totalMarks: number;
  deadline: string;
  createdAt: string;
  questions: MCQQuestion[];
}

export interface StudentSubmission {
  id: string;
  assignmentId: string;
  studentId: string;
  answers: Record<string, MCQOptionKey | null>;
  earnedMarks: number;
  totalMarks: number;
  percentage: number;
  correctCount: number;
  wrongCount: number;
  unansweredCount: number;
  gradedAt: string;
  notes?: string;
}

export interface ActivityEntry {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  target: string;
  category: 'student' | 'teacher' | 'assignment' | 'grading' | 'system';
}

export interface MeyarStateSnapshot {
  subjects: Subject[];
  teachers: Teacher[];
  groups: StudyGroup[];
  students: Student[];
  assignments: Assignment[];
  submissions: StudentSubmission[];
  activities: ActivityEntry[];
}
