import React, { useMemo, useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { useMeyar } from '../context/MeyarContext';
import {
  computeDifficultTopics,
  computeStudentSummaries,
  formatArabicDate,
  getPerformanceBand,
} from '../utils/grading';

export const AnalyticsPage: React.FC = () => {
  const { state } = useMeyar();
  const [subjectFilter, setSubjectFilter] = useState('all');
  const [groupFilter, setGroupFilter] = useState('all');

  const filteredAssignments = useMemo(() => {
    return state.assignments.filter((a) => {
      if (subjectFilter !== 'all' && a.subjectId !== subjectFilter) return false;
      if (groupFilter !== 'all' && a.groupId !== groupFilter) return false;
      return true;
    });
  }, [state.assignments, subjectFilter, groupFilter]);

  const filteredAssignmentIds = useMemo(
    () => new Set(filteredAssignments.map((a) => a.id)),
    [filteredAssignments]
  );

  const filteredSubmissions = useMemo(
    () => state.submissions.filter((s) => filteredAssignmentIds.has(s.assignmentId)),
    [state.submissions, filteredAssignmentIds]
  );

  const filteredStudents = useMemo(() => {
    return state.students.filter((st) => {
      if (subjectFilter !== 'all' && st.subjectId !== subjectFilter) return false;
      if (groupFilter !== 'all' && st.groupId !== groupFilter) return false;
      return true;
    });
  }, [state.students, subjectFilter, groupFilter]);

  // 1. Group Averages Data
  const groupAverages = useMemo(() => {
    return state.groups
      .filter((g) => {
        if (subjectFilter !== 'all' && g.subjectId !== subjectFilter) return false;
        if (groupFilter !== 'all' && g.id !== groupFilter) return false;
        return true;
      })
      .map((g) => {
        const gAsgIds = new Set(
          state.assignments.filter((a) => a.groupId === g.id).map((a) => a.id)
        );
        const subs = state.submissions.filter((s) => gAsgIds.has(s.assignmentId));
        const avg =
          subs.length > 0
            ? Math.round(
                (subs.reduce((acc, s) => acc + s.percentage, 0) / subs.length) * 10
              ) / 10
            : 0;
        const shortLabel = g.name.includes('—') ? g.name.split('—')[1].trim() : g.name;
        return {
          name: shortLabel,
          fullName: g.name,
          average: avg,
          count: subs.length,
        };
      });
  }, [state.groups, state.assignments, state.submissions, subjectFilter, groupFilter]);

  // 2. Progress Over Assessments (Chronological Line Chart)
  const progressData = useMemo(() => {
    return [...filteredAssignments]
      .sort((a, b) => a.deadline.localeCompare(b.deadline))
      .map((asg) => {
        const subs = filteredSubmissions.filter((s) => s.assignmentId === asg.id);
        const avg =
          subs.length > 0
            ? Math.round(
                (subs.reduce((acc, s) => acc + s.percentage, 0) / subs.length) * 10
              ) / 10
            : 0;
        return {
          title: asg.title.length > 22 ? `${asg.title.slice(0, 22)}...` : asg.title,
          fullTitle: asg.title,
          date: formatArabicDate(asg.deadline),
          average: avg,
          graded: subs.length,
        };
      })
      .filter((d) => d.graded > 0);
  }, [filteredAssignments, filteredSubmissions]);

  // 3. Difficult Topics
  const difficultTopics = useMemo(
    () =>
      computeDifficultTopics(filteredAssignments, filteredSubmissions, state.subjects),
    [filteredAssignments, filteredSubmissions, state.subjects]
  );

  // 4. Rankings
  const rankedStudents = useMemo(() => {
    const summaries = computeStudentSummaries(
      filteredStudents,
      filteredSubmissions,
      state.groups,
      state.teachers,
      state.subjects
    );
    return summaries
      .filter((s) => s.averagePercentage !== null)
      .sort((a, b) => (b.averagePercentage ?? 0) - (a.averagePercentage ?? 0));
  }, [filteredStudents, filteredSubmissions, state.groups, state.teachers, state.subjects]);

  const overviewStats = useMemo(() => {
    if (filteredSubmissions.length === 0) {
      return { avg: 0, passRate: 0, topScore: 0, totalGraded: 0 };
    }
    const avg =
      Math.round(
        (filteredSubmissions.reduce((acc, s) => acc + s.percentage, 0) /
          filteredSubmissions.length) *
          10
      ) / 10;
    const passed = filteredSubmissions.filter((s) => s.percentage >= 60).length;
    const passRate = Math.round((passed / filteredSubmissions.length) * 100);
    const topScore = Math.max(...filteredSubmissions.map((s) => s.percentage));
    return {
      avg,
      passRate,
      topScore,
      totalGraded: filteredSubmissions.length,
    };
  }, [filteredSubmissions]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">تحليل أداء الطلاب</h2>
          <p className="text-sm text-slate-500 mt-1">
            تحليلات فورية لمتوسطات المجموعات، الموضوعات الصعبة، ترتيب الطلاب، وتطور النتائج عبر الاختبارات.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            value={subjectFilter}
            onChange={(e) => {
              setSubjectFilter(e.target.value);
              setGroupFilter('all');
            }}
            aria-label="تصفية التحليلات حسب المادة"
            className="px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:border-teal-600"
          >
            <option value="all">كل المواد الدراسية</option>
            {state.subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
          <select
            value={groupFilter}
            onChange={(e) => setGroupFilter(e.target.value)}
            aria-label="تصفية التحليلات حسب المجموعة"
            className="px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:border-teal-600"
          >
            <option value="all">كل المجموعات</option>
            {state.groups
              .filter((g) => subjectFilter === 'all' || g.subjectId === subjectFilter)
              .map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name}
                </option>
              ))}
          </select>
        </div>
      </div>

      {/* Summary Strip */}
      <div className="bg-white border border-slate-200 rounded-xl grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x lg:divide-x-reverse divide-slate-200">
        <div className="p-5">
          <p className="text-xs text-slate-500">المتوسط العام المحدد</p>
          <p className="mt-1.5 text-2xl font-bold font-mono tabular-nums text-teal-800">
            {overviewStats.avg}%
          </p>
        </div>
        <div className="p-5">
          <p className="text-xs text-slate-500">نسبة النجاح (60% فأكثر)</p>
          <p className="mt-1.5 text-2xl font-bold font-mono tabular-nums text-emerald-700">
            {overviewStats.passRate}%
          </p>
        </div>
        <div className="p-5">
          <p className="text-xs text-slate-500">أعلى نسبة مسجلة</p>
          <p className="mt-1.5 text-2xl font-bold font-mono tabular-nums text-slate-900">
            {overviewStats.topScore}%
          </p>
        </div>
        <div className="p-5">
          <p className="text-xs text-slate-500">إجمالي الأوراق المحللة</p>
          <p className="mt-1.5 text-2xl font-bold font-mono tabular-nums text-slate-900">
            {overviewStats.totalGraded}
          </p>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Group Averages Chart */}
        <section className="bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="text-base font-bold text-slate-900">مقارنة متوسطات المجموعات</h3>
          <p className="text-xs text-slate-500 mt-0.5 mb-5">
            متوسط النسبة المئوية للدرجات داخل كل مجموعة دراسية
          </p>
          {groupAverages.length === 0 ? (
            <div className="h-64 flex items-center justify-center text-sm text-slate-400">
              لا توجد مجموعات متاحة ضمن التصفية المختارة.
            </div>
          ) : (
            <div className="h-64 w-full" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={groupAverages} margin={{ top: 8, right: 12, left: 0, bottom: 8 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                  <XAxis dataKey="name" tick={{ fill: '#475569', fontSize: 12 }} tickLine={false} />
                  <YAxis domain={[0, 100]} unit="%" tick={{ fill: '#64748B', fontSize: 12 }} tickLine={false} axisLine={false} />
                  <Tooltip
                    formatter={(v) => [`${v ?? 0}%`, 'المتوسط']}
                    labelFormatter={(_l, payload) => payload?.[0]?.payload?.fullName ?? ''}
                    contentStyle={{ borderRadius: '8px', border: '1px solid #E2E8F0', fontSize: '12px', direction: 'rtl', textAlign: 'right' }}
                  />
                  <Bar dataKey="average" fill="#0F766E" radius={[6, 6, 0, 0]} maxBarSize={42} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </section>

        {/* Progress Trend Line Chart */}
        <section className="bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="text-base font-bold text-slate-900">تطور الأداء عبر الاختبارات</h3>
          <p className="text-xs text-slate-500 mt-0.5 mb-5">
            تغير متوسط النتائج زمنياً حسب تاريخ كل اختبار أو واجب
          </p>
          {progressData.length === 0 ? (
            <div className="h-64 flex items-center justify-center text-sm text-slate-400">
              لا توجد بيانات اختبارات مصححة ضمن التصفية الحالية.
            </div>
          ) : (
            <div className="h-64 w-full" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={progressData} margin={{ top: 8, right: 16, left: 0, bottom: 8 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                  <XAxis dataKey="date" tick={{ fill: '#475569', fontSize: 12 }} tickLine={false} />
                  <YAxis domain={[0, 100]} unit="%" tick={{ fill: '#64748B', fontSize: 12 }} tickLine={false} axisLine={false} />
                  <Tooltip
                    formatter={(v) => [`${v ?? 0}%`, 'متوسط الاختبار']}
                    labelFormatter={(_l, payload) => payload?.[0]?.payload?.fullTitle ?? ''}
                    contentStyle={{ borderRadius: '8px', border: '1px solid #E2E8F0', fontSize: '12px', direction: 'rtl', textAlign: 'right' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="average"
                    stroke="#0F766E"
                    strokeWidth={2.5}
                    dot={{ r: 4, fill: '#0F766E' }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </section>
      </div>

      {/* Bottom Split: Student Rankings + Difficult Topics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Student Rankings */}
        <section className="lg:col-span-7 bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">ترتيب الطلاب حسب الأداء</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                مرتب تنازلياً وفق متوسط النسبة المئوية في الاختبارات المصححة
              </p>
            </div>
            <span className="text-xs text-slate-400 font-mono tabular-nums">
              {rankedStudents.length} طالب
            </span>
          </div>

          {rankedStudents.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              لا توجد نتائج طلاب ضمن معايير التصفية المختارة.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right text-sm">
                <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-5 font-medium">#</th>
                    <th className="py-3 px-4 font-medium">الطالب</th>
                    <th className="py-3 px-4 font-medium">المجموعة</th>
                    <th className="py-3 px-4 font-medium text-left">المتوسط</th>
                    <th className="py-3 px-4 font-medium text-left">التطور</th>
                    <th className="py-3 px-5 font-medium">التقدير</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/80">
                  {rankedStudents.map((item, index) => {
                    const avg = item.averagePercentage ?? 0;
                    const band = getPerformanceBand(avg);
                    return (
                      <tr key={item.student.id} className="hover:bg-slate-50/70">
                        <td className="py-3.5 px-5 font-mono tabular-nums text-xs font-bold text-slate-500">
                          {index + 1}
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-slate-900">
                            {item.student.name}
                          </div>
                          <div className="text-xs text-slate-500 font-mono">
                            {item.student.code} · {item.gradedCount} اختبار
                          </div>
                        </td>
                        <td className="py-3.5 px-4 text-xs text-slate-600">{item.groupName}</td>
                        <td className="py-3.5 px-4 text-left font-mono tabular-nums font-bold text-slate-900">
                          {avg}%
                        </td>
                        <td className="py-3.5 px-4 text-left font-mono tabular-nums text-xs">
                          {item.trendDelta === null ? (
                            <span className="text-slate-400">—</span>
                          ) : item.trendDelta > 0 ? (
                            <span className="text-emerald-700">+{item.trendDelta}%</span>
                          ) : item.trendDelta < 0 ? (
                            <span className="text-red-700">{item.trendDelta}%</span>
                          ) : (
                            <span className="text-slate-500">0%</span>
                          )}
                        </td>
                        <td className={`py-3.5 px-5 text-xs font-semibold ${band.textClass}`}>
                          {band.label}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* Difficult Topics Analysis */}
        <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200">
            <h3 className="text-base font-bold text-slate-900">تحليل الموضوعات الأكثر صعوبة</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              الموضوعات التي سجلت أعلى معدل أخطاء لتوجيه حصص المراجعة
            </p>
          </div>
          {difficultTopics.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              لا توجد بيانات كافية لتحليل الموضوعات.
            </div>
          ) : (
            <ul className="divide-y divide-slate-200/80">
              {difficultTopics.map((topic) => (
                <li key={`${topic.subjectId}-${topic.topic}`} className="px-6 py-4">
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="font-semibold text-slate-900">{topic.topic}</span>
                    <span
                      className={`font-mono tabular-nums text-xs font-bold ${
                        topic.errorRate >= 40
                          ? 'text-red-700'
                          : topic.errorRate >= 25
                          ? 'text-amber-700'
                          : 'text-emerald-700'
                      }`}
                    >
                      خطأ {topic.errorRate}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mt-1">
                    <span>{topic.subjectName}</span>
                    <span className="font-mono tabular-nums">
                      إتقان {topic.accuracyRate}% ({topic.totalAttempts - topic.wrongAttempts}/{topic.totalAttempts})
                    </span>
                  </div>
                  <div className="mt-2 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        topic.errorRate >= 40
                          ? 'bg-red-600'
                          : topic.errorRate >= 25
                          ? 'bg-amber-600'
                          : 'bg-teal-600'
                      }`}
                      style={{ width: `${topic.errorRate}%` }}
                    />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
};
