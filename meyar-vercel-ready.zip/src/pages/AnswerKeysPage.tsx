import React, { useEffect, useMemo, useState } from 'react';
import { Save, CheckSquare, RotateCcw } from 'lucide-react';
import { useMeyar } from '../context/MeyarContext';
import { MCQ_OPTION_LABELS, type MCQOptionKey } from '../types/domain';

const OPTION_KEYS: MCQOptionKey[] = ['A', 'B', 'C', 'D'];

export const AnswerKeysPage: React.FC = () => {
  const { state, navPayload, clearNavPayload, updateAnswerKey, navigate } = useMeyar();

  const [selectedAssignmentId, setSelectedAssignmentId] = useState<string>(
    navPayload.assignmentId ?? state.assignments[0]?.id ?? ''
  );

  useEffect(() => {
    if (navPayload.assignmentId) {
      setSelectedAssignmentId(navPayload.assignmentId);
      clearNavPayload();
    }
  }, [navPayload.assignmentId, clearNavPayload]);

  const selectedAssignment = useMemo(
    () =>
      state.assignments.find((a) => a.id === selectedAssignmentId) ??
      state.assignments[0] ??
      null,
    [state.assignments, selectedAssignmentId]
  );

  const [draftKey, setDraftKey] = useState<Record<string, MCQOptionKey>>({});
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!selectedAssignment) {
      setDraftKey({});
      return;
    }
    const next: Record<string, MCQOptionKey> = {};
    for (const q of selectedAssignment.questions) {
      next[q.id] = q.correctOption;
    }
    setDraftKey(next);
  }, [selectedAssignment]);

  const hasChanges = useMemo(() => {
    if (!selectedAssignment) return false;
    return selectedAssignment.questions.some(
      (q) => draftKey[q.id] && draftKey[q.id] !== q.correctOption
    );
  }, [selectedAssignment, draftKey]);

  const affectedSubmissionsCount = useMemo(() => {
    if (!selectedAssignment) return 0;
    return state.submissions.filter((s) => s.assignmentId === selectedAssignment.id).length;
  }, [state.submissions, selectedAssignment]);

  const subjectMap = useMemo(
    () => new Map(state.subjects.map((s) => [s.id, s.name])),
    [state.subjects]
  );
  const groupMap = useMemo(
    () => new Map(state.groups.map((g) => [g.id, g.name])),
    [state.groups]
  );

  const handleSave = async () => {
    if (!selectedAssignment || isSaving) return;
    setIsSaving(true);
    try {
      await updateAnswerKey(selectedAssignment.id, draftKey);
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetDraft = () => {
    if (!selectedAssignment) return;
    const next: Record<string, MCQOptionKey> = {};
    for (const q of selectedAssignment.questions) {
      next[q.id] = q.correctOption;
    }
    setDraftKey(next);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">نماذج الإجابة</h2>
          <p className="text-sm text-slate-500 mt-1">
            ضبط ومراجعة الإجابات النموذجية لأسئلة الاختيار من متعدد مع إعادة تصحيح فورية للدرجات عند التعديل.
          </p>
        </div>
        {selectedAssignment && (
          <button
            type="button"
            onClick={() => navigate('grading', { assignmentId: selectedAssignment.id })}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-teal-800 bg-teal-50 hover:bg-teal-100 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <CheckSquare className="w-4 h-4" />
            <span>الانتقال لتصحيح هذا الاختبار</span>
          </button>
        )}
      </div>

      {/* Selector Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex-1 max-w-xl">
          <label className="block text-xs font-semibold text-slate-600 mb-1.5">
            اختر الواجب أو الامتحان
          </label>
          <select
            value={selectedAssignment?.id ?? ''}
            onChange={(e) => setSelectedAssignmentId(e.target.value)}
            className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-lg bg-white text-slate-900 focus:outline-none focus:border-teal-600"
          >
            {state.assignments.map((asg) => (
              <option key={asg.id} value={asg.id}>
                {asg.title} ({asg.questions.length} أسئلة · {asg.totalMarks} درجة)
              </option>
            ))}
          </select>
        </div>

        {selectedAssignment && (
          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
            <span>
              المادة:{' '}
              <strong className="text-slate-900">
                {subjectMap.get(selectedAssignment.subjectId) ?? '—'}
              </strong>
            </span>
            <span aria-hidden="true">·</span>
            <span>
              المجموعة:{' '}
              <strong className="text-slate-900">
                {groupMap.get(selectedAssignment.groupId) ?? '—'}
              </strong>
            </span>
            <span aria-hidden="true">·</span>
            <span>
              أوراق مصححة:{' '}
              <strong className="font-mono tabular-nums text-slate-900">
                {affectedSubmissionsCount}
              </strong>
            </span>
          </div>
        )}
      </div>

      {!selectedAssignment ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-3">
          <p className="text-sm text-slate-600">
            لا توجد واجبات أو امتحانات مسجلة بعد. أنشئ اختباراً أولاً لضبط نموذج الإجابة.
          </p>
          <button
            type="button"
            onClick={() => navigate('assignments')}
            className="px-4 py-2 text-xs font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg"
          >
            الانتقال إلى الواجبات والامتحانات
          </button>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          {/* Quick Summary Strip */}
          <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="text-xs text-slate-600">
              <span className="font-semibold text-slate-800 ml-2">ملخص المفتاح:</span>
              <span className="font-mono">
                {selectedAssignment.questions
                  .map(
                    (q) =>
                      `${q.number}:${MCQ_OPTION_LABELS[draftKey[q.id] ?? q.correctOption]}`
                  )
                  .join(' · ')}
              </span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {hasChanges && (
                <button
                  type="button"
                  onClick={handleResetDraft}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-200 bg-white rounded-lg whitespace-nowrap"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>تراجع</span>
                </button>
              )}
              <button
                type="button"
                disabled={!hasChanges || isSaving}
                onClick={handleSave}
                className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                  hasChanges && !isSaving
                    ? 'bg-teal-700 hover:bg-teal-800 text-white'
                    : 'bg-slate-200 text-slate-500 cursor-not-allowed'
                }`}
              >
                <Save className="w-3.5 h-3.5" />
                <span>
                  {isSaving
                    ? 'جاري الحفظ...'
                    : `حفظ النموذج${
                        affectedSubmissionsCount > 0
                          ? ` وإعادة تصحيح (${affectedSubmissionsCount})`
                          : ''
                      }`}
                </span>
              </button>
            </div>
          </div>

          {/* Question Answer Key Rows */}
          <div className="divide-y divide-slate-200/80">
            {selectedAssignment.questions.map((q) => {
              const activeOpt = draftKey[q.id] ?? q.correctOption;
              return (
                <div
                  key={q.id}
                  className="p-5 sm:px-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4 hover:bg-slate-50/50 transition-colors"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="font-mono font-semibold text-slate-900">
                        سؤال {q.number}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{q.topic}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{q.marks} درجات</span>
                    </div>
                    <p className="text-sm font-medium text-slate-900 mt-1.5">{q.prompt}</p>
                    <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-600">
                      {OPTION_KEYS.map((key) => (
                        <span
                          key={key}
                          className={
                            activeOpt === key ? 'font-semibold text-teal-800' : ''
                          }
                        >
                          ({MCQ_OPTION_LABELS[key]}) {q.options[key]}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Bubble Selector */}
                  <div className="flex items-center gap-2 shrink-0">
                    {OPTION_KEYS.map((optKey) => {
                      const isSelected = activeOpt === optKey;
                      return (
                        <button
                          key={optKey}
                          type="button"
                          onClick={() =>
                            setDraftKey((prev) => ({ ...prev, [q.id]: optKey }))
                          }
                          aria-pressed={isSelected}
                          className={`w-10 h-10 rounded-lg text-sm font-bold border transition-colors focus-visible:outline-2 focus-visible:outline-teal-600 ${
                            isSelected
                              ? 'bg-teal-700 text-white border-teal-700'
                              : 'bg-white text-slate-700 border-slate-200 hover:border-teal-600 hover:text-teal-800'
                          }`}
                        >
                          {MCQ_OPTION_LABELS[optKey]}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
