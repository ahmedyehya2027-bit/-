import React, { useMemo, useState } from 'react';
import { Plus, Search, Pencil, Trash2, Download } from 'lucide-react';
import { useMeyar } from '../context/MeyarContext';
import type { Teacher } from '../types/domain';
import {
  buildExportFilename,
  buildTeachersCsvData,
  downloadCsvFile,
} from '../utils/exportCsv';
import { Modal } from '../components/ui/Modal';

interface TeacherFormState {
  name: string;
  email: string;
  phone: string;
  specialization: string;
  subjectIds: string[];
  active: boolean;
}

const EMPTY_FORM: TeacherFormState = {
  name: '',
  email: '',
  phone: '',
  specialization: '',
  subjectIds: [],
  active: true,
};

export const TeachersPage: React.FC = () => {
  const { state, addTeacher, updateTeacher, deleteTeacher, showToast } = useMeyar();
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);
  const [form, setForm] = useState<TeacherFormState>(EMPTY_FORM);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const subjectMap = useMemo(
    () => new Map(state.subjects.map((s) => [s.id, s.name])),
    [state.subjects]
  );

  const teacherRows = useMemo(() => {
    const query = search.trim().toLowerCase();
    return state.teachers
      .filter((t) => {
        if (!query) return true;
        return (
          t.name.toLowerCase().includes(query) ||
          t.specialization.toLowerCase().includes(query) ||
          t.email.toLowerCase().includes(query)
        );
      })
      .map((t) => {
        const groups = state.groups.filter((g) => g.teacherId === t.id);
        const students = state.students.filter((st) => st.teacherId === t.id);
        const assignments = state.assignments.filter((a) => a.teacherId === t.id);
        const asgIds = new Set(assignments.map((a) => a.id));
        const subs = state.submissions.filter((sub) => asgIds.has(sub.assignmentId));
        const avgScore =
          subs.length > 0
            ? Math.round(
                (subs.reduce((acc, s) => acc + s.percentage, 0) / subs.length) * 10
              ) / 10
            : null;
        const passRate =
          subs.length > 0
            ? Math.round(
                (subs.filter((s) => s.percentage >= 60).length / subs.length) * 100
              )
            : null;
        return {
          teacher: t,
          subjectsLabel: t.subjectIds
            .map((id) => subjectMap.get(id) ?? '—')
            .join('، '),
          groupNames: groups.map((g) => g.name),
          groupsCount: groups.length,
          studentsCount: students.length,
          assignmentsCount: assignments.length,
          gradedCount: subs.length,
          avgScore,
          passRate,
        };
      });
  }, [state.teachers, state.groups, state.students, state.assignments, state.submissions, subjectMap, search]);

  const openCreateModal = () => {
    setEditingTeacher(null);
    setForm({
      ...EMPTY_FORM,
      subjectIds: state.subjects[0] ? [state.subjects[0].id] : [],
    });
    setModalOpen(true);
  };

  const openEditModal = (teacher: Teacher) => {
    setEditingTeacher(teacher);
    setForm({
      name: teacher.name,
      email: teacher.email,
      phone: teacher.phone,
      specialization: teacher.specialization,
      subjectIds: [...teacher.subjectIds],
      active: teacher.active,
    });
    setModalOpen(true);
  };

  const toggleSubject = (subjectId: string) => {
    setForm((prev) => ({
      ...prev,
      subjectIds: prev.subjectIds.includes(subjectId)
        ? prev.subjectIds.filter((id) => id !== subjectId)
        : [...prev.subjectIds, subjectId],
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || isSubmitting) return;
    setIsSubmitting(true);
    try {
      const ok = editingTeacher
        ? await updateTeacher(editingTeacher.id, form)
        : await addTeacher(form);
      if (ok) {
        setModalOpen(false);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleExportTeachersCSV = () => {
    const isFiltered = search.trim().length > 0;
    const { headers, rows } = buildTeachersCsvData(teacherRows);
    const filename = buildExportFilename('teachers', { filtered: isFiltered });
    const res = downloadCsvFile(filename, headers, rows);
    showToast(`تم تصدير ${res.rowCount} مدرس إلى الملف ${res.filename}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">إدارة المدرسين</h2>
          <p className="text-sm text-slate-500 mt-1">
            إضافة وتحديث بيانات المدرسين وربطهم بالمواد الدراسية والمجموعات.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            disabled={teacherRows.length === 0}
            onClick={handleExportTeachersCSV}
            className="inline-flex items-center justify-center gap-2 px-3.5 py-2.5 text-sm font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Download className="w-4 h-4" />
            <span>تصدير CSV</span>
          </button>
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة مدرس</span>
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث بالاسم أو التخصص أو البريد..."
              className="w-full pr-9 pl-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
            />
          </div>
          <div className="text-xs text-slate-500 font-mono tabular-nums">
            إجمالي النتائج: {teacherRows.length} مدرس
          </div>
        </div>

        {teacherRows.length === 0 ? (
          <div className="p-10 text-center">
            <p className="text-sm text-slate-600">لا يوجد مدرسون مطابقون لمعايير البحث الحالية.</p>
            <button
              type="button"
              onClick={openCreateModal}
              className="mt-3 px-4 py-2 text-xs font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg"
            >
              إضافة أول مدرس
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="py-3 px-6 font-medium">المدرس</th>
                  <th className="py-3 px-4 font-medium">المواد الدراسية</th>
                  <th className="py-3 px-4 font-medium">المجموعات</th>
                  <th className="py-3 px-4 font-medium text-left">الطلاب</th>
                  <th className="py-3 px-4 font-medium text-left">متوسط الدرجات</th>
                  <th className="py-3 px-4 font-medium">الحالة</th>
                  <th className="py-3 px-6 font-medium text-left">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/80">
                {teacherRows.map(
                  ({ teacher, groupNames, groupsCount, studentsCount, avgScore }) => (
                    <tr key={teacher.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-4 px-6">
                        <div className="font-semibold text-slate-900">{teacher.name}</div>
                        <div className="text-xs text-slate-500 mt-0.5">
                          {teacher.specialization} <span aria-hidden="true">·</span>{' '}
                          <span className="font-mono">{teacher.phone}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4 text-xs text-slate-700">
                        {teacher.subjectIds.length > 0
                          ? teacher.subjectIds
                              .map((id) => subjectMap.get(id) ?? '—')
                              .join(' · ')
                          : 'غير محدد'}
                      </td>
                      <td className="py-4 px-4">
                        <div className="text-xs font-medium text-slate-800 font-mono tabular-nums">
                          {groupsCount} مجموعات
                        </div>
                        {groupNames.length > 0 && (
                          <div className="text-xs text-slate-500 mt-0.5 truncate max-w-[220px]">
                            {groupNames.join('، ')}
                          </div>
                        )}
                      </td>
                      <td className="py-4 px-4 text-left font-mono tabular-nums text-slate-800">
                        {studentsCount}
                      </td>
                      <td className="py-4 px-4 text-left font-mono tabular-nums">
                        {avgScore !== null ? (
                          <span className="font-semibold text-teal-800">{avgScore}%</span>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                      <td className="py-4 px-4 text-xs font-medium">
                        <span className={teacher.active ? 'text-emerald-700' : 'text-slate-500'}>
                          {teacher.active ? 'نشط' : 'موقوف مؤقتاً'}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-left whitespace-nowrap">
                        {confirmDeleteId === teacher.id ? (
                          <div className="inline-flex items-center gap-2">
                            <button
                              type="button"
                              onClick={async () => {
                                await deleteTeacher(teacher.id);
                                setConfirmDeleteId(null);
                              }}
                              className="text-xs font-medium text-red-700 hover:underline"
                            >
                              تأكيد الحذف
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="text-xs text-slate-500 hover:underline"
                            >
                              إلغاء
                            </button>
                          </div>
                        ) : (
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => openEditModal(teacher)}
                              className="p-2 text-slate-500 hover:text-teal-700 hover:bg-slate-100 rounded-lg transition-colors"
                              aria-label={`تعديل ${teacher.name}`}
                            >
                              <Pencil className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(teacher.id)}
                              className="p-2 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                              aria-label={`حذف ${teacher.name}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Teacher Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingTeacher ? 'تعديل بيانات المدرس' : 'إضافة مدرس جديد'}
        subtitle="أدخل بيانات المدرس واختر المواد الدراسية التي يتولى تدريسها"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                الاسم الكامل *
              </label>
              <input
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="مثال: أ. كريم عبد الله"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                التخصص *
              </label>
              <input
                type="text"
                required
                value={form.specialization}
                onChange={(e) => setForm({ ...form, specialization: e.target.value })}
                placeholder="مثال: رياضيات بحتة"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                البريد الإلكتروني
              </label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="teacher@meyar.edu"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600 font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                رقم الهاتف
              </label>
              <input
                type="tel"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                placeholder="01000000000"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">
              المواد الدراسية المسندة
            </label>
            <div className="grid grid-cols-2 gap-2">
              {state.subjects.map((sub) => {
                const checked = form.subjectIds.includes(sub.id);
                return (
                  <label
                    key={sub.id}
                    className={`flex items-center gap-2.5 px-3 py-2 rounded-lg border text-sm cursor-pointer transition-colors ${
                      checked
                        ? 'border-teal-600 bg-teal-50/60 text-teal-900 font-medium'
                        : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => toggleSubject(sub.id)}
                      className="accent-teal-700"
                    />
                    <span className="truncate">{sub.name}</span>
                  </label>
                );
              })}
            </div>
          </div>

          <label className="flex items-center gap-2.5 text-sm text-slate-700 cursor-pointer pt-1">
            <input
              type="checkbox"
              checked={form.active}
              onChange={(e) => setForm({ ...form, active: e.target.checked })}
              className="accent-teal-700"
            />
            <span>المدرس نشط ومتاح لإسناد المجموعات</span>
          </label>

          <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-lg"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 disabled:opacity-60 rounded-lg"
            >
              {isSubmitting
                ? 'جاري الحفظ...'
                : editingTeacher
                ? 'حفظ التعديلات'
                : 'إضافة المدرس'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
