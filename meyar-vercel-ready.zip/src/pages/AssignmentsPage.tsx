import React, { useMemo, useState } from 'react';
import {
  Plus,
  Search,
  KeyRound,
  CheckSquare,
  Trash2,
  Pencil,
  X,
  Download,
} from 'lucide-react';
import { useMeyar } from '../context/MeyarContext';
import {
  MCQ_OPTION_LABELS,
  type Assignment,
  type AssignmentKind,
  type MCQOptionKey,
  type MCQQuestion,
} from '../types/domain';
import { formatArabicDate } from '../utils/grading';
import {
  buildAssignmentsCsvData,
  buildExportFilename,
  downloadCsvFile,
} from '../utils/exportCsv';
import { Modal } from '../components/ui/Modal';

const OPTION_KEYS: MCQOptionKey[] = ['A', 'B', 'C', 'D'];

function createBlankQuestion(number: number, defaultTopic: string): MCQQuestion {
  return {
    id: `q-${Date.now().toString(36)}-${number}-${Math.random().toString(36).slice(2, 5)}`,
    number,
    prompt: '',
    topic: defaultTopic,
    marks: 2,
    options: { A: '', B: '', C: '', D: '' },
    correctOption: 'A',
  };
}

export const AssignmentsPage: React.FC = () => {
  const {
    state,
    currentTeacher,
    addAssignment,
    updateAssignment,
    deleteAssignment,
    navigate,
    showToast,
  } = useMeyar();
  const [search, setSearch] = useState('');
  const [kindFilter, setKindFilter] = useState<'all' | AssignmentKind>('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingAssignment, setEditingAssignment] = useState<Assignment | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Builder state
  const [title, setTitle] = useState('');
  const [kind, setKind] = useState<AssignmentKind>('exam');
  const [groupId, setGroupId] = useState('');
  const [teacherId, setTeacherId] = useState('');
  const [subjectId, setSubjectId] = useState('');
  const [deadline, setDeadline] = useState('');
  const [questions, setQuestions] = useState<MCQQuestion[]>([]);

  const teacherMap = useMemo(
    () => new Map(state.teachers.map((t) => [t.id, t.name])),
    [state.teachers]
  );
  const subjectMap = useMemo(
    () => new Map(state.subjects.map((s) => [s.id, s])),
    [state.subjects]
  );
  const groupMap = useMemo(
    () => new Map(state.groups.map((g) => [g.id, g.name])),
    [state.groups]
  );

  const selectedSubjectTopics = useMemo(() => {
    const topics = subjectMap.get(subjectId)?.topics;
    return topics && topics.length > 0 ? topics : ['موضوع عام'];
  }, [subjectMap, subjectId]);

  const computedTotalMarks = useMemo(
    () => questions.reduce((sum, q) => sum + (Number(q.marks) || 0), 0),
    [questions]
  );

  const filteredAssignments = useMemo(() => {
    const q = search.trim().toLowerCase();
    return state.assignments.filter((a) => {
      if (kindFilter !== 'all' && a.kind !== kindFilter) return false;
      if (!q) return true;
      return (
        a.title.toLowerCase().includes(q) ||
        (groupMap.get(a.groupId) ?? '').toLowerCase().includes(q) ||
        (subjectMap.get(a.subjectId)?.name ?? '').toLowerCase().includes(q)
      );
    });
  }, [state.assignments, search, kindFilter, groupMap, subjectMap]);

  const syncQuestionTopicsForSubject = (newSubId: string) => {
    const newTopics = subjectMap.get(newSubId)?.topics ?? ['موضوع عام'];
    const fallbackTopic = newTopics[0] ?? 'موضوع عام';
    setQuestions((prev) =>
      prev.map((q) => ({
        ...q,
        topic: newTopics.includes(q.topic) ? q.topic : fallbackTopic,
      }))
    );
  };

  const openCreateModal = () => {
    const firstGroup = state.groups[0];
    const subId = firstGroup?.subjectId ?? state.subjects[0]?.id ?? '';
    const defaultTopic = subjectMap.get(subId)?.topics[0] ?? 'موضوع عام';
    setEditingAssignment(null);
    setTitle('');
    setKind('exam');
    setGroupId(firstGroup?.id ?? '');
    setTeacherId(firstGroup?.teacherId ?? currentTeacher?.id ?? state.teachers[0]?.id ?? '');
    setSubjectId(subId);
    setDeadline(new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10));
    setQuestions([
      createBlankQuestion(1, defaultTopic),
      createBlankQuestion(2, defaultTopic),
    ]);
    setModalOpen(true);
  };

  const openEditModal = (asg: Assignment) => {
    setEditingAssignment(asg);
    setTitle(asg.title);
    setKind(asg.kind);
    setGroupId(asg.groupId);
    setTeacherId(asg.teacherId);
    setSubjectId(asg.subjectId);
    setDeadline(asg.deadline);
    setQuestions(structuredClone(asg.questions));
    setModalOpen(true);
  };

  const handleGroupSelect = (newGroupId: string) => {
    setGroupId(newGroupId);
    const grp = state.groups.find((g) => g.id === newGroupId);
    if (grp) {
      setTeacherId(grp.teacherId);
      setSubjectId(grp.subjectId);
      syncQuestionTopicsForSubject(grp.subjectId);
    }
  };

  const handleSubjectSelect = (newSubjectId: string) => {
    setSubjectId(newSubjectId);
    syncQuestionTopicsForSubject(newSubjectId);
  };

  const addQuestionRow = () => {
    const defaultTopic = selectedSubjectTopics[0] ?? 'موضوع عام';
    setQuestions((prev) => [...prev, createBlankQuestion(prev.length + 1, defaultTopic)]);
  };

  const removeQuestionRow = (idx: number) => {
    setQuestions((prev) =>
      prev
        .filter((_, i) => i !== idx)
        .map((q, newIndex) => ({ ...q, number: newIndex + 1 }))
    );
  };

  const updateQuestion = (idx: number, patch: Partial<MCQQuestion>) => {
    setQuestions((prev) =>
      prev.map((q, i) => (i === idx ? { ...q, ...patch } : q))
    );
  };

  const updateQuestionOption = (idx: number, optKey: MCQOptionKey, value: string) => {
    setQuestions((prev) =>
      prev.map((q, i) =>
        i === idx ? { ...q, options: { ...q.options, [optKey]: value } } : q
      )
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || questions.length === 0 || isSubmitting) return;

    const normalizedQuestions = questions.map((q, i) => ({
      ...q,
      number: i + 1,
      prompt: q.prompt.trim() || `السؤال رقم ${i + 1}`,
      marks: Number(q.marks) > 0 ? Number(q.marks) : 1,
      options: {
        A: q.options.A.trim() || 'الاختيار أ',
        B: q.options.B.trim() || 'الاختيار ب',
        C: q.options.C.trim() || 'الاختيار ج',
        D: q.options.D.trim() || 'الاختيار د',
      },
    }));

    const payload = {
      title: title.trim(),
      kind,
      groupId,
      teacherId: teacherId || currentTeacher?.id || '',
      subjectId,
      deadline,
      totalMarks: normalizedQuestions.reduce((sum, q) => sum + q.marks, 0),
      questions: normalizedQuestions,
    };

    setIsSubmitting(true);
    try {
      const ok = editingAssignment
        ? await updateAssignment(editingAssignment.id, payload)
        : Boolean(await addAssignment(payload));
      if (ok) {
        setModalOpen(false);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleExportAssignmentsCSV = () => {
    const isFiltered = search.trim().length > 0 || kindFilter !== 'all';
    const exportRows = filteredAssignments.map((asg) => {
      const groupStudentsCount = state.students.filter(
        (st) => st.groupId === asg.groupId
      ).length;
      const subs = state.submissions.filter((s) => s.assignmentId === asg.id);
      const averagePercentage =
        subs.length > 0
          ? Math.round(
              (subs.reduce((acc, s) => acc + s.percentage, 0) / subs.length) * 10
            ) / 10
          : null;
      return {
        assignment: asg,
        subjectName: subjectMap.get(asg.subjectId)?.name ?? '—',
        groupName: groupMap.get(asg.groupId) ?? '—',
        teacherName: teacherMap.get(asg.teacherId) ?? '—',
        gradedCount: subs.length,
        groupStudentsCount,
        averagePercentage,
      };
    });
    const { headers, rows } = buildAssignmentsCsvData(exportRows);
    const filename = buildExportFilename('assignments', { filtered: isFiltered });
    const res = downloadCsvFile(filename, headers, rows);
    showToast(`تم تصدير ${res.rowCount} واجب/امتحان إلى الملف ${res.filename}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">الواجبات والامتحانات</h2>
          <p className="text-sm text-slate-500 mt-1">
            إنشاء الواجبات والاختبارات بأسئلة الاختيار من متعدد وتحديد الدرجات والمواعيد النهائية.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            disabled={filteredAssignments.length === 0}
            onClick={handleExportAssignmentsCSV}
            className="inline-flex items-center justify-center gap-2 px-3.5 py-2.5 text-sm font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Download className="w-4 h-4" />
            <span>تصدير CSV</span>
          </button>
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>إنشاء واجب / امتحان</span>
          </button>
        </div>
      </div>

      {/* Filter Bar + Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث بعنوان الاختبار أو المجموعة أو المادة..."
              className="w-full pr-9 pl-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
            />
          </div>

          {/* Interactive Segmented Filter */}
          <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg self-start">
            {(
              [
                { id: 'all', label: 'الكل' },
                { id: 'exam', label: 'امتحانات' },
                { id: 'homework', label: 'واجبات' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setKindFilter(tab.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  kindFilter === tab.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {filteredAssignments.length === 0 ? (
          <div className="p-10 text-center space-y-3">
            <p className="text-sm text-slate-600">
              {state.assignments.length === 0
                ? 'لا توجد واجبات أو امتحانات مسجلة بعد.'
                : 'لا توجد نتائج مطابقة لمعايير البحث الحالية.'}
            </p>
            <div className="flex items-center justify-center gap-2">
              {state.assignments.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    setSearch('');
                    setKindFilter('all');
                  }}
                  className="px-4 py-2 text-xs font-medium text-teal-700 border border-teal-200 hover:bg-teal-50 rounded-lg"
                >
                  مسح التصفية
                </button>
              )}
              <button
                type="button"
                onClick={openCreateModal}
                className="px-4 py-2 text-xs font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg"
              >
                إنشاء واجب / امتحان
              </button>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="py-3 px-6 font-medium">العنوان والنوع</th>
                  <th className="py-3 px-4 font-medium">المجموعة والمدرس</th>
                  <th className="py-3 px-4 font-medium text-left">الأسئلة / الدرجة</th>
                  <th className="py-3 px-4 font-medium">الموعد النهائي</th>
                  <th className="py-3 px-4 font-medium text-left">تم تصحيحه</th>
                  <th className="py-3 px-6 font-medium text-left">إجراءات سريعة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/80">
                {filteredAssignments.map((asg) => {
                  const groupCount = state.students.filter(
                    (st) => st.groupId === asg.groupId
                  ).length;
                  const gradedCount = state.submissions.filter(
                    (s) => s.assignmentId === asg.id
                  ).length;

                  return (
                    <tr key={asg.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-4 px-6">
                        <div className="font-semibold text-slate-900">{asg.title}</div>
                        <div className="text-xs text-slate-500 mt-0.5">
                          {asg.kind === 'exam' ? 'امتحان' : 'واجب منزلي'}{' '}
                          <span aria-hidden="true">·</span>{' '}
                          {subjectMap.get(asg.subjectId)?.name ?? '—'}
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <div className="text-xs font-medium text-slate-800">
                          {groupMap.get(asg.groupId) ?? '—'}
                        </div>
                        <div className="text-xs text-slate-500 mt-0.5">
                          {teacherMap.get(asg.teacherId) ?? '—'}
                        </div>
                      </td>
                      <td className="py-4 px-4 text-left font-mono tabular-nums text-xs text-slate-800 whitespace-nowrap">
                        {asg.questions.length} أسئلة · {asg.totalMarks} درجة
                      </td>
                      <td className="py-4 px-4 text-xs text-slate-600 whitespace-nowrap">
                        {formatArabicDate(asg.deadline)}
                      </td>
                      <td className="py-4 px-4 text-left font-mono tabular-nums text-xs text-slate-700 whitespace-nowrap">
                        {gradedCount} / {groupCount}
                      </td>
                      <td className="py-4 px-6 text-left whitespace-nowrap">
                        {confirmDeleteId === asg.id ? (
                          <div className="inline-flex items-center gap-2">
                            <button
                              type="button"
                              onClick={async () => {
                                await deleteAssignment(asg.id);
                                setConfirmDeleteId(null);
                              }}
                              className="text-xs font-medium text-red-700 hover:underline"
                            >
                              تأكيد الحذف
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="text-xs text-slate-500 hover:underline"
                            >
                              إلغاء
                            </button>
                          </div>
                        ) : (
                          <div className="inline-flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() =>
                                navigate('answer-keys', { assignmentId: asg.id })
                              }
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:text-teal-800 hover:bg-slate-100 rounded-md transition-colors"
                              title="تعديل نموذج الإجابة"
                            >
                              <KeyRound className="w-3.5 h-3.5" />
                              <span>النموذج</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => navigate('grading', { assignmentId: asg.id })}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-teal-800 bg-teal-50 hover:bg-teal-100 rounded-md transition-colors"
                            >
                              <CheckSquare className="w-3.5 h-3.5" />
                              <span>تصحيح</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => openEditModal(asg)}
                              className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md"
                              aria-label="تعديل الاختبار"
                            >
                              <Pencil className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(asg.id)}
                              className="p-1.5 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded-md"
                              aria-label="حذف الاختبار"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Assignment & MCQ Builder Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingAssignment ? 'تعديل الواجب / الامتحان' : 'إنشاء واجب أو امتحان جديد'}
        subtitle="أضف أسئلة الاختيار من متعدد وحدد الإجابة الصحيحة ودرجة كل سؤال"
        size="xl"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Details */}
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
            <div className="sm:col-span-8">
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                عنوان الواجب أو الامتحان *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="مثال: اختبار الوحدة الثانية — التفاضل الضمني"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
              />
            </div>
            <div className="sm:col-span-4">
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                النوع *
              </label>
              <select
                value={kind}
                onChange={(e) => setKind(e.target.value as AssignmentKind)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-teal-600"
              >
                <option value="exam">امتحان</option>
                <option value="homework">واجب منزلي</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                المجموعة
              </label>
              <select
                value={groupId}
                onChange={(e) => handleGroupSelect(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-teal-600"
              >
                <option value="">
                  {state.groups.length === 0 ? 'بدون مجموعة حالياً' : 'اختر المجموعة'}
                </option>
                {state.groups.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                المدرس
              </label>
              <select
                value={teacherId}
                onChange={(e) => setTeacherId(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-teal-600"
              >
                <option value="">اختر المدرس</option>
                {state.teachers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                المادة
              </label>
              <select
                value={subjectId}
                onChange={(e) => handleSubjectSelect(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-teal-600"
              >
                <option value="">
                  {state.subjects.length === 0 ? 'بدون مادة حالياً' : 'اختر المادة'}
                </option>
                {state.subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                الموعد النهائي *
              </label>
              <input
                type="date"
                required
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-teal-600"
              />
            </div>
          </div>

          {/* MCQ Builder Section */}
          <div className="pt-4 border-t border-slate-200 space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  أسئلة الاختيار من متعدد ({questions.length} أسئلة · الإجمالي:{' '}
                  <span className="font-mono tabular-nums text-teal-800">
                    {computedTotalMarks}
                  </span>{' '}
                  درجة)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  اختر الحرف الصحيح لكل سؤال لتكوين نموذج الإجابة تلقائياً
                </p>
              </div>
              <button
                type="button"
                onClick={addQuestionRow}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-teal-800 bg-teal-50 hover:bg-teal-100 rounded-lg transition-colors whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة سؤال</span>
              </button>
            </div>

            <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg">
              {questions.map((q, idx) => {
                const topicOptions = selectedSubjectTopics.includes(q.topic)
                  ? selectedSubjectTopics
                  : [q.topic, ...selectedSubjectTopics];
                return (
                  <div key={q.id} className="p-4 space-y-3">
                    <div className="flex items-center justify-between gap-3">
                      <span className="text-xs font-bold text-slate-700 font-mono">
                        سؤال {idx + 1}
                      </span>
                      <div className="flex items-center gap-3">
                        <select
                          value={q.topic}
                          onChange={(e) => updateQuestion(idx, { topic: e.target.value })}
                          aria-label="موضوع السؤال"
                          className="px-2.5 py-1 text-xs border border-slate-200 rounded-md bg-white text-slate-700"
                        >
                          {topicOptions.map((topic) => (
                            <option key={topic} value={topic}>
                              {topic}
                            </option>
                          ))}
                        </select>
                        <label className="flex items-center gap-1.5 text-xs text-slate-600">
                          <span>الدرجة:</span>
                          <input
                            type="number"
                            min={0.5}
                            step={0.5}
                            value={q.marks}
                            onChange={(e) =>
                              updateQuestion(idx, { marks: Number(e.target.value) || 1 })
                            }
                            className="w-16 px-2 py-1 text-xs font-mono border border-slate-200 rounded-md text-center"
                          />
                        </label>
                        {questions.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeQuestionRow(idx)}
                            className="p-1 text-slate-400 hover:text-red-700 rounded"
                            aria-label="حذف السؤال"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    <input
                      type="text"
                      value={q.prompt}
                      onChange={(e) => updateQuestion(idx, { prompt: e.target.value })}
                      placeholder={`اكتب نص السؤال رقم ${idx + 1}...`}
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
                    />

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {OPTION_KEYS.map((optKey) => {
                        const isCorrect = q.correctOption === optKey;
                        return (
                          <div key={optKey} className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => updateQuestion(idx, { correctOption: optKey })}
                              className={`w-8 h-8 rounded-md text-xs font-bold shrink-0 border transition-colors ${
                                isCorrect
                                  ? 'bg-teal-700 text-white border-teal-700'
                                  : 'bg-white text-slate-600 border-slate-200 hover:border-teal-600'
                              }`}
                              title="تعيين كإجابة صحيحة"
                            >
                              {MCQ_OPTION_LABELS[optKey]}
                            </button>
                            <input
                              type="text"
                              value={q.options[optKey]}
                              onChange={(e) =>
                                updateQuestionOption(idx, optKey, e.target.value)
                              }
                              placeholder={`الاختيار ${MCQ_OPTION_LABELS[optKey]}`}
                              className={`flex-1 px-2.5 py-1.5 text-xs border rounded-md focus:outline-none ${
                                isCorrect
                                  ? 'border-teal-500 bg-teal-50/40'
                                  : 'border-slate-200 focus:border-teal-600'
                              }`}
                            />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-lg"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 disabled:opacity-60 rounded-lg"
            >
              {isSubmitting
                ? 'جاري الحفظ...'
                : editingAssignment
                ? 'حفظ التعديلات'
                : 'حفظ ونشر الواجب'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
