import React, { useMemo, useState } from 'react';
import { Download, Printer, Search } from 'lucide-react';
import { useMeyar } from '../context/MeyarContext';
import {
  computeStudentSummaries,
  formatArabicDate,
  getPerformanceBand,
  type StudentPerformanceSummary,
} from '../utils/grading';
import {
  buildExportFilename,
  buildGradesCsvData,
  buildGroupsCsvData,
  buildStudentsCsvData,
  buildTeachersCsvData,
  downloadCsvFile,
} from '../utils/exportCsv';
import {
  PrintDocumentFooter,
  PrintDocumentHeader,
  StudentA4ReportSheet,
  triggerSingleSheetPrint,
} from '../components/PrintHeader';
import { FUTURE_INTEGRATIONS } from '../services/integrations';

type ReportTab = 'students' | 'teachers' | 'groups' | 'results' | 'integrations';

export const ReportsPage: React.FC = () => {
  const { state, showToast } = useMeyar();
  const [activeTab, setActiveTab] = useState<ReportTab>('students');

  // Filters per report tab
  const [studentSearch, setStudentSearch] = useState('');
  const [studentGroupFilter, setStudentGroupFilter] = useState('all');
  const [studentTeacherFilter, setStudentTeacherFilter] = useState('all');

  const [teacherSearch, setTeacherSearch] = useState('');
  const [teacherSubjectFilter, setTeacherSubjectFilter] = useState('all');

  const [groupSubjectFilter, setGroupSubjectFilter] = useState('all');
  const [groupTeacherFilter, setGroupTeacherFilter] = useState('all');

  const [resultSearch, setResultSearch] = useState('');
  const [resultAssignmentFilter, setResultAssignmentFilter] = useState('all');
  const [resultGroupFilter, setResultGroupFilter] = useState('all');

  // Individual student A4 print target
  const [printingStudentSummary, setPrintingStudentSummary] =
    useState<StudentPerformanceSummary | null>(null);

  const subjectMap = useMemo(
    () => new Map(state.subjects.map((s) => [s.id, s])),
    [state.subjects]
  );
  const teacherMap = useMemo(
    () => new Map(state.teachers.map((t) => [t.id, t])),
    [state.teachers]
  );
  const groupMap = useMemo(
    () => new Map(state.groups.map((g) => [g.id, g])),
    [state.groups]
  );
  const studentMap = useMemo(
    () => new Map(state.students.map((st) => [st.id, st])),
    [state.students]
  );
  const assignmentMap = useMemo(
    () => new Map(state.assignments.map((a) => [a.id, a])),
    [state.assignments]
  );

  // 1. Students Report Data (respecting search & filters)
  const studentReports = useMemo(() => {
    const q = studentSearch.trim().toLowerCase();
    const all = computeStudentSummaries(
      state.students,
      state.submissions,
      state.groups,
      state.teachers,
      state.subjects
    );
    return all.filter((item) => {
      if (studentGroupFilter !== 'all' && item.student.groupId !== studentGroupFilter) {
        return false;
      }
      if (
        studentTeacherFilter !== 'all' &&
        item.student.teacherId !== studentTeacherFilter
      ) {
        return false;
      }
      if (!q) return true;
      return (
        item.student.name.toLowerCase().includes(q) ||
        item.student.code.toLowerCase().includes(q) ||
        item.groupName.toLowerCase().includes(q)
      );
    });
  }, [
    state.students,
    state.submissions,
    state.groups,
    state.teachers,
    state.subjects,
    studentSearch,
    studentGroupFilter,
    studentTeacherFilter,
  ]);

  // 2. Teachers Report Data (respecting search & subject filter)
  const teacherReports = useMemo(() => {
    const q = teacherSearch.trim().toLowerCase();
    return state.teachers
      .filter((t) => {
        if (
          teacherSubjectFilter !== 'all' &&
          !t.subjectIds.includes(teacherSubjectFilter)
        ) {
          return false;
        }
        if (!q) return true;
        return (
          t.name.toLowerCase().includes(q) ||
          t.specialization.toLowerCase().includes(q)
        );
      })
      .map((t) => {
        const groups = state.groups.filter((g) => g.teacherId === t.id);
        const students = state.students.filter((st) => st.teacherId === t.id);
        const assignments = state.assignments.filter((a) => a.teacherId === t.id);
        const asgIds = new Set(assignments.map((a) => a.id));
        const subs = state.submissions.filter((sub) => asgIds.has(sub.assignmentId));
        const avgScore =
          subs.length > 0
            ? Math.round(
                (subs.reduce((acc, s) => acc + s.percentage, 0) / subs.length) * 10
              ) / 10
            : null;
        const passRate =
          subs.length > 0
            ? Math.round(
                (subs.filter((s) => s.percentage >= 60).length / subs.length) * 100
              )
            : null;

        return {
          teacher: t,
          subjectsLabel: t.subjectIds
            .map((id) => subjectMap.get(id)?.name ?? '—')
            .join('، '),
          groupsCount: groups.length,
          studentsCount: students.length,
          assignmentsCount: assignments.length,
          gradedCount: subs.length,
          avgScore,
          passRate,
        };
      });
  }, [
    state.teachers,
    state.groups,
    state.students,
    state.assignments,
    state.submissions,
    subjectMap,
    teacherSearch,
    teacherSubjectFilter,
  ]);

  // 3. Groups Report Data (respecting subject & teacher filters)
  const groupReports = useMemo(() => {
    return state.groups
      .filter((g) => {
        if (groupSubjectFilter !== 'all' && g.subjectId !== groupSubjectFilter) {
          return false;
        }
        if (groupTeacherFilter !== 'all' && g.teacherId !== groupTeacherFilter) {
          return false;
        }
        return true;
      })
      .map((g) => {
        const enrolled = state.students.filter((st) => st.groupId === g.id).length;
        const asgs = state.assignments.filter((a) => a.groupId === g.id);
        const asgIds = new Set(asgs.map((a) => a.id));
        const subs = state.submissions.filter((s) => asgIds.has(s.assignmentId));
        const avg =
          subs.length > 0
            ? Math.round(
                (subs.reduce((acc, s) => acc + s.percentage, 0) / subs.length) * 10
              ) / 10
            : null;
        const passRate =
          subs.length > 0
            ? Math.round(
                (subs.filter((s) => s.percentage >= 60).length / subs.length) * 100
              )
            : null;

        return {
          group: g,
          teacherName: teacherMap.get(g.teacherId)?.name ?? 'غير محدد',
          subjectName: subjectMap.get(g.subjectId)?.name ?? 'غير محدد',
          enrolled,
          assignmentsCount: asgs.length,
          gradedCount: subs.length,
          avg,
          passRate,
        };
      });
  }, [
    state.groups,
    state.students,
    state.assignments,
    state.submissions,
    teacherMap,
    subjectMap,
    groupSubjectFilter,
    groupTeacherFilter,
  ]);

  // 4. Detailed Grades / Results Report Data (respecting assignment, group & search filters)
  const resultsReports = useMemo(() => {
    const q = resultSearch.trim().toLowerCase();
    return state.submissions
      .map((submission) => {
        const student = studentMap.get(submission.studentId);
        const assignment = assignmentMap.get(submission.assignmentId);
        const subject = assignment ? subjectMap.get(assignment.subjectId) : undefined;
        const group = assignment ? groupMap.get(assignment.groupId) : undefined;
        const teacher = assignment ? teacherMap.get(assignment.teacherId) : undefined;
        return { submission, student, assignment, subject, group, teacher };
      })
      .filter((row) => {
        if (
          resultAssignmentFilter !== 'all' &&
          row.submission.assignmentId !== resultAssignmentFilter
        ) {
          return false;
        }
        if (
          resultGroupFilter !== 'all' &&
          row.assignment?.groupId !== resultGroupFilter
        ) {
          return false;
        }
        if (!q) return true;
        return (
          (row.student?.name ?? '').toLowerCase().includes(q) ||
          (row.student?.code ?? '').toLowerCase().includes(q) ||
          (row.assignment?.title ?? '').toLowerCase().includes(q)
        );
      })
      .sort((a, b) => b.submission.gradedAt.localeCompare(a.submission.gradedAt));
  }, [
    state.submissions,
    studentMap,
    assignmentMap,
    subjectMap,
    groupMap,
    teacherMap,
    resultSearch,
    resultAssignmentFilter,
    resultGroupFilter,
  ]);

  const printingStudentSubmissions = useMemo(() => {
    if (!printingStudentSummary) return [];
    return state.submissions
      .filter((s) => s.studentId === printingStudentSummary.student.id)
      .map((sub) => ({ sub, assignment: assignmentMap.get(sub.assignmentId) }))
      .sort((a, b) => b.sub.gradedAt.localeCompare(a.sub.gradedAt));
  }, [printingStudentSummary, state.submissions, assignmentMap]);

  const handlePrintSingleStudent = (summary: StudentPerformanceSummary) => {
    setPrintingStudentSummary(summary);
    triggerSingleSheetPrint(() => {
      setPrintingStudentSummary(null);
    });
  };

  // Export handlers (strictly honoring active filters)
  const handleExportCurrentCSV = () => {
    if (activeTab === 'students') {
      const isFiltered =
        studentGroupFilter !== 'all' ||
        studentTeacherFilter !== 'all' ||
        studentSearch.trim().length > 0;
      const { headers, rows } = buildStudentsCsvData(studentReports);
      const filename = buildExportFilename('report-students', { filtered: isFiltered });
      const res = downloadCsvFile(filename, headers, rows);
      showToast(`تم تصدير ${res.rowCount} سجل طلاب إلى ${res.filename}`);
    } else if (activeTab === 'teachers') {
      const isFiltered =
        teacherSubjectFilter !== 'all' || teacherSearch.trim().length > 0;
      const { headers, rows } = buildTeachersCsvData(teacherReports);
      const filename = buildExportFilename('report-teachers', { filtered: isFiltered });
      const res = downloadCsvFile(filename, headers, rows);
      showToast(`تم تصدير ${res.rowCount} سجل مدرسين إلى ${res.filename}`);
    } else if (activeTab === 'groups') {
      const isFiltered =
        groupSubjectFilter !== 'all' || groupTeacherFilter !== 'all';
      const { headers, rows } = buildGroupsCsvData(groupReports);
      const filename = buildExportFilename('report-groups', { filtered: isFiltered });
      const res = downloadCsvFile(filename, headers, rows);
      showToast(`تم تصدير ${res.rowCount} سجل مجموعات إلى ${res.filename}`);
    } else if (activeTab === 'results') {
      const isFiltered =
        resultAssignmentFilter !== 'all' ||
        resultGroupFilter !== 'all' ||
        resultSearch.trim().length > 0;
      const { headers, rows } = buildGradesCsvData(resultsReports);
      const filename = buildExportFilename('report-results', { filtered: isFiltered });
      const res = downloadCsvFile(filename, headers, rows);
      showToast(`تم تصدير ${res.rowCount} نتيجة مصححة إلى ${res.filename}`);
    }
  };

  const activeRowCount =
    activeTab === 'students'
      ? studentReports.length
      : activeTab === 'teachers'
      ? teacherReports.length
      : activeTab === 'groups'
      ? groupReports.length
      : activeTab === 'results'
      ? resultsReports.length
      : 0;

  // Dynamic A4 Print metadata for the currently open report tab
  const printHeaderMeta = useMemo(() => {
    if (activeTab === 'students') {
      const graded = studentReports.filter((r) => r.averagePercentage !== null);
      const avg =
        graded.length > 0
          ? Math.round(
              (graded.reduce((sum, r) => sum + (r.averagePercentage ?? 0), 0) /
                graded.length) *
                10
            ) / 10
          : null;
      const scopeParts: string[] = [];
      scopeParts.push(
        studentGroupFilter === 'all'
          ? 'جميع المجموعات'
          : groupMap.get(studentGroupFilter)?.name ?? 'مجموعة محددة'
      );
      if (studentTeacherFilter !== 'all') {
        scopeParts.push(teacherMap.get(studentTeacherFilter)?.name ?? '');
      }
      if (studentSearch.trim()) {
        scopeParts.push(`بحث: "${studentSearch.trim()}"`);
      }
      return {
        title: 'تقرير أداء الطلاب الشامل',
        subtitle: 'ملخص نتائج الطلاب والمتوسطات وأعلى وأدنى درجة والتقدير الأكاديمي',
        filterSummary: scopeParts.filter(Boolean).join(' · '),
        metrics: [
          { label: 'عدد الطلاب', value: String(studentReports.length) },
          { label: 'طلاب لديهم نتائج', value: String(graded.length) },
          { label: 'متوسط النطاق', value: avg !== null ? `${avg}%` : '—' },
          {
            label: 'متفوقون (85%+)',
            value: String(graded.filter((r) => (r.averagePercentage ?? 0) >= 85).length),
          },
        ],
      };
    }

    if (activeTab === 'teachers') {
      const withAvg = teacherReports.filter((r) => r.avgScore !== null);
      const avg =
        withAvg.length > 0
          ? Math.round(
              (withAvg.reduce((sum, r) => sum + (r.avgScore ?? 0), 0) / withAvg.length) *
                10
            ) / 10
          : null;
      const totalGraded = teacherReports.reduce((sum, r) => sum + r.gradedCount, 0);
      return {
        title: 'تقرير أداء المدرسين والهيئة التعليمية',
        subtitle: 'مؤشرات نشاط الاختبارات، الأوراق المصححة، ومتوسطات نتائج الطلاب لكل مدرس',
        filterSummary:
          teacherSubjectFilter === 'all'
            ? 'جميع المواد الدراسية'
            : `المادة: ${subjectMap.get(teacherSubjectFilter)?.name ?? '—'}`,
        metrics: [
          { label: 'عدد المدرسين', value: String(teacherReports.length) },
          {
            label: 'إجمالي المجموعات',
            value: String(teacherReports.reduce((s, r) => s + r.groupsCount, 0)),
          },
          { label: 'الأوراق المصححة', value: String(totalGraded) },
          { label: 'متوسط الدرجات', value: avg !== null ? `${avg}%` : '—' },
        ],
      };
    }

    if (activeTab === 'groups') {
      const withAvg = groupReports.filter((r) => r.avg !== null);
      const avg =
        withAvg.length > 0
          ? Math.round(
              (withAvg.reduce((sum, r) => sum + (r.avg ?? 0), 0) / withAvg.length) * 10
            ) / 10
          : null;
      return {
        title: 'تقرير المجموعات الدراسية ومعدلات الإنجاز',
        subtitle: 'مقارنة السعة الاستيعابية، عدد الاختبارات، متوسط الدرجات، ونسبة النجاح لكل مجموعة',
        filterSummary: [
          groupSubjectFilter === 'all'
            ? 'جميع المواد'
            : subjectMap.get(groupSubjectFilter)?.name ?? '',
          groupTeacherFilter === 'all'
            ? 'جميع المدرسين'
            : teacherMap.get(groupTeacherFilter)?.name ?? '',
        ]
          .filter(Boolean)
          .join(' · '),
        metrics: [
          { label: 'عدد المجموعات', value: String(groupReports.length) },
          {
            label: 'إجمالي الطلاب',
            value: String(groupReports.reduce((s, r) => s + r.enrolled, 0)),
          },
          {
            label: 'إجمالي الاختبارات',
            value: String(groupReports.reduce((s, r) => s + r.assignmentsCount, 0)),
          },
          { label: 'متوسط المجموعات', value: avg !== null ? `${avg}%` : '—' },
        ],
      };
    }

    // results tab
    const avg =
      resultsReports.length > 0
        ? Math.round(
            (resultsReports.reduce((s, r) => s + r.submission.percentage, 0) /
              resultsReports.length) *
              10
          ) / 10
        : null;
    const passRate =
      resultsReports.length > 0
        ? Math.round(
            (resultsReports.filter((r) => r.submission.percentage >= 60).length /
              resultsReports.length) *
              100
          )
        : null;
    return {
      title: 'كشف درجات ونتائج الواجبات والامتحانات',
      subtitle: 'سجل تفصيلي للدرجات المرصودة مع عدد الإجابات الصحيحة والخاطئة والتقدير',
      filterSummary: [
        resultAssignmentFilter === 'all'
          ? 'جميع الواجبات والامتحانات'
          : assignmentMap.get(resultAssignmentFilter)?.title ?? '',
        resultGroupFilter === 'all'
          ? 'جميع المجموعات'
          : groupMap.get(resultGroupFilter)?.name ?? '',
      ]
        .filter(Boolean)
        .join(' · '),
      metrics: [
        { label: 'عدد النتائج', value: String(resultsReports.length) },
        { label: 'متوسط الدرجات', value: avg !== null ? `${avg}%` : '—' },
        { label: 'نسبة النجاح', value: passRate !== null ? `${passRate}%` : '—' },
        {
          label: 'تقدير ممتاز',
          value: String(
            resultsReports.filter((r) => r.submission.percentage >= 85).length
          ),
        },
      ],
    };
  }, [
    activeTab,
    studentReports,
    studentGroupFilter,
    studentTeacherFilter,
    studentSearch,
    teacherReports,
    teacherSubjectFilter,
    groupReports,
    groupSubjectFilter,
    groupTeacherFilter,
    resultsReports,
    resultAssignmentFilter,
    resultGroupFilter,
    groupMap,
    teacherMap,
    subjectMap,
    assignmentMap,
  ]);

  return (
    <div className="space-y-6">
      {/* Screen Header & Print/Export Actions */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 no-print">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">التقارير والطباعة</h2>
          <p className="text-sm text-slate-500 mt-1">
            استعراض وطباعة تقارير A4 للطلاب والمدرسين والمجموعات والنتائج، مع تصدير CSV متوافق مع Excel.
          </p>
        </div>

        {activeTab !== 'integrations' && (
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={activeRowCount === 0}
              onClick={() => window.print()}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة التقرير (A4)</span>
            </button>
            <button
              type="button"
              disabled={activeRowCount === 0}
              onClick={handleExportCurrentCSV}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors whitespace-nowrap disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Download className="w-4 h-4" />
              <span>تصدير CSV</span>
            </button>
          </div>
        )}
      </div>

      {/* Report Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-3 no-print">
        <div className="inline-flex flex-wrap items-center p-1 bg-slate-200/70 rounded-lg">
          {(
            [
              { id: 'students', label: 'تقارير الطلاب' },
              { id: 'teachers', label: 'تقارير المدرسين' },
              { id: 'groups', label: 'تقارير المجموعات' },
              { id: 'results', label: 'النتائج والدرجات' },
              { id: 'integrations', label: 'التكاملات المستقبلية' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-md transition-colors whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Official A4 Print Header (shown only when printing one of the 4 report tabs) */}
      {activeTab !== 'integrations' && (
        <PrintDocumentHeader
          title={printHeaderMeta.title}
          subtitle={printHeaderMeta.subtitle}
          filterSummary={printHeaderMeta.filterSummary}
          metrics={printHeaderMeta.metrics}
        />
      )}

      {/* TAB 1: Student Performance Report */}
      {activeTab === 'students' && (
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden print-section-card">
          <div className="px-6 py-4 border-b border-slate-200 flex flex-col lg:flex-row lg:items-center justify-between gap-3 no-print">
            <div>
              <h3 className="text-base font-bold text-slate-900">تقرير أداء الطلاب الشامل</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                التصدير والطباعة يطبقان البحث وفلاتر المجموعة والمدرس المحددة أدناه
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={studentSearch}
                  onChange={(e) => setStudentSearch(e.target.value)}
                  placeholder="بحث بالاسم أو الكود..."
                  className="pr-8 pl-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
                />
              </div>
              <select
                value={studentGroupFilter}
                onChange={(e) => setStudentGroupFilter(e.target.value)}
                aria-label="تصفية تقرير الطلاب حسب المجموعة"
                className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:border-teal-600"
              >
                <option value="all">جميع المجموعات</option>
                {state.groups.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name}
                  </option>
                ))}
              </select>
              <select
                value={studentTeacherFilter}
                onChange={(e) => setStudentTeacherFilter(e.target.value)}
                aria-label="تصفية تقرير الطلاب حسب المدرس"
                className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:border-teal-600"
              >
                <option value="all">جميع المدرسين</option>
                {state.teachers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {studentReports.length === 0 ? (
            <div className="p-10 text-center text-sm text-slate-500">
              لا يوجد طلاب في النطاق المحدد لعرض التقرير.
            </div>
          ) : (
            <div className="overflow-x-auto print-table-wrapper">
              <table className="w-full text-right text-sm">
                <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-5 font-medium">الكود</th>
                    <th className="py-3 px-4 font-medium">اسم الطالب</th>
                    <th className="py-3 px-4 font-medium">المجموعة / المدرس</th>
                    <th className="py-3 px-4 font-medium text-left">الاختبارات</th>
                    <th className="py-3 px-4 font-medium text-left">المتوسط</th>
                    <th className="py-3 px-4 font-medium text-left">أعلى / أدنى</th>
                    <th className="py-3 px-4 font-medium">التقدير</th>
                    <th className="py-3 px-5 font-medium text-left no-print">طباعة فردية</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/80">
                  {studentReports.map((r) => {
                    const band =
                      r.averagePercentage !== null
                        ? getPerformanceBand(r.averagePercentage)
                        : null;
                    return (
                      <tr key={r.student.id} className="hover:bg-slate-50/70">
                        <td className="py-3.5 px-5 font-mono tabular-nums text-xs font-semibold text-teal-800 whitespace-nowrap">
                          {r.student.code}
                        </td>
                        <td className="py-3.5 px-4 font-semibold text-slate-900">
                          {r.student.name}
                        </td>
                        <td className="py-3.5 px-4 text-xs text-slate-600">
                          <div>{r.groupName}</div>
                          <div className="text-slate-400 mt-0.5">{r.teacherName}</div>
                        </td>
                        <td className="py-3.5 px-4 text-left font-mono tabular-nums text-xs text-slate-700">
                          {r.gradedCount}
                        </td>
                        <td className="py-3.5 px-4 text-left font-mono tabular-nums font-bold text-slate-900">
                          {r.averagePercentage !== null ? `${r.averagePercentage}%` : '—'}
                        </td>
                        <td className="py-3.5 px-4 text-left font-mono tabular-nums text-xs text-slate-600 whitespace-nowrap">
                          {r.highestPercentage !== null && r.lowestPercentage !== null
                            ? `${r.highestPercentage}% / ${r.lowestPercentage}%`
                            : '—'}
                        </td>
                        <td className="py-3.5 px-4 text-xs font-semibold">
                          {band ? (
                            <span className={band.textClass}>{band.label}</span>
                          ) : (
                            <span className="text-slate-400">لم يُقيّم</span>
                          )}
                        </td>
                        <td className="py-3.5 px-5 text-left no-print whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => handlePrintSingleStudent(r)}
                            className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-700 hover:text-teal-900 px-2.5 py-1.5 hover:bg-teal-50 rounded-md transition-colors"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>تقرير الطالب</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      {/* TAB 2: Teacher Performance Report */}
      {activeTab === 'teachers' && (
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden print-section-card">
          <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 no-print">
            <div>
              <h3 className="text-base font-bold text-slate-900">تقرير أداء المدرسين والمجموعات</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                مقارنة نشاط التصحيح ومتوسط نتائج الطلاب ونسب النجاح لكل مدرس
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={teacherSearch}
                  onChange={(e) => setTeacherSearch(e.target.value)}
                  placeholder="بحث باسم المدرس..."
                  className="pr-8 pl-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
                />
              </div>
              <select
                value={teacherSubjectFilter}
                onChange={(e) => setTeacherSubjectFilter(e.target.value)}
                aria-label="تصفية تقرير المدرسين حسب المادة"
                className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:border-teal-600"
              >
                <option value="all">جميع المواد</option>
                {state.subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {teacherReports.length === 0 ? (
            <div className="p-10 text-center text-sm text-slate-500">
              لا يوجد مدرسون مطابقون لمعايير التصفية الحالية.
            </div>
          ) : (
            <div className="overflow-x-auto print-table-wrapper">
              <table className="w-full text-right text-sm">
                <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-6 font-medium">المدرس</th>
                    <th className="py-3 px-4 font-medium">المواد</th>
                    <th className="py-3 px-4 font-medium text-left">المجموعات</th>
                    <th className="py-3 px-4 font-medium text-left">الطلاب</th>
                    <th className="py-3 px-4 font-medium text-left">الاختبارات</th>
                    <th className="py-3 px-4 font-medium text-left">أوراق مصححة</th>
                    <th className="py-3 px-4 font-medium text-left">متوسط الدرجات</th>
                    <th className="py-3 px-6 font-medium text-left">نسبة النجاح</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/80">
                  {teacherReports.map((r) => (
                    <tr key={r.teacher.id} className="hover:bg-slate-50/70">
                      <td className="py-4 px-6">
                        <div className="font-semibold text-slate-900">{r.teacher.name}</div>
                        <div className="text-xs text-slate-500 mt-0.5">
                          {r.teacher.specialization}
                        </div>
                      </td>
                      <td className="py-4 px-4 text-xs text-slate-700">
                        {r.subjectsLabel || '—'}
                      </td>
                      <td className="py-4 px-4 text-left font-mono tabular-nums text-slate-800">
                        {r.groupsCount}
                      </td>
                      <td className="py-4 px-4 text-left font-mono tabular-nums text-slate-800">
                        {r.studentsCount}
                      </td>
                      <td className="py-4 px-4 text-left font-mono tabular-nums text-slate-800">
                        {r.assignmentsCount}
                      </td>
                      <td className="py-4 px-4 text-left font-mono tabular-nums text-slate-800">
                        {r.gradedCount}
                      </td>
                      <td className="py-4 px-4 text-left font-mono tabular-nums font-bold text-teal-800">
                        {r.avgScore !== null ? `${r.avgScore}%` : '—'}
                      </td>
                      <td className="py-4 px-6 text-left font-mono tabular-nums font-semibold text-emerald-700">
                        {r.passRate !== null ? `${r.passRate}%` : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      {/* TAB 3: Groups Performance Report */}
      {activeTab === 'groups' && (
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden print-section-card">
          <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 no-print">
            <div>
              <h3 className="text-base font-bold text-slate-900">تقرير أداء المجموعات الدراسية</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                مؤشرات الالتزام، السعة، متوسط الدرجات، ونسبة النجاح لكل مجموعة
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={groupSubjectFilter}
                onChange={(e) => setGroupSubjectFilter(e.target.value)}
                aria-label="تصفية تقرير المجموعات حسب المادة"
                className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:border-teal-600"
              >
                <option value="all">جميع المواد</option>
                {state.subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
              <select
                value={groupTeacherFilter}
                onChange={(e) => setGroupTeacherFilter(e.target.value)}
                aria-label="تصفية تقرير المجموعات حسب المدرس"
                className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:border-teal-600"
              >
                <option value="all">جميع المدرسين</option>
                {state.teachers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {groupReports.length === 0 ? (
            <div className="p-10 text-center text-sm text-slate-500">
              لا توجد مجموعات مطابقة لمعايير التصفية الحالية.
            </div>
          ) : (
            <div className="overflow-x-auto print-table-wrapper">
              <table className="w-full text-right text-sm">
                <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-6 font-medium">المجموعة والصف</th>
                    <th className="py-3 px-4 font-medium">المدرس والمادة</th>
                    <th className="py-3 px-4 font-medium">المواعيد</th>
                    <th className="py-3 px-4 font-medium text-left">الطلاب / السعة</th>
                    <th className="py-3 px-4 font-medium text-left">الاختبارات</th>
                    <th className="py-3 px-4 font-medium text-left">أوراق مصححة</th>
                    <th className="py-3 px-4 font-medium text-left">المتوسط</th>
                    <th className="py-3 px-6 font-medium text-left">نسبة النجاح</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/80">
                  {groupReports.map((r) => (
                    <tr key={r.group.id} className="hover:bg-slate-50/70">
                      <td className="py-3.5 px-6">
                        <div className="font-semibold text-slate-900">{r.group.name}</div>
                        <div className="text-xs text-slate-500 mt-0.5">{r.group.gradeLevel}</div>
                      </td>
                      <td className="py-3.5 px-4 text-xs">
                        <div className="font-medium text-slate-800">{r.teacherName}</div>
                        <div className="text-slate-500 mt-0.5">{r.subjectName}</div>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-600">
                        {r.group.schedule || '—'}
                      </td>
                      <td className="py-3.5 px-4 text-left font-mono tabular-nums text-xs text-slate-800">
                        {r.enrolled} / {r.group.capacity}
                      </td>
                      <td className="py-3.5 px-4 text-left font-mono tabular-nums text-slate-800">
                        {r.assignmentsCount}
                      </td>
                      <td className="py-3.5 px-4 text-left font-mono tabular-nums text-slate-800">
                        {r.gradedCount}
                      </td>
                      <td className="py-3.5 px-4 text-left font-mono tabular-nums font-bold text-teal-800">
                        {r.avg !== null ? `${r.avg}%` : '—'}
                      </td>
                      <td className="py-3.5 px-6 text-left font-mono tabular-nums font-semibold text-emerald-700">
                        {r.passRate !== null ? `${r.passRate}%` : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      {/* TAB 4: Detailed Grades & Results Report */}
      {activeTab === 'results' && (
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden print-section-card">
          <div className="px-6 py-4 border-b border-slate-200 flex flex-col lg:flex-row lg:items-center justify-between gap-3 no-print">
            <div>
              <h3 className="text-base font-bold text-slate-900">كشف النتائج والدرجات التفصيلي</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                جميع أوراق الإجابة المصححة قابلة للتصفية والطباعة والتصدير بصيغة CSV
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={resultSearch}
                  onChange={(e) => setResultSearch(e.target.value)}
                  placeholder="بحث بالطالب أو الاختبار..."
                  className="pr-8 pl-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
                />
              </div>
              <select
                value={resultAssignmentFilter}
                onChange={(e) => setResultAssignmentFilter(e.target.value)}
                aria-label="تصفية النتائج حسب الاختبار"
                className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:border-teal-600 max-w-[220px]"
              >
                <option value="all">جميع الواجبات والامتحانات</option>
                {state.assignments.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.title}
                  </option>
                ))}
              </select>
              <select
                value={resultGroupFilter}
                onChange={(e) => setResultGroupFilter(e.target.value)}
                aria-label="تصفية النتائج حسب المجموعة"
                className="px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:border-teal-600"
              >
                <option value="all">جميع المجموعات</option>
                {state.groups.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {resultsReports.length === 0 ? (
            <div className="p-10 text-center text-sm text-slate-500">
              لا توجد نتائج مصححة مطابقة لمعايير التصفية الحالية.
            </div>
          ) : (
            <div className="overflow-x-auto print-table-wrapper">
              <table className="w-full text-right text-sm">
                <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-5 font-medium">الطالب</th>
                    <th className="py-3 px-4 font-medium">الواجب / الامتحان</th>
                    <th className="py-3 px-4 font-medium">المجموعة</th>
                    <th className="py-3 px-4 font-medium text-left">الدرجة</th>
                    <th className="py-3 px-4 font-medium text-left">النسبة</th>
                    <th className="py-3 px-4 font-medium text-left">صحيح / خطأ</th>
                    <th className="py-3 px-4 font-medium">التقدير</th>
                    <th className="py-3 px-5 font-medium">تاريخ التصحيح</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/80">
                  {resultsReports.map((r) => {
                    const band = getPerformanceBand(r.submission.percentage);
                    return (
                      <tr key={r.submission.id} className="hover:bg-slate-50/70">
                        <td className="py-3.5 px-5">
                          <div className="font-semibold text-slate-900">
                            {r.student?.name ?? 'طالب غير موجود'}
                          </div>
                          <div className="text-xs text-teal-800 font-mono">
                            {r.student?.code ?? '—'}
                          </div>
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="text-xs font-medium text-slate-900">
                            {r.assignment?.title ?? '—'}
                          </div>
                          <div className="text-xs text-slate-500 mt-0.5">
                            {r.subject?.name ?? '—'} ·{' '}
                            {r.assignment?.kind === 'exam' ? 'امتحان' : 'واجب'}
                          </div>
                        </td>
                        <td className="py-3.5 px-4 text-xs text-slate-600">
                          {r.group?.name ?? '—'}
                        </td>
                        <td className="py-3.5 px-4 text-left font-mono tabular-nums text-xs font-bold text-slate-900 whitespace-nowrap">
                          {r.submission.earnedMarks} / {r.submission.totalMarks}
                        </td>
                        <td className="py-3.5 px-4 text-left font-mono tabular-nums font-bold text-teal-800">
                          {r.submission.percentage}%
                        </td>
                        <td className="py-3.5 px-4 text-left font-mono tabular-nums text-xs text-slate-700 whitespace-nowrap">
                          {r.submission.correctCount} / {r.submission.wrongCount}
                        </td>
                        <td className={`py-3.5 px-4 text-xs font-semibold ${band.textClass}`}>
                          {band.label}
                        </td>
                        <td className="py-3.5 px-5 text-xs text-slate-600 whitespace-nowrap">
                          {formatArabicDate(r.submission.gradedAt)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      {/* Official A4 Print Footer */}
      {activeTab !== 'integrations' && <PrintDocumentFooter />}

      {/* TAB 5: Integrations Status */}
      {activeTab === 'integrations' && (
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200">
            <h3 className="text-base font-bold text-slate-900">حالة التكاملات والخدمات السحابية</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              قاعدة البيانات والمصادقة مرتبطتان فعلياً بـ Supabase، بينما تبقى الخدمات الإضافية مهيأة معمارياً للربط المستقبلي.
            </p>
          </div>
          <ul className="divide-y divide-slate-200/80">
            {FUTURE_INTEGRATIONS.map((mod) => (
              <li
                key={mod.id}
                className="px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-slate-900">{mod.title}</div>
                  <p className="text-xs text-slate-600 mt-1">{mod.description}</p>
                </div>
                <div className="text-xs text-left shrink-0">
                  {mod.status === 'connected' ? (
                    <div className="font-semibold text-emerald-700">متصل ومفعّل</div>
                  ) : (
                    <div className="font-medium text-amber-700">غير متصل بعد</div>
                  )}
                  <div className="font-mono text-slate-400 mt-0.5">{mod.plannedProvider}</div>
                </div>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* Hidden Portaled Single-Student A4 Report Sheet */}
      {printingStudentSummary && (
        <StudentA4ReportSheet
          summary={printingStudentSummary}
          submissions={printingStudentSubmissions}
        />
      )}
    </div>
  );
};
