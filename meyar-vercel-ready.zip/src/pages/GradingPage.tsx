import React, { useEffect, useMemo, useState } from 'react';
import {
  Save,
  CheckCircle2,
  XCircle,
  MinusCircle,
  ChevronLeft,
  ChevronRight,
  Trash2,
  Download,
} from 'lucide-react';
import { useMeyar } from '../context/MeyarContext';
import { MCQ_OPTION_LABELS, type MCQOptionKey } from '../types/domain';
import { evaluateMCQSubmission, getPerformanceBand } from '../utils/grading';
import {
  buildExportFilename,
  buildGradesCsvData,
  downloadCsvFile,
} from '../utils/exportCsv';

const OPTION_KEYS: MCQOptionKey[] = ['A', 'B', 'C', 'D'];

export const GradingPage: React.FC = () => {
  const {
    state,
    navPayload,
    clearNavPayload,
    saveSubmission,
    deleteSubmission,
    navigate,
    showToast,
  } = useMeyar();

  const [selectedAssignmentId, setSelectedAssignmentId] = useState<string>(
    navPayload.assignmentId ?? state.assignments[0]?.id ?? ''
  );
  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    navPayload.studentId ?? ''
  );
  const [confirmDeleteSub, setConfirmDeleteSub] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Consume deep-link navigation payload once, then clear it so user can freely switch students/assignments
  useEffect(() => {
    if (!navPayload.assignmentId && !navPayload.studentId) return;

    if (navPayload.assignmentId) {
      setSelectedAssignmentId(navPayload.assignmentId);
    } else if (navPayload.studentId) {
      const st = state.students.find((s) => s.id === navPayload.studentId);
      if (st) {
        const matchingAsg = state.assignments.find((a) => a.groupId === st.groupId);
        if (matchingAsg) {
          setSelectedAssignmentId(matchingAsg.id);
        }
      }
    }

    if (navPayload.studentId) {
      setSelectedStudentId(navPayload.studentId);
    }

    clearNavPayload();
  }, [navPayload.assignmentId, navPayload.studentId, state.students, state.assignments, clearNavPayload]);

  const selectedAssignment = useMemo(
    () =>
      state.assignments.find((a) => a.id === selectedAssignmentId) ??
      state.assignments[0] ??
      null,
    [state.assignments, selectedAssignmentId]
  );

  const eligibleStudents = useMemo(() => {
    if (!selectedAssignment) return [];
    const inGroup = state.students.filter((st) => st.groupId === selectedAssignment.groupId);
    return inGroup.length > 0 ? inGroup : state.students;
  }, [selectedAssignment, state.students]);

  useEffect(() => {
    if (eligibleStudents.length === 0) {
      if (selectedStudentId !== '') setSelectedStudentId('');
      return;
    }
    if (!eligibleStudents.some((s) => s.id === selectedStudentId)) {
      setSelectedStudentId(eligibleStudents[0].id);
    }
  }, [eligibleStudents, selectedStudentId]);

  const existingSubmission = useMemo(() => {
    if (!selectedAssignment || !selectedStudentId) return null;
    return (
      state.submissions.find(
        (s) =>
          s.assignmentId === selectedAssignment.id && s.studentId === selectedStudentId
      ) ?? null
    );
  }, [state.submissions, selectedAssignment, selectedStudentId]);

  const [answers, setAnswers] = useState<Record<string, MCQOptionKey | null>>({});
  const [notes, setNotes] = useState('');

  useEffect(() => {
    setConfirmDeleteSub(false);
    if (!selectedAssignment) {
      setAnswers({});
      setNotes('');
      return;
    }
    if (existingSubmission) {
      setAnswers({ ...existingSubmission.answers });
      setNotes(existingSubmission.notes ?? '');
    } else {
      const empty: Record<string, MCQOptionKey | null> = {};
      for (const q of selectedAssignment.questions) {
        empty[q.id] = null;
      }
      setAnswers(empty);
      setNotes('');
    }
  }, [selectedAssignment, selectedStudentId, existingSubmission]);

  const liveResult = useMemo(() => {
    if (!selectedAssignment) return null;
    return evaluateMCQSubmission(selectedAssignment, answers);
  }, [selectedAssignment, answers]);

  const handleToggleOption = (questionId: string, opt: MCQOptionKey) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: prev[questionId] === opt ? null : opt,
    }));
  };

  const handleSaveGrade = async () => {
    if (!selectedAssignment || !selectedStudentId || isSaving) return;
    setIsSaving(true);
    try {
      await saveSubmission(
        selectedAssignment.id,
        selectedStudentId,
        answers,
        notes.trim() || undefined
      );
    } finally {
      setIsSaving(false);
    }
  };

  const currentStudentIndex = eligibleStudents.findIndex(
    (s) => s.id === selectedStudentId
  );
  const hasPrevStudent = currentStudentIndex > 0;
  const hasNextStudent =
    currentStudentIndex >= 0 && currentStudentIndex < eligibleStudents.length - 1;

  const handlePrevStudent = () => {
    if (hasPrevStudent) {
      setSelectedStudentId(eligibleStudents[currentStudentIndex - 1].id);
    }
  };

  const handleNextStudent = () => {
    if (hasNextStudent) {
      setSelectedStudentId(eligibleStudents[currentStudentIndex + 1].id);
    }
  };

  const selectedStudent =
    eligibleStudents.find((s) => s.id === selectedStudentId) ?? null;
  const band = liveResult ? getPerformanceBand(liveResult.percentage) : null;

  const selectedAssignmentSubmissions = useMemo(() => {
    if (!selectedAssignment) return [];
    return state.submissions.filter((s) => s.assignmentId === selectedAssignment.id);
  }, [state.submissions, selectedAssignment]);

  const handleExportAssignmentGrades = () => {
    if (!selectedAssignment) return;
    const studentMap = new Map(state.students.map((s) => [s.id, s]));
    const subject = state.subjects.find((s) => s.id === selectedAssignment.subjectId);
    const group = state.groups.find((g) => g.id === selectedAssignment.groupId);
    const teacher = state.teachers.find((t) => t.id === selectedAssignment.teacherId);

    const exportRows = selectedAssignmentSubmissions.map((submission) => ({
      submission,
      student: studentMap.get(submission.studentId),
      assignment: selectedAssignment,
      subject,
      group,
      teacher,
    }));

    const { headers, rows } = buildGradesCsvData(exportRows);
    const filename = buildExportFilename('grades', {
      detailSlug: selectedAssignment.id,
      filtered: true,
    });
    const res = downloadCsvFile(filename, headers, rows);
    showToast(`تم تصدير ${res.rowCount} درجة لهذا الاختبار إلى ${res.filename}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">تصحيح الإجابات</h2>
          <p className="text-sm text-slate-500 mt-1">
            أدخل إجابات الطالب لأسئلة الاختيار من متعدد ليقوم النظام بمقارنتها مع نموذج الإجابة وحساب الدرجة بدقة فورية.
          </p>
        </div>
        {selectedAssignment && (
          <button
            type="button"
            disabled={selectedAssignmentSubmissions.length === 0}
            onClick={handleExportAssignmentGrades}
            className="inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Download className="w-4 h-4" />
            <span>
              تصدير درجات الاختبار ({selectedAssignmentSubmissions.length})
            </span>
          </button>
        )}
      </div>

      {/* Assignment Selection Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div className="flex-1 max-w-xl">
          <label className="block text-xs font-semibold text-slate-600 mb-1.5">
            الاختبار أو الواجب المطلوب تصحيحه
          </label>
          <select
            value={selectedAssignment?.id ?? ''}
            onChange={(e) => setSelectedAssignmentId(e.target.value)}
            disabled={state.assignments.length === 0}
            className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-lg bg-white text-slate-900 focus:outline-none focus:border-teal-600 disabled:bg-slate-50 disabled:text-slate-400"
          >
            {state.assignments.length === 0 ? (
              <option value="">لا توجد اختبارات مسجلة</option>
            ) : (
              state.assignments.map((asg) => (
                <option key={asg.id} value={asg.id}>
                  {asg.title} ({asg.totalMarks} درجة)
                </option>
              ))
            )}
          </select>
        </div>

        {selectedAssignment && (
          <div className="text-xs text-slate-500 flex items-center gap-3">
            <span>
              إجمالي الأسئلة:{' '}
              <strong className="font-mono tabular-nums text-slate-900">
                {selectedAssignment.questions.length}
              </strong>
            </span>
            <span aria-hidden="true">·</span>
            <span>
              الدرجة النهائية:{' '}
              <strong className="font-mono tabular-nums text-slate-900">
                {selectedAssignment.totalMarks}
              </strong>
            </span>
          </div>
        )}
      </div>

      {!selectedAssignment ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-3">
          <p className="text-sm text-slate-600">لا توجد اختبارات متاحة للتصحيح حالياً.</p>
          <button
            type="button"
            onClick={() => navigate('assignments')}
            className="px-4 py-2 text-xs font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg"
          >
            إنشاء واجب أو امتحان جديد
          </button>
        </div>
      ) : eligibleStudents.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-3">
          <p className="text-sm text-slate-600">
            لا يوجد طلاب مسجلون حالياً لتصحيح إجاباتهم.
          </p>
          <button
            type="button"
            onClick={() => navigate('students')}
            className="px-4 py-2 text-xs font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg"
          >
            إضافة طلاب
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Student Roster Sidebar */}
          <aside className="lg:col-span-4 bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">طلاب المجموعة</h3>
              <span className="text-xs text-slate-500 font-mono tabular-nums">
                {eligibleStudents.length} طالب
              </span>
            </div>
            <ul className="divide-y divide-slate-200/80 max-h-[540px] overflow-y-auto">
              {eligibleStudents.map((st) => {
                const sub = state.submissions.find(
                  (s) => s.assignmentId === selectedAssignment.id && s.studentId === st.id
                );
                const isSelected = st.id === selectedStudentId;
                return (
                  <li key={st.id}>
                    <button
                      type="button"
                      onClick={() => setSelectedStudentId(st.id)}
                      className={`w-full text-right px-5 py-3.5 flex items-center justify-between gap-3 transition-colors ${
                        isSelected
                          ? 'bg-teal-50/80 text-teal-950'
                          : 'hover:bg-slate-50 text-slate-800'
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="text-sm font-semibold truncate">{st.name}</div>
                        <div className="text-xs text-slate-500 font-mono mt-0.5">
                          {st.code}
                        </div>
                      </div>
                      <div className="text-left shrink-0">
                        {sub ? (
                          <div>
                            <div className="font-mono tabular-nums text-xs font-bold text-teal-800">
                              {sub.earnedMarks}/{sub.totalMarks}
                            </div>
                            <div className="font-mono tabular-nums text-[11px] text-emerald-700">
                              {sub.percentage}% · مصحح
                            </div>
                          </div>
                        ) : (
                          <span className="text-xs text-amber-700 font-medium">
                            بانتظار التصحيح
                          </span>
                        )}
                      </div>
                    </button>
                  </li>
                );
              })}
            </ul>
          </aside>

          {/* Interactive Grading Sheet */}
          <section className="lg:col-span-8 space-y-5">
            {selectedStudent && liveResult && band && (
              <>
                {/* Live Computed Score Strip */}
                <div className="bg-white border border-slate-200 rounded-xl p-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
                    <div>
                      <div className="text-xs text-slate-500 font-mono">
                        {selectedStudent.code} <span aria-hidden="true">·</span>{' '}
                        <span className="font-sans">
                          {existingSubmission ? 'تحديث درجة مرصودة' : 'تصحيح جديد'}
                        </span>
                      </div>
                      <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                        {selectedStudent.name}
                      </h3>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        disabled={isSaving}
                        onClick={handleSaveGrade}
                        className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap"
                      >
                        <Save className="w-4 h-4" />
                        <span>{isSaving ? 'جاري الحفظ...' : 'حفظ النتيجة'}</span>
                      </button>

                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          disabled={!hasPrevStudent}
                          onClick={handlePrevStudent}
                          className="inline-flex items-center gap-1 px-2.5 py-2 text-xs font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap disabled:opacity-40 disabled:cursor-not-allowed"
                          aria-label="الطالب السابق"
                        >
                          <ChevronRight className="w-4 h-4" />
                          <span>السابق</span>
                        </button>
                        <button
                          type="button"
                          disabled={!hasNextStudent}
                          onClick={handleNextStudent}
                          className="inline-flex items-center gap-1 px-2.5 py-2 text-xs font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap disabled:opacity-40 disabled:cursor-not-allowed"
                          aria-label="الطالب التالي"
                        >
                          <span>التالي</span>
                          <ChevronLeft className="w-4 h-4" />
                        </button>
                      </div>

                      {existingSubmission &&
                        (confirmDeleteSub ? (
                          <div className="inline-flex items-center gap-2 text-xs mr-1">
                            <button
                              type="button"
                              onClick={async () => {
                                await deleteSubmission(existingSubmission.id);
                                setConfirmDeleteSub(false);
                              }}
                              className="font-medium text-red-700 hover:underline whitespace-nowrap"
                            >
                              تأكيد الحذف
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteSub(false)}
                              className="text-slate-500 hover:underline whitespace-nowrap"
                            >
                              إلغاء
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteSub(true)}
                            className="p-2 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                            aria-label="حذف سجل التصحيح"
                            title="حذف سجل التصحيح"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        ))}
                    </div>
                  </div>

                  {/* Live Score Metrics */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4">
                    <div>
                      <p className="text-xs text-slate-500">الدرجة المحسوبة</p>
                      <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                        {liveResult.earnedMarks}{' '}
                        <span className="text-sm font-normal text-slate-400">
                          / {liveResult.totalMarks}
                        </span>
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">النسبة والتقدير</p>
                      <p className="text-2xl font-bold font-mono tabular-nums text-teal-800 mt-1">
                        {liveResult.percentage}%
                      </p>
                      <p className={`text-xs font-medium ${band.textClass}`}>{band.label}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">صحيح / خطأ</p>
                      <p className="text-sm font-semibold font-mono tabular-nums mt-2">
                        <span className="text-emerald-700">{liveResult.correctCount} صحيح</span>
                        <span className="text-slate-300 mx-1.5">·</span>
                        <span className="text-red-700">{liveResult.wrongCount} خطأ</span>
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">بدون إجابة</p>
                      <p className="text-sm font-semibold font-mono tabular-nums text-slate-600 mt-2">
                        {liveResult.unansweredCount} سؤال
                      </p>
                    </div>
                  </div>
                </div>

                {/* Per-Question Bubble Sheet */}
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                  <div className="px-6 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs text-slate-500">
                    <span className="font-semibold text-slate-700">ورقة إجابة الطالب (MCQ)</span>
                    <span>انقر على اختيار الطالب لكل سؤال · انقر مجدداً للإلغاء</span>
                  </div>

                  <div className="divide-y divide-slate-200/80">
                    {selectedAssignment.questions.map((q) => {
                      const chosen = answers[q.id] ?? null;
                      const isCorrect = chosen !== null && chosen === q.correctOption;
                      const isWrong = chosen !== null && chosen !== q.correctOption;

                      return (
                        <div
                          key={q.id}
                          className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                        >
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2 text-xs text-slate-500">
                              <span className="font-mono font-bold text-slate-900">
                                س{q.number}
                              </span>
                              <span aria-hidden="true">·</span>
                              <span>{q.topic}</span>
                              <span aria-hidden="true">·</span>
                              <span className="font-mono tabular-nums">{q.marks} درجات</span>
                              <span aria-hidden="true">·</span>
                              <span className="text-teal-800 font-medium">
                                النموذج: ({MCQ_OPTION_LABELS[q.correctOption]})
                              </span>
                            </div>
                            <p className="text-sm text-slate-800 mt-1">{q.prompt}</p>
                          </div>

                          <div className="flex items-center gap-3 shrink-0">
                            <div className="flex items-center gap-1.5">
                              {OPTION_KEYS.map((optKey) => {
                                const selected = chosen === optKey;
                                let btnStyle =
                                  'bg-white text-slate-700 border-slate-200 hover:border-slate-400';
                                if (selected && isCorrect) {
                                  btnStyle =
                                    'bg-emerald-700 text-white border-emerald-700';
                                } else if (selected && isWrong) {
                                  btnStyle = 'bg-red-700 text-white border-red-700';
                                }

                                return (
                                  <button
                                    key={optKey}
                                    type="button"
                                    onClick={() => handleToggleOption(q.id, optKey)}
                                    className={`w-9 h-9 rounded-lg text-xs font-bold border transition-colors ${btnStyle}`}
                                  >
                                    {MCQ_OPTION_LABELS[optKey]}
                                  </button>
                                );
                              })}
                            </div>

                            <div className="w-20 text-left text-xs font-medium flex items-center justify-end gap-1">
                              {isCorrect && (
                                <span className="inline-flex items-center gap-1 text-emerald-700">
                                  <CheckCircle2 className="w-4 h-4" />
                                  <span className="font-mono tabular-nums">+{q.marks}</span>
                                </span>
                              )}
                              {isWrong && (
                                <span className="inline-flex items-center gap-1 text-red-700">
                                  <XCircle className="w-4 h-4" />
                                  <span className="font-mono tabular-nums">0</span>
                                </span>
                              )}
                              {chosen === null && (
                                <span className="inline-flex items-center gap-1 text-slate-400">
                                  <MinusCircle className="w-4 h-4" />
                                  <span>فارغ</span>
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Optional Teacher Feedback Notes */}
                  <div className="p-5 border-t border-slate-200 bg-slate-50/50 space-y-3">
                    <label className="block text-xs font-semibold text-slate-700">
                      ملاحظات المدرس للطالب (اختياري)
                    </label>
                    <input
                      type="text"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="مثال: أداء ممتاز في التفاضل، يرجى مراجعة مسائل الأعداد المركبة..."
                      className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
                    />
                    <p className="text-xs text-slate-500">
                      ملاحظة: تصحيح الأسئلة المقالية بالذكاء الاصطناعي وإرسال النتائج عبر تيليجرام جاهزان معمارياً للتكامل لاحقاً وغير مفعلين حالياً.
                    </p>
                  </div>
                </div>
              </>
            )}
          </section>
        </div>
      )}
    </div>
  );
};
