import React, { useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { useMeyar } from '../context/MeyarContext';
import type { Subject } from '../types/domain';
import { Modal } from '../components/ui/Modal';

interface SubjectFormState {
  name: string;
  code: string;
  stage: string;
  topicsText: string;
  description: string;
}

export const SubjectsPage: React.FC = () => {
  const { state, addSubject, updateSubject, deleteSubject } = useMeyar();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [form, setForm] = useState<SubjectFormState>({
    name: '',
    code: '',
    stage: 'الثالث الثانوي',
    topicsText: '',
    description: '',
  });

  const openCreateModal = () => {
    setEditingSubject(null);
    setForm({
      name: '',
      code: '',
      stage: 'الثالث الثانوي',
      topicsText: '',
      description: '',
    });
    setModalOpen(true);
  };

  const openEditModal = (subject: Subject) => {
    setEditingSubject(subject);
    setForm({
      name: subject.name,
      code: subject.code,
      stage: subject.stage,
      topicsText: subject.topics.join('، '),
      description: subject.description,
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || isSubmitting) return;
    const topics = form.topicsText
      .split(/[،,]/)
      .map((t) => t.trim())
      .filter(Boolean);

    const payload = {
      name: form.name.trim(),
      code: form.code.trim().toUpperCase() || 'SUB-101',
      stage: form.stage.trim(),
      topics: topics.length > 0 ? topics : ['موضوعات عامة'],
      description: form.description.trim(),
    };

    setIsSubmitting(true);
    try {
      const ok = editingSubject
        ? await updateSubject(editingSubject.id, payload)
        : await addSubject(payload);
      if (ok) {
        setModalOpen(false);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">المواد الدراسية</h2>
          <p className="text-sm text-slate-500 mt-1">
            تعريف المواد والموضوعات المنهجية المستخدمة في تصنيف الأسئلة وتحليل نقاط الضعف.
          </p>
        </div>
        <button
          type="button"
          onClick={openCreateModal}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة مادة دراسية</span>
        </button>
      </div>

      {state.subjects.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-3">
          <p className="text-sm text-slate-600">لا توجد مواد دراسية مسجلة بعد.</p>
          <button
            type="button"
            onClick={openCreateModal}
            className="px-4 py-2 text-xs font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg"
          >
            إضافة أول مادة دراسية
          </button>
        </div>
      ) : (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {state.subjects.map((sub) => {
          const teacherCount = state.teachers.filter((t) =>
            t.subjectIds.includes(sub.id)
          ).length;
          const groupCount = state.groups.filter((g) => g.subjectId === sub.id).length;
          const assignmentCount = state.assignments.filter(
            (a) => a.subjectId === sub.id
          ).length;

          return (
            <article
              key={sub.id}
              className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between gap-5"
            >
              <div>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="text-xs text-slate-500 font-mono">
                      {sub.code} <span aria-hidden="true">·</span>{' '}
                      <span className="font-sans">{sub.stage}</span>
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 mt-1">{sub.name}</h3>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {confirmDeleteId === sub.id ? (
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={async () => {
                            await deleteSubject(sub.id);
                            setConfirmDeleteId(null);
                          }}
                          className="text-xs font-medium text-red-700 hover:underline"
                        >
                          تأكيد
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(null)}
                          className="text-xs text-slate-500 hover:underline"
                        >
                          إلغاء
                        </button>
                      </div>
                    ) : (
                      <>
                        <button
                          type="button"
                          onClick={() => openEditModal(sub)}
                          className="p-2 text-slate-500 hover:text-teal-700 hover:bg-slate-100 rounded-lg transition-colors"
                          aria-label={`تعديل ${sub.name}`}
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(sub.id)}
                          className="p-2 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                          aria-label={`حذف ${sub.name}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {sub.description && (
                  <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                    {sub.description}
                  </p>
                )}

                <div className="mt-4 pt-4 border-t border-slate-100">
                  <p className="text-xs font-semibold text-slate-500 mb-1.5">
                    الوحدات والموضوعات المنهجية:
                  </p>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    {sub.topics.join(' · ')}
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center gap-5 text-xs text-slate-500">
                <span>
                  المدرسون: <strong className="font-mono tabular-nums text-slate-900">{teacherCount}</strong>
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  المجموعات: <strong className="font-mono tabular-nums text-slate-900">{groupCount}</strong>
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  الاختبارات والواجبات:{' '}
                  <strong className="font-mono tabular-nums text-slate-900">{assignmentCount}</strong>
                </span>
              </div>
            </article>
          );
        })}
      </div>
      )}

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingSubject ? 'تعديل المادة الدراسية' : 'إضافة مادة دراسية جديدة'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                اسم المادة *
              </label>
              <input
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="مثال: الأحياء"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                رمز المادة
              </label>
              <input
                type="text"
                value={form.code}
                onChange={(e) => setForm({ ...form, code: e.target.value })}
                placeholder="BIO-301"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-teal-600"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              المرحلة الدراسية
            </label>
            <input
              type="text"
              value={form.stage}
              onChange={(e) => setForm({ ...form, stage: e.target.value })}
              placeholder="الثالث الثانوي"
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              الموضوعات المنهجية (افصل بينها بفاصلة)
            </label>
            <input
              type="text"
              value={form.topicsText}
              onChange={(e) => setForm({ ...form, topicsText: e.target.value })}
              placeholder="الدعامة والحركة، التنسيق الهرموني، التكاثر، المناعة"
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              وصف مختصر
            </label>
            <textarea
              rows={2}
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-lg"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 disabled:opacity-60 rounded-lg"
            >
              {isSubmitting
                ? 'جاري الحفظ...'
                : editingSubject
                ? 'حفظ التعديلات'
                : 'إضافة المادة'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
