import React, { useMemo, useState } from 'react';
import { Plus, Search, Pencil, Trash2, Eye, Download, Printer } from 'lucide-react';
import { useMeyar } from '../context/MeyarContext';
import type { Student } from '../types/domain';
import {
  computeStudentSummaries,
  formatArabicDate,
  getPerformanceBand,
} from '../utils/grading';
import {
  buildExportFilename,
  buildStudentsCsvData,
  downloadCsvFile,
} from '../utils/exportCsv';
import {
  StudentA4ReportSheet,
  triggerSingleSheetPrint,
} from '../components/PrintHeader';
import { Modal } from '../components/ui/Modal';

interface StudentFormState {
  code: string;
  name: string;
  groupId: string;
  teacherId: string;
  subjectId: string;
  phone: string;
  guardianPhone: string;
  notes: string;
}

export const StudentsPage: React.FC = () => {
  const {
    state,
    currentTeacher,
    addStudent,
    updateStudent,
    deleteStudent,
    generateNextStudentCode,
    navigate,
    showToast,
  } = useMeyar();

  const [search, setSearch] = useState('');
  const [groupFilter, setGroupFilter] = useState('all');
  const [teacherFilter, setTeacherFilter] = useState('all');
  const [subjectFilter, setSubjectFilter] = useState('all');

  const [modalOpen, setModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [viewingStudentId, setViewingStudentId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [form, setForm] = useState<StudentFormState>({
    code: '',
    name: '',
    groupId: '',
    teacherId: '',
    subjectId: '',
    phone: '',
    guardianPhone: '',
    notes: '',
  });
  const [codeError, setCodeError] = useState('');

  const summaries = useMemo(
    () =>
      computeStudentSummaries(
        state.students,
        state.submissions,
        state.groups,
        state.teachers,
        state.subjects
      ),
    [state.students, state.submissions, state.groups, state.teachers, state.subjects]
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return summaries.filter(({ student, groupName, teacherName, subjectName }) => {
      if (groupFilter !== 'all' && student.groupId !== groupFilter) return false;
      if (teacherFilter !== 'all' && student.teacherId !== teacherFilter) return false;
      if (subjectFilter !== 'all' && student.subjectId !== subjectFilter) return false;
      if (!q) return true;
      return (
        student.name.toLowerCase().includes(q) ||
        student.code.toLowerCase().includes(q) ||
        groupName.toLowerCase().includes(q) ||
        teacherName.toLowerCase().includes(q) ||
        subjectName.toLowerCase().includes(q)
      );
    });
  }, [summaries, search, groupFilter, teacherFilter, subjectFilter]);

  const openCreateModal = () => {
    const defaultGroup = state.groups[0];
    setEditingStudent(null);
    setCodeError('');
    setForm({
      code: generateNextStudentCode(),
      name: '',
      groupId: defaultGroup?.id ?? '',
      teacherId: defaultGroup?.teacherId ?? currentTeacher?.id ?? state.teachers[0]?.id ?? '',
      subjectId: defaultGroup?.subjectId ?? state.subjects[0]?.id ?? '',
      phone: '',
      guardianPhone: '',
      notes: '',
    });
    setModalOpen(true);
  };

  const openEditModal = (student: Student) => {
    setEditingStudent(student);
    setCodeError('');
    setForm({
      code: student.code,
      name: student.name,
      groupId: student.groupId,
      teacherId: student.teacherId,
      subjectId: student.subjectId,
      phone: student.phone ?? '',
      guardianPhone: student.guardianPhone,
      notes: student.notes ?? '',
    });
    setModalOpen(true);
  };

  const handleGroupChange = (newGroupId: string) => {
    const grp = state.groups.find((g) => g.id === newGroupId);
    setForm((prev) => ({
      ...prev,
      groupId: newGroupId,
      teacherId: grp ? grp.teacherId : prev.teacherId,
      subjectId: grp ? grp.subjectId : '',
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    const trimmedCode = form.code.trim().toUpperCase();
    const trimmedName = form.name.trim();
    if (!trimmedCode || !trimmedName) {
      setCodeError(!trimmedCode ? 'يرجى إدخال كود صحيح للطالب' : '');
      return;
    }
    const duplicate = state.students.find(
      (s) => s.code.toUpperCase() === trimmedCode && s.id !== editingStudent?.id
    );
    if (duplicate) {
      setCodeError(`الكود ${trimmedCode} مستخدم بالفعل للطالب ${duplicate.name}`);
      return;
    }

    const payload = {
      ...form,
      code: trimmedCode,
      name: trimmedName,
    };

    setIsSubmitting(true);
    try {
      const ok = editingStudent
        ? await updateStudent(editingStudent.id, payload)
        : await addStudent(payload);
      if (ok) {
        setModalOpen(false);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const inspectedSummary = useMemo(
    () => summaries.find((s) => s.student.id === viewingStudentId) ?? null,
    [summaries, viewingStudentId]
  );

  const inspectedSubmissions = useMemo(() => {
    if (!viewingStudentId) return [];
    const asgMap = new Map(state.assignments.map((a) => [a.id, a]));
    return state.submissions
      .filter((sub) => sub.studentId === viewingStudentId)
      .map((sub) => ({
        sub,
        assignment: asgMap.get(sub.assignmentId),
      }))
      .sort((a, b) => b.sub.gradedAt.localeCompare(a.sub.gradedAt));
  }, [viewingStudentId, state.submissions, state.assignments]);

  const handleExportStudentsCSV = () => {
    const isFiltered =
      search.trim().length > 0 ||
      groupFilter !== 'all' ||
      teacherFilter !== 'all' ||
      subjectFilter !== 'all';
    const { headers, rows } = buildStudentsCsvData(filtered);
    const filename = buildExportFilename('students', { filtered: isFiltered });
    const res = downloadCsvFile(filename, headers, rows);
    showToast(`تم تصدير ${res.rowCount} طالب إلى الملف ${res.filename}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">إدارة الطلاب</h2>
          <p className="text-sm text-slate-500 mt-1">
            سجل الطلاب بأكوادهم الفريدة وربطهم بالمجموعات والمدرسين والمواد الدراسية.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            disabled={filtered.length === 0}
            onClick={handleExportStudentsCSV}
            className="inline-flex items-center justify-center gap-2 px-3.5 py-2.5 text-sm font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Download className="w-4 h-4" />
            <span>تصدير CSV</span>
          </button>
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة طالب جديد</span>
          </button>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 items-center">
          <div className="relative lg:col-span-5">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث باسم الطالب أو الكود (مثال: MYR-1001)..."
              className="w-full pr-9 pl-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
            />
          </div>
          <select
            value={groupFilter}
            onChange={(e) => setGroupFilter(e.target.value)}
            aria-label="تصفية حسب المجموعة"
            className="lg:col-span-3 px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:border-teal-600"
          >
            <option value="all">كل المجموعات</option>
            {state.groups.map((g) => (
              <option key={g.id} value={g.id}>
                {g.name}
              </option>
            ))}
          </select>
          <select
            value={teacherFilter}
            onChange={(e) => setTeacherFilter(e.target.value)}
            aria-label="تصفية حسب المدرس"
            className="lg:col-span-2 px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:border-teal-600"
          >
            <option value="all">كل المدرسين</option>
            {state.teachers.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
          <select
            value={subjectFilter}
            onChange={(e) => setSubjectFilter(e.target.value)}
            aria-label="تصفية حسب المادة"
            className="lg:col-span-2 px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:border-teal-600"
          >
            <option value="all">كل المواد</option>
            {state.subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>

        {filtered.length === 0 ? (
          <div className="p-10 text-center">
            <p className="text-sm text-slate-600">لا يوجد طلاب مطابقون للبحث أو التصفية الحالية.</p>
            <button
              type="button"
              onClick={() => {
                setSearch('');
                setGroupFilter('all');
                setTeacherFilter('all');
                setSubjectFilter('all');
              }}
              className="mt-3 px-4 py-2 text-xs font-medium text-teal-700 border border-teal-200 hover:bg-teal-50 rounded-lg"
            >
              مسح التصفية
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="py-3 px-6 font-medium">الكود</th>
                  <th className="py-3 px-4 font-medium">اسم الطالب</th>
                  <th className="py-3 px-4 font-medium">المجموعة</th>
                  <th className="py-3 px-4 font-medium">المدرس</th>
                  <th className="py-3 px-4 font-medium">المادة</th>
                  <th className="py-3 px-4 font-medium text-left">المتوسط</th>
                  <th className="py-3 px-6 font-medium text-left">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200/80">
                {filtered.map((item) => {
                  const { student, groupName, teacherName, subjectName, averagePercentage, gradedCount } = item;
                  const band =
                    averagePercentage !== null ? getPerformanceBand(averagePercentage) : null;
                  return (
                    <tr key={student.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-6 font-mono tabular-nums text-xs font-semibold text-teal-800 whitespace-nowrap">
                        {student.code}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900">{student.name}</div>
                        <div className="text-xs text-slate-500 font-mono mt-0.5">
                          ولي الأمر: {student.guardianPhone || '—'}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-700">{groupName}</td>
                      <td className="py-3.5 px-4 text-xs text-slate-700 whitespace-nowrap">{teacherName}</td>
                      <td className="py-3.5 px-4 text-xs text-slate-700 whitespace-nowrap">{subjectName}</td>
                      <td className="py-3.5 px-4 text-left whitespace-nowrap">
                        {averagePercentage !== null && band ? (
                          <div>
                            <span className="font-mono tabular-nums font-semibold text-slate-900">
                              {averagePercentage}%
                            </span>
                            <div className={`text-xs ${band.textClass}`}>
                              {band.label} · {gradedCount} اختبار
                            </div>
                          </div>
                        ) : (
                          <span className="text-xs text-slate-400">لم يُصحح بعد</span>
                        )}
                      </td>
                      <td className="py-3.5 px-6 text-left whitespace-nowrap">
                        {confirmDeleteId === student.id ? (
                          <div className="inline-flex items-center gap-2">
                            <button
                              type="button"
                              onClick={async () => {
                                await deleteStudent(student.id);
                                setConfirmDeleteId(null);
                              }}
                              className="text-xs font-medium text-red-700 hover:underline"
                            >
                              تأكيد
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="text-xs text-slate-500 hover:underline"
                            >
                              إلغاء
                            </button>
                          </div>
                        ) : (
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => setViewingStudentId(student.id)}
                              className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                              aria-label={`ملف الطالب ${student.name}`}
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => openEditModal(student)}
                              className="p-2 text-slate-500 hover:text-teal-700 hover:bg-slate-100 rounded-lg transition-colors"
                              aria-label={`تعديل ${student.name}`}
                            >
                              <Pencil className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(student.id)}
                              className="p-2 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                              aria-label={`حذف ${student.name}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Student Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingStudent ? 'تعديل بيانات الطالب' : 'تسجيل طالب جديد'}
        subtitle="يحصل كل طالب على كود فريد يرتبط بجميع اختباره وتقاريره"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                الكود الفريد للطالب *
              </label>
              <input
                type="text"
                required
                value={form.code}
                onChange={(e) => {
                  setForm({ ...form, code: e.target.value });
                  setCodeError('');
                }}
                placeholder="MYR-1017"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-teal-600"
              />
              {codeError && <p className="text-xs text-red-700 mt-1">{codeError}</p>}
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                اسم الطالب ثلاثياً *
              </label>
              <input
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="مثال: عبد الله محمد محمود"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                المجموعة
              </label>
              <select
                value={form.groupId}
                onChange={(e) => handleGroupChange(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-teal-600"
              >
                <option value="">
                  {state.groups.length === 0 ? 'بدون مجموعة حالياً' : 'اختر المجموعة'}
                </option>
                {state.groups.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                المدرس
              </label>
              <select
                value={form.teacherId}
                onChange={(e) => setForm({ ...form, teacherId: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-teal-600"
              >
                <option value="">اختر المدرس</option>
                {state.teachers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                المادة الدراسية
              </label>
              <select
                value={form.subjectId}
                onChange={(e) => setForm({ ...form, subjectId: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-teal-600"
              >
                <option value="">
                  {state.subjects.length === 0 ? 'حسب المجموعة' : 'اختر المادة'}
                </option>
                {state.subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                رقم هاتف الطالب
              </label>
              <input
                type="tel"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                placeholder="01000000000"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-teal-600"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                رقم هاتف ولي الأمر
              </label>
              <input
                type="tel"
                value={form.guardianPhone}
                onChange={(e) => setForm({ ...form, guardianPhone: e.target.value })}
                placeholder="01000000000"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-teal-600"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              ملاحظات أكاديمية
            </label>
            <textarea
              rows={2}
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              placeholder="ملاحظات اختيارية حول مستوى الطالب أو خطة المتابعة..."
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-lg"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 disabled:opacity-60 rounded-lg"
            >
              {isSubmitting
                ? 'جاري الحفظ...'
                : editingStudent
                ? 'حفظ التعديلات'
                : 'تسجيل الطالب'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Student Profile / History Modal */}
      <Modal
        open={Boolean(inspectedSummary)}
        onClose={() => setViewingStudentId(null)}
        title={inspectedSummary ? inspectedSummary.student.name : ''}
        subtitle={
          inspectedSummary
            ? `${inspectedSummary.student.code} · ${inspectedSummary.groupName} · ${inspectedSummary.teacherName}`
            : undefined
        }
        size="lg"
      >
        {inspectedSummary && (
          <div className="space-y-6">
            <div className="grid grid-cols-3 divide-x divide-x-reverse divide-slate-200 border border-slate-200 rounded-lg">
              <div className="p-4">
                <p className="text-xs text-slate-500">المتوسط العام</p>
                <p className="text-2xl font-bold font-mono tabular-nums text-teal-800 mt-1">
                  {inspectedSummary.averagePercentage !== null
                    ? `${inspectedSummary.averagePercentage}%`
                    : '—'}
                </p>
              </div>
              <div className="p-4">
                <p className="text-xs text-slate-500">أعلى درجة</p>
                <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                  {inspectedSummary.highestPercentage !== null
                    ? `${inspectedSummary.highestPercentage}%`
                    : '—'}
                </p>
              </div>
              <div className="p-4">
                <p className="text-xs text-slate-500">الاختبارات المصححة</p>
                <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                  {inspectedSummary.gradedCount}
                </p>
              </div>
            </div>

            <div>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                <h3 className="text-sm font-bold text-slate-900">سجل الدرجات والاختبارات</h3>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => triggerSingleSheetPrint()}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>طباعة تقرير الطالب (A4)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const id = inspectedSummary.student.id;
                      setViewingStudentId(null);
                      navigate('grading', { studentId: id });
                    }}
                    className="text-xs font-medium text-teal-700 hover:text-teal-900 whitespace-nowrap"
                  >
                    فتح شاشة التصحيح للطالب
                  </button>
                </div>
              </div>
              {inspectedSubmissions.length === 0 ? (
                <p className="text-sm text-slate-500 py-6 text-center border border-slate-200 rounded-lg">
                  لم يتم رصد أي درجات لهذا الطالب بعد.
                </p>
              ) : (
                <div className="border border-slate-200 rounded-lg divide-y divide-slate-200">
                  {inspectedSubmissions.map(({ sub, assignment }) => (
                    <div key={sub.id} className="p-4 flex items-center justify-between gap-4">
                      <div>
                        <p className="text-sm font-semibold text-slate-900">
                          {assignment?.title ?? 'اختبار محذوف'}
                        </p>
                        <p className="text-xs text-slate-500 mt-0.5">
                          تاريخ التصحيح: {formatArabicDate(sub.gradedAt)} · إجابات صحيحة:{' '}
                          <span className="font-mono tabular-nums">{sub.correctCount}</span> · أخطاء:{' '}
                          <span className="font-mono tabular-nums">{sub.wrongCount}</span>
                        </p>
                      </div>
                      <div className="text-left shrink-0">
                        <div className="font-mono tabular-nums text-sm font-bold text-slate-900">
                          {sub.earnedMarks} / {sub.totalMarks}
                        </div>
                        <div className={`font-mono tabular-nums text-xs font-semibold ${getPerformanceBand(sub.percentage).textClass}`}>
                          {sub.percentage}% · {getPerformanceBand(sub.percentage).label}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>

      {/* Hidden Portaled Individual Student A4 Print Sheet */}
      {inspectedSummary && (
        <StudentA4ReportSheet
          summary={inspectedSummary}
          submissions={inspectedSubmissions}
        />
      )}
    </div>
  );
};
