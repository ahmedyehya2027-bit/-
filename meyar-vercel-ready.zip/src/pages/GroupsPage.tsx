import React, { useMemo, useState } from 'react';
import { Plus, Pencil, Trash2, Search, Download } from 'lucide-react';
import { useMeyar } from '../context/MeyarContext';
import type { StudyGroup } from '../types/domain';
import {
  buildExportFilename,
  buildGroupsCsvData,
  downloadCsvFile,
} from '../utils/exportCsv';
import { Modal } from '../components/ui/Modal';

interface GroupFormState {
  name: string;
  gradeLevel: string;
  teacherId: string;
  subjectId: string;
  schedule: string;
  capacity: number;
}

export const GroupsPage: React.FC = () => {
  const { state, currentTeacher, addGroup, updateGroup, deleteGroup, showToast } = useMeyar();
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState<StudyGroup | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [form, setForm] = useState<GroupFormState>({
    name: '',
    gradeLevel: 'الصف الثالث الثانوي',
    teacherId: '',
    subjectId: '',
    schedule: '',
    capacity: 25,
  });

  const teacherMap = useMemo(
    () => new Map(state.teachers.map((t) => [t.id, t.name])),
    [state.teachers]
  );
  const subjectMap = useMemo(
    () => new Map(state.subjects.map((s) => [s.id, s.name])),
    [state.subjects]
  );

  const groupRows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return state.groups
      .filter((g) => {
        if (!q) return true;
        return (
          g.name.toLowerCase().includes(q) ||
          g.gradeLevel.toLowerCase().includes(q) ||
          (teacherMap.get(g.teacherId) ?? '').toLowerCase().includes(q)
        );
      })
      .map((g) => {
        const enrolled = state.students.filter((st) => st.groupId === g.id).length;
        const asgs = state.assignments.filter((a) => a.groupId === g.id);
        const asgIds = new Set(asgs.map((a) => a.id));
        const subs = state.submissions.filter((sub) => asgIds.has(sub.assignmentId));
        const avg =
          subs.length > 0
            ? Math.round(
                (subs.reduce((acc, s) => acc + s.percentage, 0) / subs.length) * 10
              ) / 10
            : null;
        const passRate =
          subs.length > 0
            ? Math.round(
                (subs.filter((s) => s.percentage >= 60).length / subs.length) * 100
              )
            : null;
        return {
          group: g,
          teacherName: teacherMap.get(g.teacherId) ?? 'غير محدد',
          subjectName: subjectMap.get(g.subjectId) ?? 'غير محدد',
          enrolled,
          assignmentsCount: asgs.length,
          gradedCount: subs.length,
          avg,
          passRate,
        };
      });
  }, [state.groups, state.students, state.assignments, state.submissions, teacherMap, subjectMap, search]);

  const openCreateModal = () => {
    setEditingGroup(null);
    setForm({
      name: '',
      gradeLevel: 'الصف الثالث الثانوي',
      teacherId: currentTeacher?.id ?? state.teachers[0]?.id ?? '',
      subjectId: state.subjects[0]?.id ?? '',
      schedule: '',
      capacity: 25,
    });
    setModalOpen(true);
  };

  const openEditModal = (group: StudyGroup) => {
    setEditingGroup(group);
    setForm({
      name: group.name,
      gradeLevel: group.gradeLevel,
      teacherId: group.teacherId,
      subjectId: group.subjectId,
      schedule: group.schedule,
      capacity: group.capacity,
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || isSubmitting) return;
    setIsSubmitting(true);
    try {
      const ok = editingGroup
        ? await updateGroup(editingGroup.id, form)
        : await addGroup(form);
      if (ok) {
        setModalOpen(false);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleExportGroupsCSV = () => {
    const isFiltered = search.trim().length > 0;
    const { headers, rows } = buildGroupsCsvData(groupRows);
    const filename = buildExportFilename('groups', { filtered: isFiltered });
    const res = downloadCsvFile(filename, headers, rows);
    showToast(`تم تصدير ${res.rowCount} مجموعة إلى الملف ${res.filename}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">إدارة المجموعات</h2>
          <p className="text-sm text-slate-500 mt-1">
            تنظيم المجموعات الدراسية ومواعيدها وسعتها الاستيعابية وربطها بالمدرس والمادة.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            disabled={groupRows.length === 0}
            onClick={handleExportGroupsCSV}
            className="inline-flex items-center justify-center gap-2 px-3.5 py-2.5 text-sm font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Download className="w-4 h-4" />
            <span>تصدير CSV</span>
          </button>
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>إنشاء مجموعة</span>
          </button>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث باسم المجموعة أو المرحلة أو المدرس..."
              className="w-full pr-9 pl-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
            />
          </div>
          <span className="text-xs text-slate-500 font-mono tabular-nums">
            {groupRows.length} مجموعة دراسية
          </span>
        </div>

        {groupRows.length === 0 ? (
          <div className="p-10 text-center space-y-3">
            <p className="text-sm text-slate-600">
              {state.groups.length === 0
                ? 'لا توجد مجموعات دراسية مسجلة بعد.'
                : 'لا توجد مجموعات مطابقة للبحث الحالي.'}
            </p>
            <div className="flex items-center justify-center gap-2">
              {state.groups.length > 0 && (
                <button
                  type="button"
                  onClick={() => setSearch('')}
                  className="px-4 py-2 text-xs font-medium text-teal-700 border border-teal-200 hover:bg-teal-50 rounded-lg"
                >
                  مسح البحث
                </button>
              )}
              <button
                type="button"
                onClick={openCreateModal}
                className="px-4 py-2 text-xs font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg"
              >
                إنشاء مجموعة جديدة
              </button>
            </div>
          </div>
        ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-right text-sm">
            <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
              <tr>
                <th className="py-3 px-6 font-medium">اسم المجموعة</th>
                <th className="py-3 px-4 font-medium">المدرس والمادة</th>
                <th className="py-3 px-4 font-medium">المواعيد</th>
                <th className="py-3 px-4 font-medium text-left">الطلاب / السعة</th>
                <th className="py-3 px-4 font-medium text-left">المتوسط</th>
                <th className="py-3 px-6 font-medium text-left">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/80">
              {groupRows.map(({ group, teacherName, subjectName, enrolled, assignmentsCount, avg }) => (
                <tr key={group.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-4 px-6">
                    <div className="font-semibold text-slate-900">{group.name}</div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {group.gradeLevel} · <span className="font-mono tabular-nums">{assignmentsCount}</span> واجب/امتحان
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="text-xs font-medium text-slate-900">{teacherName}</div>
                    <div className="text-xs text-slate-500 mt-0.5">{subjectName}</div>
                  </td>
                  <td className="py-4 px-4 text-xs text-slate-600">{group.schedule || '—'}</td>
                  <td className="py-4 px-4 text-left font-mono tabular-nums text-xs text-slate-800">
                    {enrolled} / {group.capacity}
                  </td>
                  <td className="py-4 px-4 text-left font-mono tabular-nums text-sm">
                    {avg !== null ? (
                      <span className="font-semibold text-teal-800">{avg}%</span>
                    ) : (
                      <span className="text-slate-400">—</span>
                    )}
                  </td>
                  <td className="py-4 px-6 text-left whitespace-nowrap">
                    {confirmDeleteId === group.id ? (
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={async () => {
                            await deleteGroup(group.id);
                            setConfirmDeleteId(null);
                          }}
                          className="text-xs font-medium text-red-700 hover:underline"
                        >
                          تأكيد
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(null)}
                          className="text-xs text-slate-500 hover:underline"
                        >
                          إلغاء
                        </button>
                      </div>
                    ) : (
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => openEditModal(group)}
                          className="p-2 text-slate-500 hover:text-teal-700 hover:bg-slate-100 rounded-lg transition-colors"
                          aria-label={`تعديل ${group.name}`}
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(group.id)}
                          className="p-2 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                          aria-label={`حذف ${group.name}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        )}
      </div>

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingGroup ? 'تعديل المجموعة الدراسية' : 'إنشاء مجموعة دراسية جديدة'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                اسم المجموعة *
              </label>
              <input
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="مثال: الثالث الثانوي — فيزياء (ب)"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                الصف الدراسي *
              </label>
              <input
                type="text"
                required
                value={form.gradeLevel}
                onChange={(e) => setForm({ ...form, gradeLevel: e.target.value })}
                placeholder="الصف الثالث الثانوي"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                المدرس المسؤول *
              </label>
              <select
                required
                value={form.teacherId}
                onChange={(e) => setForm({ ...form, teacherId: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-teal-600"
              >
                <option value="">اختر المدرس</option>
                {state.teachers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                المادة الدراسية
              </label>
              <select
                value={form.subjectId}
                onChange={(e) => setForm({ ...form, subjectId: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-teal-600"
              >
                <option value="">
                  {state.subjects.length === 0 ? 'بدون مادة حالياً' : 'اختر المادة'}
                </option>
                {state.subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                مواعيد الحصص
              </label>
              <input
                type="text"
                value={form.schedule}
                onChange={(e) => setForm({ ...form, schedule: e.target.value })}
                placeholder="السبت والثلاثاء · 4:00 عصراً"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                السعة القصوى
              </label>
              <input
                type="number"
                min={1}
                max={200}
                value={form.capacity}
                onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) || 20 })}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-teal-600"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-lg"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 disabled:opacity-60 rounded-lg"
            >
              {isSubmitting
                ? 'جاري الحفظ...'
                : editingGroup
                ? 'حفظ التعديلات'
                : 'إنشاء المجموعة'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
