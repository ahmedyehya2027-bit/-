import React, { useMemo } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import {
  ArrowUpLeft,
  CheckSquare,
  FilePlus2,
  UserPlus,
  KeyRound,
} from 'lucide-react';
import { useMeyar } from '../context/MeyarContext';
import {
  computeDifficultTopics,
  formatArabicDate,
  getPerformanceBand,
} from '../utils/grading';

export const DashboardPage: React.FC = () => {
  const { state, navigate } = useMeyar();

  const overallAverage = useMemo(() => {
    if (state.submissions.length === 0) return 0;
    const sum = state.submissions.reduce((acc, s) => acc + s.percentage, 0);
    return Math.round((sum / state.submissions.length) * 10) / 10;
  }, [state.submissions]);

  const groupChartData = useMemo(() => {
    return state.groups.map((grp) => {
      const grpAssignments = state.assignments.filter((a) => a.groupId === grp.id);
      const grpAssignmentIds = new Set(grpAssignments.map((a) => a.id));
      const grpSubs = state.submissions.filter((s) => grpAssignmentIds.has(s.assignmentId));
      const avg =
        grpSubs.length > 0
          ? Math.round(
              (grpSubs.reduce((acc, s) => acc + s.percentage, 0) / grpSubs.length) * 10
            ) / 10
          : 0;
      const shortName = grp.name.includes('—') ? grp.name.split('—')[1].trim() : grp.name;
      return {
        id: grp.id,
        name: shortName,
        fullName: grp.name,
        average: avg,
        submissions: grpSubs.length,
        students: state.students.filter((st) => st.groupId === grp.id).length,
      };
    });
  }, [state.groups, state.assignments, state.submissions, state.students]);

  const difficultTopics = useMemo(
    () =>
      computeDifficultTopics(state.assignments, state.submissions, state.subjects).slice(0, 4),
    [state.assignments, state.submissions, state.subjects]
  );

  const upcomingAssignments = useMemo(() => {
    const groupMap = new Map(state.groups.map((g) => [g.id, g.name]));
    const subjectMap = new Map(state.subjects.map((s) => [s.id, s.name]));
    return state.assignments.slice(0, 5).map((asg) => {
      const groupStudentsCount = state.students.filter((st) => st.groupId === asg.groupId).length;
      const gradedCount = state.submissions.filter((s) => s.assignmentId === asg.id).length;
      return {
        ...asg,
        groupName: groupMap.get(asg.groupId) ?? '—',
        subjectName: subjectMap.get(asg.subjectId) ?? '—',
        groupStudentsCount,
        gradedCount,
      };
    });
  }, [state.assignments, state.groups, state.subjects, state.students, state.submissions]);

  const band = getPerformanceBand(overallAverage);

  return (
    <div className="space-y-8">
      {/* Intro Heading & Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">ملخص المنصة الأكاديمية</h2>
          <p className="text-sm text-slate-500 mt-1">
            متابعة شاملة لأداء المجموعات، حركة التصحيح اليومية، والواجبات النشطة.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => navigate('students')}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap"
          >
            <UserPlus className="w-3.5 h-3.5 text-slate-500" />
            <span>إضافة طالب</span>
          </button>
          <button
            type="button"
            onClick={() => navigate('assignments')}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap"
          >
            <FilePlus2 className="w-3.5 h-3.5 text-slate-500" />
            <span>إنشاء واجب / امتحان</span>
          </button>
          <button
            type="button"
            onClick={() => navigate('answer-keys')}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap"
          >
            <KeyRound className="w-3.5 h-3.5 text-slate-500" />
            <span>نماذج الإجابة</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Strip — Single Flat Container with Clean Hairline Dividers */}
      <section
        aria-label="المؤشرات الرئيسية"
        className="bg-white border border-slate-200 rounded-xl grid grid-cols-2 lg:grid-cols-5 divide-y lg:divide-y-0 lg:divide-x lg:divide-x-reverse divide-slate-200"
      >
        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">إجمالي المدرسين</p>
          <p className="mt-2 text-3xl font-bold text-slate-900 font-mono tabular-nums">
            {state.teachers.length}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            في {state.subjects.length} مواد دراسية
          </p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">إجمالي الطلاب</p>
          <p className="mt-2 text-3xl font-bold text-slate-900 font-mono tabular-nums">
            {state.students.length}
          </p>
          <p className="mt-1 text-xs text-slate-500">مسجلون بأكواد تعريفية</p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">المجموعات النشطة</p>
          <p className="mt-2 text-3xl font-bold text-slate-900 font-mono tabular-nums">
            {state.groups.length}
          </p>
          <p className="mt-1 text-xs text-slate-500">بمتوسط {Math.round(state.students.length / Math.max(state.groups.length, 1))} طالب/مجموعة</p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">الواجبات والامتحانات</p>
          <p className="mt-2 text-3xl font-bold text-slate-900 font-mono tabular-nums">
            {state.assignments.length}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            <span className="font-mono tabular-nums">{state.submissions.length}</span> ورقة مصححة
          </p>
        </div>

        <div className="p-5 col-span-2 lg:col-span-1">
          <p className="text-xs font-medium text-slate-500">متوسط الدرجات العام</p>
          <p className="mt-2 text-3xl font-bold text-teal-800 font-mono tabular-nums">
            {overallAverage}%
          </p>
          <p className={`mt-1 text-xs font-medium ${band.textClass}`}>
            التقدير العام: {band.label}
          </p>
        </div>
      </section>

      {/* Main Analytics + Activity Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Group Averages Chart */}
        <section className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6">
          <div className="flex items-center justify-between gap-4 mb-6">
            <div>
              <h3 className="text-base font-bold text-slate-900">متوسط أداء المجموعات الدراسية</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                النسبة المئوية لمتوسط درجات الطلاب المصححة في كل مجموعة
              </p>
            </div>
            <button
              type="button"
              onClick={() => navigate('analytics')}
              className="inline-flex items-center gap-1 text-xs font-medium text-teal-700 hover:text-teal-900 whitespace-nowrap shrink-0"
            >
              <span>التحليل المفصل</span>
              <ArrowUpLeft className="w-3.5 h-3.5" />
            </button>
          </div>

          {groupChartData.length === 0 ? (
            <div className="h-64 flex items-center justify-center text-sm text-slate-400">
              لا توجد مجموعات مسجلة بعد لعرض متوسط الأداء.
            </div>
          ) : (
            <div className="h-64 w-full" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={groupChartData}
                  margin={{ top: 8, right: 12, left: 0, bottom: 8 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                  <XAxis
                    dataKey="name"
                    tick={{ fill: '#475569', fontSize: 12 }}
                    axisLine={{ stroke: '#CBD5E1' }}
                    tickLine={false}
                  />
                  <YAxis
                    domain={[0, 100]}
                    tick={{ fill: '#64748B', fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                    unit="%"
                  />
                  <Tooltip
                    formatter={(value) => [`${value ?? 0}%`, 'متوسط المجموعة']}
                    labelFormatter={(_label, payload) =>
                      payload?.[0]?.payload?.fullName ?? ''
                    }
                    contentStyle={{
                      borderRadius: '8px',
                      border: '1px solid #E2E8F0',
                      fontSize: '12px',
                      direction: 'rtl',
                      textAlign: 'right',
                    }}
                  />
                  <Bar dataKey="average" fill="#0F766E" radius={[6, 6, 0, 0]} maxBarSize={44} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </section>

        {/* Recent Activity Log */}
        <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">النشاط الأخير</h3>
            <span className="text-xs text-slate-400 font-mono tabular-nums">
              آخر {Math.min(state.activities.length, 6)} عمليات
            </span>
          </div>
          {state.activities.length === 0 ? (
            <div className="p-6 text-center text-sm text-slate-500">
              لا توجد أنشطة مسجلة حتى الآن.
            </div>
          ) : (
            <ul className="divide-y divide-slate-200/80">
              {state.activities.slice(0, 6).map((act) => (
                <li key={act.id} className="px-6 py-3.5 hover:bg-slate-50/70 transition-colors">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-900">{act.action}</p>
                      <p className="text-xs text-slate-600 mt-0.5 truncate">{act.target}</p>
                      <p className="text-xs text-slate-400 mt-1">
                        {act.actor} <span aria-hidden="true">·</span>{' '}
                        {formatArabicDate(act.timestamp)}
                      </p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* Bottom Split: Active Assignments Progress + Difficult Topics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Recent Assignments & Grading Completion */}
        <section className="lg:col-span-7 bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">حالة تصحيح الواجبات والامتحانات</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                انتقل مباشرة إلى شاشة التصحيح لأي اختبار أو واجب
              </p>
            </div>
            <button
              type="button"
              onClick={() => navigate('assignments')}
              className="text-xs font-medium text-teal-700 hover:text-teal-900 whitespace-nowrap"
            >
              عرض الكل
            </button>
          </div>
          {upcomingAssignments.length === 0 ? (
            <div className="p-8 text-center space-y-3">
              <p className="text-sm text-slate-500">لا توجد واجبات أو امتحانات مسجلة حالياً.</p>
              <button
                type="button"
                onClick={() => navigate('assignments')}
                className="px-4 py-2 text-xs font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg"
              >
                إنشاء أول اختبار
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right text-sm">
                <thead className="bg-slate-50 text-xs text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-6 font-medium">العنوان</th>
                    <th className="py-3 px-4 font-medium">المجموعة</th>
                    <th className="py-3 px-4 font-medium">الموعد النهائي</th>
                    <th className="py-3 px-4 font-medium text-left">تم تصحيحه</th>
                    <th className="py-3 px-6 font-medium text-left">إجراء</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/80">
                  {upcomingAssignments.map((asg) => (
                    <tr key={asg.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-6">
                        <div className="font-medium text-slate-900">{asg.title}</div>
                        <div className="text-xs text-slate-500 mt-0.5">
                          {asg.kind === 'exam' ? 'امتحان' : 'واجب'} · {asg.subjectName} ·{' '}
                          <span className="font-mono tabular-nums">{asg.totalMarks}</span> درجة
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-600">{asg.groupName}</td>
                      <td className="py-3.5 px-4 text-xs text-slate-600 whitespace-nowrap">
                        {formatArabicDate(asg.deadline)}
                      </td>
                      <td className="py-3.5 px-4 text-left font-mono tabular-nums text-xs text-slate-700">
                        {asg.gradedCount} / {asg.groupStudentsCount}
                      </td>
                      <td className="py-3.5 px-6 text-left">
                        <button
                          type="button"
                          onClick={() => navigate('grading', { assignmentId: asg.id })}
                          className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-700 hover:text-teal-900 whitespace-nowrap"
                        >
                          <CheckSquare className="w-3.5 h-3.5" />
                          <span>تصحيح</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* Most Difficult Topics */}
        <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">الموضوعات الأكثر صعوبة</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                مرتبة حسب نسبة الإجابات الخاطئة في الاختبارات المصححة
              </p>
            </div>
          </div>
          {difficultTopics.length === 0 ? (
            <div className="p-6 text-center text-sm text-slate-500">
              لا توجد بيانات تصحيح كافية بعد لعرض الموضوعات الصعبة.
            </div>
          ) : (
            <ul className="divide-y divide-slate-200/80">
              {difficultTopics.map((item) => (
                <li key={`${item.subjectId}-${item.topic}`} className="px-6 py-4">
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="font-medium text-slate-900">{item.topic}</span>
                    <span className="font-mono tabular-nums text-xs font-semibold text-red-700">
                      نسبة الخطأ {item.errorRate}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mt-1">
                    <span>{item.subjectName}</span>
                    <span className="font-mono tabular-nums">
                      {item.wrongAttempts} خطأ من {item.totalAttempts} إجابة
                    </span>
                  </div>
                  <div className="mt-2.5 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-amber-600 rounded-full transition-all"
                      style={{ width: `${item.errorRate}%` }}
                    />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
};
