import React, { useState } from 'react';
import {
  Mail,
  Lock,
  User as UserIcon,
  Phone,
  BookOpen,
  LogIn,
  UserPlus,
  AlertCircle,
  CheckCircle2,
  Loader2,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabaseInitError } from '../lib/supabase';

type AuthMode = 'signin' | 'signup';

export const AuthPage: React.FC = () => {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<AuthMode>('signin');
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(supabaseInitError);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [specialty, setSpecialty] = useState('');
  const [phone, setPhone] = useState('');

  const switchMode = (next: AuthMode) => {
    setMode(next);
    setErrorMessage(null);
    setSuccessMessage(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!email.trim() || !password) {
      setErrorMessage('يرجى إدخال البريد الإلكتروني وكلمة المرور.');
      return;
    }

    if (mode === 'signup') {
      if (!fullName.trim()) {
        setErrorMessage('يرجى إدخال الاسم الكامل للمدرس.');
        return;
      }
      if (password.length < 6) {
        setErrorMessage('كلمة المرور يجب أن تتكون من 6 أحرف على الأقل.');
        return;
      }
    }

    setSubmitting(true);
    try {
      if (mode === 'signin') {
        const res = await signIn(email, password);
        if (res.error) {
          setErrorMessage(res.error);
        }
      } else {
        const res = await signUp({
          fullName,
          email,
          password,
          phone,
          specialty,
        });
        if (res.error) {
          setErrorMessage(res.error);
        } else if (res.needsEmailConfirmation) {
          setSuccessMessage(
            'تم إنشاء الحساب بنجاح. يرجى فتح بريدك الإلكتروني وتأكيد الحساب عبر الرابط المرسل، ثم تسجيل الدخول.'
          );
          setMode('signin');
          setPassword('');
        }
      }
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : 'حدث خطأ غير متوقع أثناء المصادقة.';
      setErrorMessage(msg);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col justify-center py-10 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md mx-auto space-y-6">
        {/* Brand Identity */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-3">
            <span className="w-11 h-11 rounded-xl bg-teal-700 text-white flex items-center justify-center font-bold text-xl shadow-xs">
              م
            </span>
            <div className="text-right">
              <div className="font-bold text-slate-900 text-xl tracking-tight">
                مِعيار <span className="text-slate-300 font-normal mx-1">|</span>
                <span className="font-mono text-sm font-semibold text-teal-800 tracking-wider">
                  ME&apos;YAR
                </span>
              </div>
              <p className="text-xs text-slate-500">
                منصة إدارة الطلاب والاختبارات والتصحيح الأكاديمي
              </p>
            </div>
          </div>
        </div>

        {/* Auth Card */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
          {/* Mode Switch Tabs */}
          <div className="grid grid-cols-2 border-b border-slate-200 bg-slate-50/70">
            <button
              type="button"
              onClick={() => switchMode('signin')}
              className={`py-3.5 px-4 text-sm font-semibold flex items-center justify-center gap-2 border-b-2 transition-colors ${
                mode === 'signin'
                  ? 'border-teal-700 text-teal-800 bg-white'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <LogIn className="w-4 h-4" />
              <span>تسجيل الدخول</span>
            </button>
            <button
              type="button"
              onClick={() => switchMode('signup')}
              className={`py-3.5 px-4 text-sm font-semibold flex items-center justify-center gap-2 border-b-2 transition-colors ${
                mode === 'signup'
                  ? 'border-teal-700 text-teal-800 bg-white'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <UserPlus className="w-4 h-4" />
              <span>إنشاء حساب مدرس</span>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6 sm:p-7 space-y-4">
            <div className="space-y-1">
              <h1 className="text-lg font-bold text-slate-900">
                {mode === 'signin'
                  ? 'أهلاً بك مجدداً في مِعيار'
                  : 'تسجيل حساب مدرس جديد'}
              </h1>
              <p className="text-xs text-slate-500 leading-relaxed">
                {mode === 'signin'
                  ? 'سجّل الدخول للوصول إلى طلابك ومجموعاتك واختباراتك المحفوظة بشكل آمن.'
                  : 'أنشئ حسابك الشخصي لإدارة فصولك وطلابك ودرجاتك بخصوصية كاملة.'}
              </p>
            </div>

            {errorMessage && (
              <div
                role="alert"
                className="flex items-start gap-2.5 p-3.5 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800 leading-relaxed break-words"
              >
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
                <span className="min-w-0">{errorMessage}</span>
              </div>
            )}

            {successMessage && (
              <div
                role="status"
                className="flex items-start gap-2.5 p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 leading-relaxed"
              >
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
                <span>{successMessage}</span>
              </div>
            )}

            {mode === 'signup' && (
              <>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    الاسم الكامل للمدرس *
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="مثال: أ. كريم عبد الله"
                      className="w-full pr-9 pl-3 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      التخصص الدراسي
                    </label>
                    <div className="relative">
                      <BookOpen className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        value={specialty}
                        onChange={(e) => setSpecialty(e.target.value)}
                        placeholder="مثال: رياضيات"
                        className="w-full pr-9 pl-3 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-teal-600"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      رقم الهاتف
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="01000000000"
                        className="w-full pr-9 pl-3 py-2.5 text-sm border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-teal-600"
                      />
                    </div>
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                البريد الإلكتروني *
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="teacher@example.com"
                  dir="ltr"
                  className="w-full pr-9 pl-3 py-2.5 text-sm text-left border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-teal-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                كلمة المرور *
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="password"
                  required
                  minLength={6}
                  autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  dir="ltr"
                  className="w-full pr-9 pl-3 py-2.5 text-sm text-left border border-slate-200 rounded-lg font-mono focus:outline-none focus:border-teal-600"
                />
              </div>
              {mode === 'signup' && (
                <p className="text-[11px] text-slate-500 mt-1">
                  يجب ألا تقل كلمة المرور عن 6 أحرف.
                </p>
              )}
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full mt-2 inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-teal-700 hover:bg-teal-800 disabled:opacity-60 disabled:cursor-not-allowed rounded-lg transition-colors"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>
                    {mode === 'signin' ? 'جاري تسجيل الدخول...' : 'جاري إنشاء الحساب...'}
                  </span>
                </>
              ) : mode === 'signin' ? (
                <>
                  <LogIn className="w-4 h-4" />
                  <span>تسجيل الدخول إلى المنصة</span>
                </>
              ) : (
                <>
                  <UserPlus className="w-4 h-4" />
                  <span>إنشاء حساب المدرس</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Security Assurance Note */}
        <div className="flex items-center justify-center gap-2 text-xs text-slate-500">
          <ShieldCheck className="w-4 h-4 text-teal-700 shrink-0" />
          <span>بيانات كل مدرس محمية ومعزولة بالكامل بحسابه الشخصي</span>
        </div>
      </div>
    </div>
  );
};
