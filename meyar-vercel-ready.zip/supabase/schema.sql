-- ME'YAR — Supabase schema + RLS. Run once in Supabase SQL Editor (safe to re-run).
create extension if not exists pgcrypto;

create table if not exists public.teachers (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text, email text, phone text, specialty text,
  created_at timestamptz not null default now()
);
create table if not exists public.subjects (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.teachers(id) on delete cascade,
  name text not null, code text, description text,
  created_at timestamptz not null default now()
);
create table if not exists public.groups (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.teachers(id) on delete cascade,
  subject_id uuid references public.subjects(id) on delete set null,
  name text not null, schedule text,
  created_at timestamptz not null default now()
);
create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.teachers(id) on delete cascade,
  group_id uuid references public.groups(id) on delete set null,
  student_code text, full_name text not null, phone text, parent_phone text, notes text,
  created_at timestamptz not null default now()
);
create table if not exists public.assignments (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.teachers(id) on delete cascade,
  subject_id uuid references public.subjects(id) on delete set null,
  group_id uuid references public.groups(id) on delete set null,
  title text not null, type text default 'exam',
  total_marks numeric default 0, due_date date, status text default 'active',
  created_at timestamptz not null default now()
);
create table if not exists public.answer_keys (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.teachers(id) on delete cascade,
  assignment_id uuid not null unique references public.assignments(id) on delete cascade,
  questions jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.teachers(id) on delete cascade,
  assignment_id uuid not null references public.assignments(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  answers jsonb not null default '{}'::jsonb,
  mcq_score numeric default 0, essay_score numeric default 0,
  total_score numeric default 0, max_score numeric default 0,
  ai_feedback text, weak_topics jsonb not null default '[]'::jsonb,
  status text default 'graded', submission_source text default 'manual',
  file_url text, graded_at timestamptz,
  created_at timestamptz not null default now()
);

create unique index if not exists students_code_uq
  on public.students (teacher_id, student_code) where student_code is not null and student_code <> '';
create unique index if not exists subjects_code_uq
  on public.subjects (teacher_id, code) where code is not null and code <> '';
create index if not exists groups_t on public.groups(teacher_id);
create index if not exists students_t on public.students(teacher_id);
create index if not exists students_g on public.students(group_id);
create index if not exists assignments_t on public.assignments(teacher_id);
create index if not exists submissions_t on public.submissions(teacher_id);
create index if not exists submissions_a on public.submissions(assignment_id);
create index if not exists submissions_s on public.submissions(student_id);

-- RLS: each teacher sees and changes only their own rows
alter table public.teachers enable row level security;
drop policy if exists teachers_own on public.teachers;
create policy teachers_own on public.teachers for all to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

do $$
declare t text;
begin
  foreach t in array array['subjects','groups','students','assignments','answer_keys','submissions'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists %I on public.%I', t||'_own', t);
    execute format('create policy %I on public.%I for all to authenticated using (teacher_id = auth.uid()) with check (teacher_id = auth.uid())', t||'_own', t);
  end loop;
end $$;

-- Auto-create the teacher profile when an auth user signs up
create or replace function public.handle_new_teacher() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.teachers (id, full_name, email, phone, specialty)
  values (new.id,
    coalesce(nullif(new.raw_user_meta_data->>'full_name',''), split_part(new.email,'@',1)),
    new.email,
    coalesce(new.raw_user_meta_data->>'phone',''),
    coalesce(nullif(new.raw_user_meta_data->>'specialty',''), 'تعليم عام'))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_teacher();
